title_page_texts_dict = {

"title_present":\
{"pass":"You have included a title",\
"fail":"Have you given your manuscript a title?",\
"explain":"Your title should be shorter than 70 characters, and it should include the key elements of your work, such as your experimental design and subject matter, so that others can find it easily.",\
"none":""},\

"title_length":\
{"pass":"Your title is shorter than 70 characters",\
"fail":"Is your title shorter than 70 characters?",\
"explain":"""You may have to make your title shorter before it can be accepted by the journal's submission system. Your title will be indexed by search engines, so it should include the key elements of your work, such as your experimental design and subject matter, so that others can find it easily.""",\
"none":"It wasn't possible to check the length of your title"},\

"corresponding_author":\
{"pass":"You have named a corresponding author",\
"fail":"Have you named a corresponding author?",\
"explain":"You should state who the corresponding author is.",\
"none":"It wasn't possible to check for a corresponding author",\
},\

"email":\
{"pass":"You have included an email address",\
"fail":"Have you included an email address?",\
"explain":"Make sure you include the email address of the corresponding author.",\
"none":"It wasn't possible to check for an email address",\
}

}