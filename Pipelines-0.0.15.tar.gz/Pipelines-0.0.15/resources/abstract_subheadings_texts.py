abstract_subheading_texts_dict = {

"purpose_h_ab_sub":\
{"pass":"You have a 'Purpose' subsection in your abstract",\
"fail":"Have you included a 'Purpose' subsection in your abstract?",\
"explain":"""Your abstract should be structured with the subsections 'Purpose', 'Methods', 'Results' and 'Conclusions'. The purpose section should set out your primary objectives.""",\
"none":"Your Abstract wasn't checked for subheadings"},\

"methods_h_ab_sub":\
{"pass":"You have a 'Methods' subsection in your abstract",\
"fail":"Have you included a 'Methods' subsection in your abstract?",\
"explain":"""Abstracts should be structured with the subsections 'Purpose', 'Methods', 'Results' and 'Conclusions'. The methods section should include the experimental design (if it's not in your title), the sample population, and the main techniques used.""",\
"none":"Your Abstract wasn't checked for subheadings"},\

"results_h_ab_sub":\
{"pass":"You have a 'Results' subsection in your abstract",\
"fail":"Have you included a 'Results' subsection in your abstract?",\
"explain":"""Abstracts should be structured with the subsections 'Purpose', 'Methods', 'Results' and 'Conclusions'. Report the main results, whether they were significant or not. Do not selectively mention significant results that weren't central to the objectives of your study.""",\
"none":"Your Abstract wasn't checked for subheadings"},\

"conclusions_h_ab_sub":\
{"pass":"You have a 'Conclusions' subsection in your abstract",\
"fail":"Have you included a 'Conclusions' subsection in your abstract?",\
"explain":"""Abstracts should be structured with the subsections 'Purpose', 'Methods', 'Results' and 'Conclusions'. Summarise the main conclusions pertaining to your objectives. Do not overemphasise significant results that weren't central to the objectives of your study.""",\
"none":"Your Abstract wasn't checked for subheadings"},\

}