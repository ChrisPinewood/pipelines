other_heading_texts_dict = {

"acknowledgements_h":\
{"pass":"You have included an acknowledgements section",\
"fail":"Have you included an acknowledgements section?",\
"explain":"""Your manuscript should include an 'Acknowledgements' section where you mention others who helped you, but who did not meet the criteria for authorship. OPO asks that you include funding information in this section, including grant codes. 

If you already have that section, make sure the heading is spelled correctly and doesn't have any strange formatting.

[Learn more about authorship and acknowledging non-authors](http://www.icmje.org/recommendations/browse/roles-and-responsibilities/defining-the-role-of-authors-and-contributors.html#three).
[Advice for industry-sponsore studies](http://www.icmje.org/ and GPP2 guidelines for industry-sponsored studies).""",\
"none":"It wasn't possible to check your manuscript for an Acknowledgements section"},\

"conflicting_interests_h":\
{"pass":"You have included a disclosure section",\
"fail":"Have you included a disclosure section?",\
"explain":"""Your manuscript should include a 'Disclosure' section where you declare any potential conflict of interest. 

Your disclosure section should include any association with a commercial organisation or any financial interest in a product that may give rise to the perception of a potential conflict of interest. 

Indicate if the sponsors had any specific role in the production of the paper (e.g.involvement in writing, analysis, or control over publication). 

If there are no conflicts of interest, state: 'The authors report no conflicts of interest and have no proprietary interest in any of the materials mentioned in this article.'""",\
"none":"It wasn't possible to check your manuscript for a Conflicts of Interest section"},\

"data_statement_h":\
{"pass":"You have included a data statement section",\
"fail":"Have you included a data statement section?",\
"explain":"""Your manuscript should have a 'Data Statement' where you explain how the raw data underlying your results can be accessed. Typically this involves publishing your raw data in a suitable data repository and then citing it.""",\
"none":"It wasn't possible to check your manuscript for a Data Statement section"},\

"funding_statement_h":\
{"pass":"You have included a section about funding",\
"fail":"Have you included a funding statement section?",\
"explain":"""You should have a section titled 'Funding Statement' where they explain who funded the research, and give grant reference codes.""",\
"none":"It wasn't possible to check your manuscript for a Funding section"}
}