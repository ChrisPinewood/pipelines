pass_text = "You have cited the {0} guidelines"
fail_text = "Have you cited the {0} guidelines?"

explain_url_dict = {
"consort":"http://www.equator-network.org/reporting-guidelines/consort/", 
"arrive":"http://www.equator-network.org/reporting-guidelines/improving-bioscience-research-reporting-the-arrive-guidelines-for-reporting-animal-research/", 
"prisma":"http://www.equator-network.org/reporting-guidelines/prisma/", 
"moose":"http://www.equator-network.org/reporting-guidelines/meta-analysis-of-observational-studies-in-epidemiology-a-proposal-for-reporting-meta-analysis-of-observational-studies-in-epidemiology-moose-group/", 
"entreq":"http://www.equator-network.org/reporting-guidelines/entreq/", 
"care":"http://www.equator-network.org/reporting-guidelines/care/", 
"srqr":"http://www.equator-network.org/reporting-guidelines/srqr/", 
"strobe":"http://www.equator-network.org/reporting-guidelines/strobe/", 
"stard":"http://www.equator-network.org/reporting-guidelines/stard/", 
"remark":"http://www.equator-network.org/reporting-guidelines/reporting-recommendations-for-tumour-marker-prognostic-studies-remark/", 
"tripod":"http://www.equator-network.org/reporting-guidelines/tripod-statement/"
}

checklist_url_dict = {
"consort":"http://www.equator-network.org/wp-content/uploads/2013/09/CONSORT-2010-Checklist-MS-Word.doc", 
"arrive":"http://www.nc3rs.org.uk/arrive-guidelines", 
"prisma":"http://www.equator-network.org/wp-content/uploads/2013/09/PRISMA-2009-Checklist-MS-Word.doc", 
"moose":"http://www.equator-network.org/reporting-guidelines/meta-analysis-of-observational-studies-in-epidemiology-a-proposal-for-reporting-meta-analysis-of-observational-studies-in-epidemiology-moose-group/", 
"entreq":"http://www.equator-network.org/reporting-guidelines/entreq/", 
"care":"http://www.care-statement.org/downloads/CAREchecklist-English.docx", 
"srqr":"http://www.equator-network.org/reporting-guidelines/srqr/", 
"strobe":"http://www.equator-network.org/wp-content/uploads/2013/09/STROBE-Checklist-v4-MS-Word.doc", 
"stard":"http://www.equator-network.org/wp-content/uploads/2015/03/STARD-2015-checklist.pdf", 
"remark":"http://www.equator-network.org/reporting-guidelines/reporting-recommendations-for-tumour-marker-prognostic-studies-remark/", 
"tripod":"http://www.tripod-statement.org/Portals/0/Documents/TRIPOD/Tripod%20checklist/Checklist_v2_090215.docx"
}

reference_dict = {
"consort":"""Schulz KF, Altman DG, Moher D, for the CONSORT Group. CONSORT 2010 Statement: updated guidelines for reporting parallel group randomised trials.
Ann Int Med. 2010;152(11):726-32. PMID: [20335313](http://www.ncbi.nlm.nih.gov/pubmed/20335313)""", 
"arrive":"""Kilkenny C, Browne WJ, Cuthill IC, Emerson M, Altman DG. Improving bioscience research reporting: the ARRIVE guidelines for reporting animal research.
PLoS Biol. 2010;8(6):e1000412. PMID: [20613859](http://www.ncbi.nlm.nih.gov/pubmed/20613859)""", 
"prisma":"""Moher D, Liberati A, Tetzlaff J, Altman DG, The PRISMA Group. Preferred Reporting Items for Systematic Reviews and Meta-Analyses: The PRISMA Statement.
PLoS Med. 2009; 6(7):e1000097.  PMID: [19621072](http://www.ncbi.nlm.nih.gov/pubmed/19621072)""", 
"moose":"""Stroup DF, Berlin JA, Morton SC, Olkin I, Williamson GD, Rennie D, Moher D, Becker BJ, Sipe TA, Thacker SB. Meta-analysis of observational studies in epidemiology: a proposal for reporting. Meta-analysis Of Observational Studies in Epidemiology (MOOSE) group. 
JAMA. 2000; 283(15):2008-2012. PMID: [10789670](http://www.ncbi.nlm.nih.gov/pubmed/10789670)""", 
"entreq":"""Tong A, Flemming K, McInnes E, Oliver S, Craig J. Enhancing transparency in reporting the synthesis of qualitative research: ENTREQ. 
BMC Med Res Methodol. 2012;12(1):181. PMID: [23185978](http://www.ncbi.nlm.nih.gov/pubmed/23185978)""", 
"care":"""Gagnier JJ, Kienle G, Altman DA, Moher D, Sox H, Riley D; the CARE Group. The CARE Guidelines: Consensus-based Clinical Case Reporting Guideline Development.
BMJ Case Rep. 2013; doi: 10.1136/bcr-2013-201554 PMID: [24155002](http://www.ncbi.nlm.nih.gov/pubmed/24155002)""", 
"srqr":"""O'Brien BC, Harris IB, Beckman TJ, Reed DA, Cook DA. Standards for reporting qualitative research: a synthesis of recommendations. 
Acad Med. 2014; 89(9):1245-1251 PMID: [24979285](http://www.ncbi.nlm.nih.gov/pubmed/24979285)""", 
"strobe":"""von Elm E, Altman DG, Egger M, Pocock SJ, Gotzsche PC, Vandenbroucke JP. The Strengthening the Reporting of Observational Studies in Epidemiology (STROBE) Statement: guidelines for reporting observational studies.
Ann Intern Med. 2007; 147(8):573-577. PMID: [17938396](http://www.ncbi.nlm.nih.gov/pubmed/17938396)""", 
"stard":"""Bossuyt PM, Reitsma JB, Bruns DE, Gatsonis CA, Glasziou PP, Irwig L, LijmerJG Moher D, Rennie D, de Vet HCW, Kressel HY, Rifai N, Golub RM, Altman DG, Hooft L, Korevaar DA, Cohen JF, For the STARD Group. STARD 2015: An Updated List of Essential Items for Reporting Diagnostic Accuracy Studies.
BMJ. 2015;351:h5527. PMID: [26511519](http://www.ncbi.nlm.nih.gov/pubmed/26511519)""", 
"remark":"""McShane LM, Altman DG, Sauerbrei W, Taube SE, Gion M, Clark GM. REporting recommendations for tumour MARKer prognostic studies (REMARK). 
Br J Cancer. 2005;93(4):387-391. PMID: [16106245](http://www.ncbi.nlm.nih.gov/pubmed/16106245)""", 
"tripod":"""Collins GS, Reitsma JB, Altman DG, Moons KG. Transparent reporting of a multivariable prediction model for individual prognosis or diagnosis (TRIPOD): The TRIPOD statement.
BMJ 2015; 350:g7594. PMID: [25569120](http://www.ncbi.nlm.nih.gov/pubmed/25569120)"""
}

explaination = """Judging by what you told us about your work, your manuscript needs to adhere to the [{0} reporting guidelines]({1}). Make sure you have addressed all items on the {2} checklist.
Reviewers and editors use this checklist when assessing work, so your manuscript may be returned if you forget to include one of its items. 

In your methods section, state that your manuscript adheres to the {0} guidelines, and then cite them using the following reference:

{3}"""

checklists = [
"consort", 
"arrive", 
"prisma", 
"moose", 
"entreq", 
"care", 
"srqr", 
"strobe", 
"stard", 
"remark", 
"tripod"
]

checklist_citation_texts_dict = {}

for i in checklists:
	d = {i+"_checklist_cited":{
	"pass":pass_text.format(i.upper()),\
	"fail":fail_text.format(i.upper()),\
	"explain":explaination.format(i.upper(), explain_url_dict[i], checklist_url_dict[i], reference_dict[i]),\
	"none":""
	}
	}
	checklist_citation_texts_dict.update(d)