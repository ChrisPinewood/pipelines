# -*- coding: utf-8 -*-

import re
from helpers.parker_regexs import all_regexs as regexs
from helpers.general_fns import find_in_full_text, clean_string
from helpers.test_result import *

main_body_headings = ["methods_h", "results_h", "discussion_h"]
abstract_subheading_headings = ["purpose_h_ab_sub", "methods_h_ab_sub", "results_h_ab_sub", "conclusions_h_ab_sub"]
start_or_end_headings = ["acknowledgements_h", "funding_statement_h", "data_statement_h", "conflicting_interests_h"]


### Main function for Penelope

def tell_penelope_headings(h_dict = None):
	#Now let's tell Penelope the results. Passed = True means the heading was found, else we send back false

	for k in h_dict.keys():
		passed = h_dict[k] is not None
		p1 = h_dict[k].position[0] if h_dict[k] else None
		p2 = h_dict[k].position[1] if h_dict[k] else None
		result = TestResult(k, passed, (p1, p2))
		tell_penelope(result)

# Sub functions

def check_headings(text, mb_hs = main_body_headings, absub_hs = abstract_subheading_headings, s_e_hs = start_or_end_headings):
	h_dict = {}
	raw_headings = extract_headings(text)
	references_h = find_heading_occurance(raw_headings, text, "references_h", -1)

	passed = True if references_h else False
	p1 = references_h.position[0] if references_h else None
	p2 = references_h.position[1] if references_h else None
	result = TestResult("references_h", passed, (p1, p2))
	h_dict.update({"references_h":result})

	abstract_h = find_heading_occurance(raw_headings, text, "abstract_h", 0)
	passed = True if abstract_h else False
	p1 = abstract_h.position[0] if abstract_h else None
	p2 = abstract_h.position[1] if abstract_h else None
	result = TestResult("abstract_h", passed, (p1, p2))
	h_dict.update({"abstract_h":result})

	introduction_h = find_heading_occurance(raw_headings, text, "introduction_h", -1)
	passed = True if introduction_h else False
	p1 = introduction_h.position[0] if introduction_h else None
	p2 = introduction_h.position[1] if introduction_h else None
	result = TestResult("introduction_h", passed, (p1, p2))
	h_dict.update({"introduction_h":result})

	#Now we extract headings from the main body, abstract, and start/ends
	h_dict = extract_main_body_headings(raw_headings, text, mb_hs, h_dict, introduction_h, references_h)
	h_dict = extract_abstract_subheadings(raw_headings, text, absub_hs, h_dict, abstract_h, introduction_h)
	h_dict = find_headings_at_start_or_end(raw_headings, text, s_e_hs, h_dict, introduction_h, h_dict["discussion_h"])

	h_list = []
	h_list += [h_dict[k] for k in start_or_end_headings]
	h_list.append(h_dict["abstract_h"])
	h_list += [h_dict[k] for k in abstract_subheading_headings]
	h_list.append(h_dict["introduction_h"])
	h_list += [h_dict[k] for k in main_body_headings]
	h_list.append(h_dict["references_h"])		
	
	return h_dict, h_list

def extract_main_body_headings(raw_headings, text, headings, h_dict, introduction_h = None, references_h = None):
	# find main body headings
	e = introduction_h.position[0] if introduction_h else None
	l = references_h.position[0] if references_h else None
	for h in headings:
		passed = False
		p1 = None
		p2 = None
		obj = find_heading_occurance(raw_headings, text, h, -1, e, l)
		if obj:
			passed = True
			p1 = obj.position[0]
			p2 = obj.position[1]
		result = TestResult(h, passed, (p1, p2))
		h_dict.update({h:result})

	return h_dict

def extract_abstract_subheadings(raw_headings, text, headings, h_dict, abstract_h = None, introduction_h = None):
	#find abstract subheadings
	for h in headings:
		passed = False
		p1 = None
		p2 = None
		if abstract_h:
			e = abstract_h.position[0]
			l = introduction_h.position[0] if introduction_h else e + 1000
			obj = find_heading_occurance(raw_headings, text, h, 0, e, l)
			if obj:
				passed = True
				p1 = obj.position[0]
				p2 = obj.position[1]
			else:
				p1 = e
				p2 = abstract_h.position[1]
		result = TestResult(h, passed, (p1, p2))
		h_dict.update({h:result})

	return h_dict

def find_headings_at_start_or_end(raw_headings, text, headings, h_dict, introduction_h = None, discussion_h = None):
	# find headings that could occur at the start or end
	e1 = None
	l1 = introduction_h.position[0] if introduction_h else None
	e2 = discussion_h.position[0] if discussion_h else None
	l2 = None
	for h in headings:
		passed = False
		p1 = None
		p2 = None
		# first we'll try and find them at the start
		obj = find_heading_occurance(raw_headings, text, h, 0, e1, l1)
		if not obj:
			obj = find_heading_occurance(raw_headings, text, h, -1, e2, l2)
		if obj:
			passed = True
			p1 = obj.position[0]
			p2 = obj.position[1]
		result = TestResult(h, passed, (p1, p2))
		h_dict.update({h:result})
	return h_dict


def extract_headings(text):
    raw_headings = find_in_full_text(regexs["heading_regex"], text, "headings")
    return raw_headings

def find_heading_occurance(heading_objs, text, heading_to_match, first_or_last = 0, early_start_pos = None, latest_end_point = None):
    e = early_start_pos
    l = latest_end_point
    # first or last should be 0 or -1
    result = None
    poss_headings = match_headings(heading_to_match, heading_objs, text)
    if (e or l):
    	if not e:
    		e = 0
    	if not l:
    		l = len(text) - 1
    	new_headings = [h for h in poss_headings if ((h.position[0] >= e) and (h.position[1]<l))]
    	poss_headings = new_headings
    if poss_headings:
        result = poss_headings[first_or_last]
    return result

def match_headings(heading_to_match, heading_obj_list, text, earliest = 0, latest = None):
	if not latest:
		latest = len(text) - 1
	found = []
	regex = regexs[heading_to_match]
	for h in heading_obj_list:
		if ((h.position[0] >= earliest) and h.position[1] < latest):
			h_text = text[h.position[0]:h.position[1]]
			h_text = clean_string(h_text.strip())
			match = regex.search(h_text)
			if match:
				found.append(h)
	return found


#### Old code


# def fuzzy_match(s1, s2, max_dist = None, stem = None):
# 	print "HAVE DISABLED FUZZY MATCH FOR NOW"
# 	return None

# def fuzzy_match(s1, s2, max_dist=None, stem = stem):
# #     """
# #     Decide if one string matches another, by tokenising and stemming the words, and using edit distance.
# #     :param s1: the string you're interested in
# #     :param s2: the string you are comparing it to
# #     :param max_dist:
# #     :return:
# #     """
#     # Use the NLTK's Porter Stemmer
#     stemmer = stem.PorterStemmer()
#
#     # Tokenise and stem the words
#     s1_words = tokenize.wordpunct_tokenize(s1.lower().strip())
#     normalised_s1 = ' '.join([stemmer.stem(w) for w in s1_words])
#     s2_words = tokenize.wordpunct_tokenize(s2.lower().strip())
#     normalised_s2 = ' '.join([stemmer.stem(w) for w in s2_words])
#
#     # the default max edit distance - half the mean word length of the shortest sentence
#     if not max_dist:
#         min_sent = min(s1_words, s2_words, key=len)
#         max_dist = float(sum(map(len, min_sent))) / float((len(min_sent) * 8 + 1))
#
#     # Check for edit distance match or substring match
#     e_d_match = metrics.edit_distance(normalised_s1, normalised_s2) <= max_dist
#     sub_match = normalised_s1 in normalised_s2
#     if (e_d_match or sub_match):
# 	    print "{0}, {1}, {2}, {3}, {4}, {5}, {6}".format(max_dist, e_d_match, sub_match, s1, len(s1), s2, len(s2))
#     return e_d_match or sub_match
#
# def allocate_abstract_h(heading_obj_list):
# 	sorted_list = sorted(heading_obj_list, key=lambda x: x.position[0], reverse=False)
# 	abstract_h = sorted_list[0]
# 	return abstract_h
#
# def allocate_intro_h(heading_obj_list, ref_h_start_pos):
# 	if heading_obj_list:
# 		if len(heading_obj_list) == 1:
# 			return heading_obj_list[0]
# 		sorted_list = sorted(heading_obj_list, key=lambda x: x.position[0], reverse=True)
# 		for s in sorted_list:
# 			if (s.position[0] < (ref_h_start_pos + 0)):
# 				return s
# 	return None
#
#
# def fuzzy_match_headings(heading_obj_list, ideal_titles, heading_to_match, text):
# 	ideal_headings = ideal_titles[heading_to_match]
# 	for h in heading_obj_list:
# 		h_text = text[h.position[0]:h.position[1]]
# 		h_text = clean_string(h_text.strip())
# 		for ch in ideal_headings:
# 			m = SM(None, h_text, ch).ratio()
# 			if m > 0.9:
# 				found.append(h)
# 	return found
#
# def clean_headings(headings):
#     cleaned_headings = []
#     for h in headings:
#         split_h = h.split(r"\n")
#         for s in split_h:
#             s = s.strip()
#             s = clean_string(s)
#             s = s.lower()
#             cleaned_headings.append(s)
#     return cleaned_headings
