# -*- coding: utf-8 -*-

import re
import scipy.stats as stats
from decimal import Decimal
from helpers.file_fns import *
from helpers.parker_regexs import f_test_regex, p_regex
from helpers.general_fns import *
from helpers.test_result import *

comma_regex = re.compile("[\,\.]$")

## main functions

def tell_penelope_f_tests_match_pvals(text, f_tests = None):
	if not f_tests:
		f_tests = check_f_tests_match_pvals(text)
	for f in f_tests:
		tell_penelope(f)

def check_f_tests_match_pvals(text):
	results = []
	f_tests = extract_and_compute_f_tests(text)
	if not f_tests:
		return results
	for f in f_tests:
		passed = f["pval_correct"]
		p1 = f["obj"].position[0]
		p2 = f["obj"].position[1]
		correct = f["correct_pval_1tail"]
		result = TestResult("correct_f_test", passed, (p1, p2), {"correct":correct})
		results.append(result)
	return results

# sub functions

def extract_f_tests(text):
    f_tests = find_in_full_text(f_test_regex, text, "f_tests")
    return list(f_tests)

def extract_f_test_components(text, f_tests):
	f_test_components = []
	for f in f_tests:
		string = text[f.position[0]:f.position[1]]
		matchgroup = f_test_regex.search(string)
		groupdict = matchgroup.groupdict()
		df1 = groupdict["f_df1"]
		df1 = float(df1.strip())
		df2 = groupdict["f_df2"]
		df2 = float(df2.strip())
		fval = groupdict["f_value"]
		fval = float(comma_regex.sub("", fval).strip())
		pval = groupdict["f_test_p_value"]
		pval = float(comma_regex.sub("", pval).strip())
		operand = groupdict["operand"]
		lower_fval, upper_fval = compute_lower_and_upper_rounding_bounds(abs(fval))
		lower_pval_1tail = compute_correct_pval_1tail_f_test(upper_fval, df1, df2)
		upper_pval_1tail = compute_correct_pval_1tail_f_test(lower_fval, df1, df2)
		exact_pval_1tail = compute_correct_pval_1tail_f_test(fval, df1, df2)
		dp = abs(Decimal(str(pval)).as_tuple().exponent)
		pval_correct = False
		if "=" in operand:
			if ((round(lower_pval_1tail, dp) <= pval) and (pval <= round(upper_pval_1tail, dp))):
				pval_correct = True
		elif (">" in operand or "≥" in operand or "&gt" in operand):
			if (upper_pval_1tail > pval):
				pval_correct = True
		else:
			if (lower_pval_1tail < pval):
				pval_correct = True
		f_test_components.append({
		"obj":f,\
		"df1":float(df1),\
		"df2":float(df2),\
		"fval":float(fval),\
		"pval":float(pval),\
		"operand":operand,\
		"lower_fval":lower_fval,\
		"upper_fval":upper_fval,\
		"pval_dp":dp,\
		"correct_pval_1tail":{"lower":lower_pval_1tail, "upper":upper_pval_1tail, "exact":exact_pval_1tail},\
		"pval_correct":pval_correct
		})
	return f_test_components

# NB we should be computing a range of p values
# because an f value of 1.23 could be anything from 1.225 to 1.2349 so we need to know the p values
# for each of these limits.

def compute_correct_pval_1tail_f_test(fval, df1, df2):
	correct_pval = 1 - stats.f.cdf(fval, df1, df2)
	return correct_pval

def extract_and_compute_f_tests(text):
	f_tests = extract_f_tests(text)
	components = None
	if f_tests:
		components = extract_f_test_components(text, f_tests)
# 		if components:
# 			for c in components:
# 				c.update({"correct_pval_1tail_f_test": compute_correct_pval_1tail_f_test(c["fval"], c["df1"], c["df2"])}) # f tests are always 1 sided
	return components

def get_f_test_details_for_multiple_filepaths(md_filepath_list):
    all_results = {}
    for path in md_filepath_list:
        text = get_full_text_from_md_filepath(path)
        components = extract_and_compute_f_tests(text)
        if components:
			all_results.update({path:components})
    return all_results


def compare_f_tests_multiple_files(all_results):
	for p in all_results.keys():
		if all_results[p]:
			print "checking ", p.split("/")[-1]
			for t in all_results[p]:
				check_f_test(t)

def check_f_test(t):
	operand = t["operand"]
	if operand == "=":
		dp = abs(Decimal(str(t["pval"])).as_tuple().exponent)
		correct_rounded = round(t["correct_pval_1tail_f_test"], dp)
		if round(abs(t["pval"] - correct_rounded), 4) > 0.001:
# 			print "problem with {0}".format(p)
			print "found an incorrect f test: f statistic: {0}, df: {1}, {2} reported pval: {3}, correct pval: {4}".format(t["fval"], t["df1"], t["df2"], t["pval"], correct_rounded)#t["correct_pval_1tail_f_test"])
	if (">" in operand or "<" in operand or "≤" in operand or "≥" in operand):
		if (">" in operand or "≥" in operand):
			if (t["correct_pval_1tail_f_test"] < t["pval"]):
# 				print "found operand in {0}".format(p)
				print "ERROR, correct pvalue is not > {0}".format(t["pval"])
		else:
			if (t["correct_pval_1tail_f_test"] > t["pval"]):
# 				print "found operand in {0}".format(p)
				print "ERROR, correct pvalue is not < {0}".format(t["pval"])

def run_f_test_checks(md_filepath_list):
	a = get_f_test_details_for_multiple_filepaths(md_filepath_list)
	compare_f_tests_multiple_files(a)
