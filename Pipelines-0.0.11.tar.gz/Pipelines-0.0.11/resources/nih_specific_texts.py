nih_specific_texts_dict = {

"power_calculation":\
{"pass":"You have included a power calculation",\
"fail":"Have you explained how you decided what sample size you needed?",\
"explain":"You need to state whether an appropriate sample size was computed when the \
study was being designed and include the statistical method of computation. \
If no power analysis was used, you should include how the sample size was determined.",\
"none":""
},\

"randomisation":\
{"pass":"You have addressed randomisation",\
"fail":"Have you explained how you randomly allocated subjects into experimental groups?",\
"explain":"You need to explain whether samples were randomised and, if so, the method of randomisation",\
"none":""
},\

"blinding":\
{"pass":"You have addressed blinding",\
"fail":"Have you addressed blinding?",\
"explain":"You need to state whether experimenters were blind to group assignment and \
outcome assessment. If your work involved human participants you should also state whether \
they were blinded",\
"none":""
},\

}