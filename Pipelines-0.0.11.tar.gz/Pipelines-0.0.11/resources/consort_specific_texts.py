consort_specific_texts_dict = {

"clinical_trial_registration":\
{"pass":"You have included a trial registration ID",\
"fail":"Have you included your trial registration ID?",\
"explain":"All clinical trials must be registered with an official registry. \
The registry will then give you a unique trial ID which you should include in your manuscript",\
"none":""
},\

"participant_flow_diagram":\
{"pass":"You have included a participant flow diagram",\
"fail":"Have you included a participant flow diagram?",\
"explain":"You should describe the the numbers of participants that were assessed for eligibility, \
randomly assigned to each group, received intended treatment and analysed for the primary outcome. \
In many cases it's easiest to include this as a flow diagram.",\
# You can see <a href = 'https://www.google.co.uk/search?q=consort+participant+flow+diagram&safe=off&source=lnms&tbm=isch&sa=X&ved=0ahUKEwjV1ryU8oDKAhUBoRoKHTZQCJsQ_AUIBygB&biw=1278&bih=593'>\
# examples</a>, use these templates \
# (<a href = 'http://www.consort-statement.org/download/Media/Default/Downloads/CONSORT%202010%20Flow%20Diagram.doc'>MS Word<\a>, \
# <a href = 'http://www.consort-statement.org/download/Media/Default/Downloads/CONSORT%202010%20Flow%20Diagram.pdf'>PDF</a>) \
# or <a href = 'https://www.gliffy.com/'>make your own</a>"
"none":""
},\

"title_keywords_consort":\
{"pass":"Your title states that this is a randomised trial",\
"fail":"Have you included the term 'Randomised Trial' in your title?",\
"explain":"""Scientists and search engines look for specific words in the titles of manuscripts when \
searching for literature. Your title should include the term "Randomised Trial" \
so that other people can find your work easily and know that participants were \
randomly assigned to experimental groups.""",\
"none":""
}

}
