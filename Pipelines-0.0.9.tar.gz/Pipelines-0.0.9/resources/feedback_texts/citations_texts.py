citations_texts_dict = {

"correct_cit_style_used_num":\
{"pass":"Your citations are numerical",\
"fail":"Are your citations numerical?",\
"explain":"You should make sure you are using numbered citations.",\
"none":""},\

"correct_cit_style_used_alpha":\
{"pass":"Your citations follow a harvard system",\
"fail":"Have you used the correct citing style?",\
"explain":"You should make sure your citations follow the Harvard citing style. You should \
reference resources using the name of the authors and year it was published.",\
"none":""},\

"anomaly_cit_style_used":\
{"pass":"All citations are in the correct style",\
"fail":"Is this citation in the correct style?",\
"explain":"You should make sure all citations follow the same style according to journal guidelines",\
"none":""},\

"citation_in_abstract":\
{"pass":"There are no citations in your abstract",\
"fail":"Have you made sure there are no citations in your abstract?",\
"explain":"Your abstract shouldn't have any citations in.",\
"none":""},\

"verify_citation_in_references":\
{"pass":"You've referenced all of your citations",\
"fail":"Have you referenced this citation?",\
"explain":"You should make sure you've provided an entry for this citation in your reference list",\
"none":""},\

"verify_num_citation_seq:numerical_order":\
{"pass":"Your citations are in numerical order",\
"fail":"Is this citation in ascending numerical order?",\
"explain":"You should make sure this citation is part of ascending sequence, and that \
you haven't accidently cited things in the wrong order.",\
"none":""},\

"verify_num_citation_seq:full_sequence":\
{"pass":"Your citations are in continual sequential order",\
"fail":"Are these citations in continual sequential order?",\
"explain":"You should make sure your citations are in a continual \
sequential order, and that you haven't missed out any numbers",\
"none":""}

}