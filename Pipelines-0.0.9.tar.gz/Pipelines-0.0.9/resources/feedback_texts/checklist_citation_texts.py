pass_text = "You have cited the {0} guidelines"
fail_text = "Have you cited the {0} guidelines"

explaination = "From what you told us about your work, it seems that your manuscript must \
adhere to the {0} reporting guidelines. You should make sure you have addressed all items of the \
{0} checklist and then cite the {0} guidelines in your methods section, stating that they \
were used in the writing of your manuscript. As reviewers and editors use this \
checklist when assessing work, your manuscript may be returned if you forget to include one \
of its items"

checklists = [
"consort", 
"arrive", 
"prisma", 
"moose", 
"entreq", 
"care", 
"srqr", 
"strobe", 
"stard", 
"remark", 
"tripod"
]

checklist_citation_texts_dict = {}

for i in checklists:
	d = {i+"_checklist_cited":{
	"pass":pass_text.format(i.upper()),\
	"fail":fail_text.format(i.upper()),\
	"explain":explaination.format(i.upper()),\
	"none":""
	}
	}
	checklist_citation_texts_dict.update(d)