main_headings_texts_dict = {

"abstract_h":\
{"pass":"You have included an abstract",\
"fail":"Have you included an abstract?",\
"explain":"Your manuscript should have a section titled 'Abstract', where you summarise your\
research in 2500 characters or less, including punctuation and spaces. You should \
arrange your abstract under the subheadings of Purpose, Methods, Results and Conclusions. \
Review articles should use the subheadings of Purpose, Recent findings and Summary",\
# http://onlinelibrary.wiley.com/journal/10.1111/(ISSN)1475-1313/homepage/ForAuthors.html
"none":"There was a problem while checking your manuscript for an Abstract section"},\

"introduction_h":\
{"pass":"You have included an introduction",\
"fail":"Have you included an introduction?",\
"explain":"Your manuscript should have a section titled 'Introduction', where you \
succinctly explain the rationale behind your research",\
# http://onlinelibrary.wiley.com/journal/10.1111/(ISSN)1475-1313/homepage/ForAuthors.html
"none":"There was a problem while checking your manuscript for an Introduction section"},\

"methods_h":\
{"pass":"You have included a methods section",\
"fail":"Have you included a methods section?",\
"explain":"Your manuscript should have a section titled 'Methods', where you describe the \
experimental design, subjects used and procedures followed in sufficient detail such that \
others could duplicate the research. You should also include details of ethical standards \
followed where appropriate. ",\
# http://onlinelibrary.wiley.com/journal/10.1111/(ISSN)1475-1313/homepage/ForAuthors.html
"none":"There was a problem while checking your manuscript for a Methods section"},\

"results_h":\
{"pass":"You have included a results section",\
"fail":"Have you included a results section?",\
"explain":"Your manuscript should have a section titled 'Results' where you describe your \
data and statistical analyses with minimal discussion",\
# http://onlinelibrary.wiley.com/journal/10.1111/(ISSN)1475-1313/homepage/ForAuthors.html
"none":"There was a problem while checking your manuscript for a Results section"},\

"discussion_h":\
{"pass":"You have included a discussion section",\
"fail":"Have you included a discussion section?",\
"explain":"Your manuscript should have a section titled 'Discussion' where you \
highlight the key features of the results and their interpretation and do not merely \
reiterate the results. You should also include any limitations of the study.",\
# http://onlinelibrary.wiley.com/journal/10.1111/(ISSN)1475-1313/homepage/ForAuthors.html
"none":"There was a problem while checking your manuscript for a Discussion section"},\

"references_h":\
{"pass":"You have a references section",\
"fail":"Have you got a reference section?",\
"explain":"Your manuscripts should have a section titled 'References' where you list your \
cited resources in numerical order.",\
# http://onlinelibrary.wiley.com/journal/10.1111/(ISSN)1475-1313/homepage/ForAuthors.html
"none":"There was a problem while checking your manuscript for a References section"}

}