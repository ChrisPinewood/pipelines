table_media_texts_dict = {

# "tables_present_if_cited":\
# {"pass":"You've included tables in your manuscript",\
# "fail":"Have you included this table that you've cited?",\
# "explain":"It seems like your article cites a table, but we can't find one in \
# your manuscript. You should make them using the table function in Word, not as an \
# embedded excel table",\
# "none":"It looks like your manuscript doesn't mention any tables"},
# 
# "tables_present_if_legends":\
# {"pass":"You've included tables in your manuscript",\
# "fail":"Have you included the table for this legend?",\
# "explain":"It seems like your article includes table legends, but we can't find any tables in \
# your manuscript. You should make them using the table function in Word, not as an \
# embedded excel table",\
# "none":"It looks like your manuscript doesn't have any table legends"},

"tables_present_if_mentioned":\
{"pass":"You have included tables in this file",\
"fail":"Have you included tables in this file?",\
"explain":"It looks like your article mentions tables, but there don't seem to be any \
tables in this file. You should include all tables in your main manuscript, near to where \
they are first mentioned. You should make the tables using Microsoft Word's table function, \
and not as embedded excel tables or pictures",\
"none":"It looks like your manuscript doesn't mention, or include tables"},

"no_surprise_tables":\
{"pass":"You have referred to the tables you've included",\
"fail":"Does this table have a legend and have you referred to it in your article?",\
"explain":"It looks like your article includes a table, but we can't find a table legend \
or where you refer to it in your article.",\
"none":"It looks like your manuscript doesn't have any tables"},

# "figures_present_if_cited":\
# {"pass":"Manuscript cites, and includes media",\
# "fail":"Have you included all the figures in your manuscript?",\
# "explain":"It seems like your article cites figures, but we can't find any in your\
#  manuscript. You should include them within your article",\
# "none":"It looks like your manuscript doesn't cite any figures"},
# 
# "figures_present_if_legends":\
# {"pass":"Manuscript has figure legends, and includes figures",\
# "fail":"Have you included all the figures in your manuscript?",\
# "explain":"It seems like your article includes figure legends, but we can't find any media in your\
#  manuscript. You should include all media within this file",\
# "none":"It looks like your manuscript doesn't have any figure legends"},

"figures_present_if_mentioned":\
{"pass":"You have included figures in this file",\
"fail":"Have you included figures in this file?",\
"explain":"It looks like your article mentions figures, but have you referred to it \
anywhere else in your article? You should include all figures in this file, near to where they are discussed",\
"none":"It looks like your manuscript doesn't mention, or include figures"},

"no_surprise_figures":\
{"pass":"You have referred to the figures you've included",\
"fail":"Has this figure got a legend, and have you referred to it in your article?",\
"explain":"It looks like your article includes a figure, but we can't find a figure \
legend or where you refer to it in your article.",\
"none":"It looks like your manuscript doesn't have any figures"},

"numerically_ordered_table_c":\
{"pass":"You've mentioned tables in numerical order",\
"fail":"Have you mentioned tables in numerical order?",\
"explain":"Tables must be numbered numerically, in the order they are mentioned in\
 the body of the article",\
"none":"It wasn't possible to check that tables are cited in numerical order, because no table citations were found"
},\

"numerically_ordered_figure_c":\
{"pass":"All figures are mentioned in numerical order",\
"fail":"Have you mentioned all figures in numerical order?",\
"explain":"Figures must be numbered numerically, in the order they are mentioned in the\
 body of the article",\
"none":"It wasn't possible to check that figures are cited in numerical order, because no table citations were found"
},\

"numerically_ordered_table_l":\
{"pass":"Your tables are in the right order",\
"fail":"Are your tabes in the right order?",\
"explain":"Tables and their legends must be ordered numerically, according to the order in which they are mentioned \
in the body of the article",\
"none":"It wasn't possible to check that table legends occur in numerical order, because no table lagends were found"
},\

"numerically_ordered_figure_l":\
{"pass":"Your figures are in the right order",\
"fail":"Are your figures in the right order?",\
"explain":"Figures and their legends must be ordered numerically, according to the order in which they are mentioned \
in the body of the article",\
"none":"It wasn't possible to check that figure legends occur in numerical order, because no figure lagends were found"
},\

"no_missing_table_c":\
{"pass":"You've mentioned every table in the article body",\
"fail":"Have you mentioned this table in the article?",\
"explain":"You must mention all tables in the body of your article. Tables should be \
numbered numerically in the order in which they are first mentioned.",\
"none":"We couldn't crosscheck your table legends and citations because we couldn't find any"
},\

"no_missing_figure_c":\
{"pass":"You've mentioned every figure in the article body",\
"fail":"Have you mentioned this figure in the article?",\
"explain":"You must mention all figures in the body of your article. Figures should be \
numbered numerically in the order in which they are first mentioned.",\
"none":"We couldn't crosscheck your figure legends and citations because we couldn't find any"
},\

"no_missing_table_l":\
{"pass":"Every mentioned table has a table legend",\
"fail":"Have you included a table legend for this table?",\
"explain":"Make sure this table has a table legend, and that both are numbered the same",\
"none":""
},\

"no_missing_figure_l":\
{"pass":"Every mentioned figure has a figure legend",\
"fail":"Have you included a figure legend for this table?",\
"explain":"Make sure this figure has a figure legend, and that both are numbered the same",\
"none":""}

}