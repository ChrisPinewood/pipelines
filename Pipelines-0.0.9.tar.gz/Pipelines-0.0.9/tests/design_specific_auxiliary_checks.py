import re
from helpers.test_result import TestResult

title_keywords_dict_raw = {
"consort":[r"(randomi[sz]ed\s+(control+(ed)?\s+)?trial|\brct\b)"],\
"arrive":[],\
"prisma":[],\
"entreq":[],\
"care":[],\
"srqr":[],\
"strobe":[],\
"stard":[],\
"remark":[],\
"tripod":[]
}

title_keywords_dict = {}
for i in title_keywords_dict_raw.keys():
	title_keywords_dict.update({i : [re.compile(p, flags = re.IGNORECASE) for p in title_keywords_dict_raw[i]]})

def check_title_for_keywords(title, text, type):
	passed = False
	p1 = None
	p2 = None
	title_text = title.match_string(text)
	check_name = "title_keywords_" + type
	if not title_keywords_dict[type]:
		passed = None
	else:
		for i in title_keywords_dict[type]:
			match = i.search(title_text)
			if match:
				passed = True
				p1 = match.start() + title.position[0]
				p2 = match.end() + title.position[1]
				break
	result = TestResult(check_name, passed, (p1, p2))
	return result

def check_for_checklist_citation(type, references, text):
	pattern = re.compile(type, flags = re.IGNORECASE)
	check_name = type + "_checklist_cited"
	passed = False
	p1 = None
	p2 = None
	for ref in references:
		r = ref.match_string(text)
		if pattern.search(r):
			passed = True
			p1 = text.find(r)
			p2 = text.find(r) + len(r)
			break
	checklist_citation = TestResult(check_name, passed, (p1, p2))
	return checklist_citation

def check_for_randomisation(text):
	result = TestResult("randomisation", False, (None, None))
	return result

def check_for_blinding(text):
	result = TestResult("blinding", False, (None, None))
	return result

def check_for_power_calculation(text):
	result = TestResult("power_calculation", False, (None, None))
	return result

def check_for_flow_diagram(text):
	result = TestResult("participant_flow_diagram", False, (None, None))
	return result

##check for risk of bias
# 	print_title("Checking for risk of bias")
# 	print ""
# 	annotations = bot.annotate(text.decode("utf8"))
# 	print_bias_results(annotations)
