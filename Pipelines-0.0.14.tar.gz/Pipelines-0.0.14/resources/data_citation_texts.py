data_citation_texts_dict = {
"has_data_citation":\
{"pass":"You have cited a dataset",\
"fail":"Have you and published and cited your data?",\
"explain":"All original research articles should cite the underlying raw data. You should publish \
your data in a repository, and then cite the dataset in the body of your\
aticle. Make sure you include the citation in your reference list so that, where possible, your manuscript and \
dataset can be linked with a proper citation.\
",\
# </br>You can find out about your funder's data sharing policy <a href = 'http://www.sherpa.ac.uk/juliet/index.php'>here</a>.</br>\
# The <a href = 'http://www.dcc.ac.uk/resources/how-guides'>Data Curation Centre</a> has lots \
# of useful resources for authors that can help you <a href = 'http://www.dcc.ac.uk/resources/how-guides/five-steps-decide-what-data-keep'> decide which data to keep</a>, \
# how to <a href = 'http://www.dcc.ac.uk/resources/how-guides/cite-datasets'>cite your data and link it to your publication</a>, \
# and how to <a href = 'http://www.dcc.ac.uk/resources/how-guides/track-data-impact-metrics'> use metrics to track the impact of your data</a>.
"none":"Your manuscript wasn't checked for a data citation"}
}