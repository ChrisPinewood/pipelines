references_texts_dict = {

"correct_ref_style_used_num":\
{"pass":"Your references are numbered",\
"fail":"Are your references numbered?",\
"explain":"You should make sure your references are in a numbered list. They should \
be ordered according to how they are first mentioned in the text. This journal does not \
accept alphabetic referencing systems",\
"none":""},\

"correct_ref_style_used_alpha":\
{"pass":"Your references aren't numbered",\
"fail":"Have you used the correct referencing style?",\
"explain":"You should make sure your references follow the Harvard referencing style. They should be \
in an alphabetised list, according to the surname of the lead author of each article.",\
"none":""},\

"anomaly_ref_style_used":\
{"pass":"All references are in the correct style",\
"fail":"Is this reference in the correct style?",\
"explain":"You should make sure all references follow the same style - \
either alphabetic or numerical - according to journal guidelines",\
"none":""},\

"verify_references_in_citations":\
{"pass":"You've cited all your references",\
"fail":"Have you cited this reference?",\
"explain":"You should make sure you've mentioned this reference in your article, and \
cited it properly",\
"none":""},\

"verify_num_reference_seq:numerical_order":\
{"pass":"Your references are in numerical order",\
"fail":"Are these references in ascending numerical order?",\
"explain":"You should make sure each item in your reference list is numbered in increasing \
sequential order",\
"none":""},\

"verify_num_reference_seq:full_sequence":\
{"pass":"Your references are in continual numerical order",\
"fail":"Are these references in continuous sequential order?",\
"explain":"You should make sure each item in your reference list is numbered in increasing \
sequential order, and that you haven't missed out any numbers",\
"none":""},\

"verify_num_reference_seq:duplicate_numbers":\
{"pass":"Your references are in numerical order",\
"fail":"Is this reference number duplicated?",\
"explain":"You should make sure each item in your reference list is numbered in increasing \
sequential order, and that you only use each number once",\
"none":""},\

"verify_num_reference_seq":\
{"pass":"Your references are in numerical order",\
"fail":"Are your references in numerical order?",\
"explain":"You should make sure each item in your reference list is numbered in increasing \
sequential order",\
"none":""}

}