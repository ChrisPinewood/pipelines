abstract_subheading_texts_dict = {

"purpose_h_ab_sub":\
{"pass":"You have a subsection called 'Purpose' in your abstract",\
"fail":"Have you included a subsection called 'Purpose' in your abstract?",\
"explain":"Abtracts should be structured with the subsections 'Purpose', 'Methods', 'Results' and 'Conclusions'",\
"none":"Your Abstract wasn't checked for subheadings"},\

"methods_h_ab_sub":\
{"pass":"You have a subsection called 'Methods' in your abstract",\
"fail":"Have you included a subsection called 'Methods' in your abstract?",\
"explain":"Abtracts should be structured with the subsections 'Purpose', 'Methods', 'Results' and 'Conclusions'",\
"none":"Your Abstract wasn't checked for subheadings"},\

"results_h_ab_sub":\
{"pass":"You have a subsection called 'results' in your abstract",\
"fail":"Have you included a subsection called 'Results' in your abstract?",\
"explain":"Abtracts should be structured with the subsections 'Purpose', 'Methods', 'Results' and 'Conclusions'",\
"none":"Your Abstract wasn't checked for subheadings"},\

"conclusions_h_ab_sub":\
{"pass":"You have a subsection called 'conclusions' in your abstract",\
"fail":"Have you included a subsection called 'Conclusions' in your abstract?",\
"explain":"Abtracts should be structured with the subsections 'Purpose', 'Methods', 'Results' and 'Conclusions'",\
"none":"Your Abstract wasn't checked for subheadings"},\

}