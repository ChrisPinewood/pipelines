from resources.test_messages import msgs
import time

def print_error(msg_dict):
	print colors.WARNING + msg_dict["fail"] + colors.ENDC
	print msg_dict["explain"]

def print_ok(msg_dict):
	print colors.OKGREEN + msg_dict["pass"] + colors.ENDC

def print_none(msg_dict):
	print colors.OKBLUE + msg_dict["none"] + colors.ENDC

def print_na(string):
	print colors.OKBLUE + string + colors.ENDC

def print_title(string):
# 	print "\n"
# 	time.sleep(0.5)
	print (colors.BOLD + string + colors.ENDC),

def print_section(string):
	print "\n"
	print colors.UNDERLINE + colors.BOLD + string + colors.ENDC
	print ""

def print_obj_text(obj, text, context = True):
	if not obj.position[0]:
		pass
	else:
		a = 10
		match_text = text[obj.position[0]:obj.position[1]]
		if not context:
			a = 0
		start = obj.position[0]
		if match_text.splitlines()[0]:
			start = obj.position[0]-a
		if start < 0:
			start = 0
		start_text = text[start:obj.position[0]]
		if start_text:
			start_text = start_text.splitlines()[-1] + " "
		end = obj.position[1]
		if match_text.splitlines()[-1].strip():
			end = obj.position[1]+a
		if end > len(text):
			end = len(text) - 1
		end_text = text[obj.position[1]:end]
		if end_text:
			end_text = " " + end_text.splitlines()[0]
		text_to_return = text[start:end]
		text_to_return = start_text + match_text.strip() + end_text
		print colors.GREY + text_to_return + colors.ENDC
		if obj.data:
			if obj.data.get("other_citation_start"):
				start = obj.data["other_citation_start"] - a
				end = obj.data["other_citation_end"] + a
				print colors.GREY + text[start:end] + colors.ENDC

def print_TestResult_False_is_bad(TR, text, print_text = True):
	try:
		if TR.passed:
			print_ok(msgs[TR.test])
		elif (type(TR.passed) == bool):
			print_error(msgs[TR.test])
			if print_text:
				print_obj_text(TR, text)
		else: #elif (str(TR.passed) == "null"):
			print_none(msgs[TR.test])
	except:
		print "couldn't print this: ", TR




def print_heading_result(h, match, text):
	if match:
		print_ok(msgs[h])
	else:
		print_error(msgs[h])


def print_result_email(email, text):
	if email:
		print_ok(msgs["email"])
		for e in email:
			print_obj_text(e, text)
	else:
		print_error(msgs["email"])

def print_results_abstract(abstract_h, text):
	if abstract_h:
		print_ok(msgs["abstract_h"])
	else:
		print_error(msgs["abstract_h"])

def print_results_reference_section(ref_h, text):
	if ref_h:
		print_ok(msgs["ref_h"])
	else:
		print_error(msgs["ref_h"])

def print_results_data_citation(has_data):
	if has_data:
		print_ok(msgs["has_data_citation"])
	else:
		print_error(msgs["has_data_citation"])

def print_results_consort_citation(has_data):
	if has_data:
		print_ok(msgs["consort"])
	else:
		print_error(msgs["consort"])

def print_results_consent(has_consent, text):
	if has_consent:
		print_ok(msgs["consent"])
		for i in has_consent:
			print_obj_text(i, text)
	else:
		print_error(msgs["consent"])

def print_results_helsinki(has_helsinki, text):
	if has_helsinki:
		print_ok(msgs["helsinki"])
		for i in has_helsinki:
			print_obj_text(i, text)
	else:
		print_error(msgs["helsinki"])

def print_results_arrive_citation(has_arrive):
	if has_arrive:
		print_ok(msgs["arrive"])
	else:
		print_error(msgs["arrive"])

def print_results_arvo(has_arvo, text):
	if has_arvo:
		print_ok(msgs["arvo"])
		for i in has_arvo:
			print_obj_text(i, text)
	else:
		print_error(msgs["arvo"])

def print_results_equator_citation(has_data):
	if has_data:
		print_ok(msgs["equator"])
	else:
		print_error(msgs["equator"])

def print_bad_inequalities_results(pvals, text):
	bad_pvals = []
	for p in pvals:
		if not p.passed:
			bad_pvals.append(p)
	if bad_pvals:
		print_error(msgs["pval_as_equalities"])
		for i in bad_pvals:
# 			print i.match_string(text)
			print_obj_text(i, text)
	else:
		print_ok(msgs["pval_as_equalities"])

def print_badly_reported_t_tests(badly_reported_t_tests, t_tests, text):
	if not badly_reported_t_tests:
		print_ok(msgs["t_tests_reported_well"])
	else:
		for t in badly_reported_t_tests:
			if t.passed:
				print_error(msgs["t_tests_reported_well"])
				print_obj_text(t, text)
			else:
				if t_tests:
					print_ok(msgs["t_tests_reported_well"])
				else:
					print_na("found no t-tests")

def print_badly_reported_f_tests(badly_reported_f_tests, f_tests, text):
	if not badly_reported_f_tests:
		print_ok(msgs["f_tests_reported_well"])
	else:
		for t in badly_reported_f_tests:
			if t.passed:
				print_error(msgs["f_tests_reported_well"])
				print_obj_text(obj, text)
			else:
				if f_tests:
					print_ok(msgs["f_tests_reported_well"])
				else:
					print_na("found no f-tests")


def print_t_tests_results(t_tests, text):
	if not t_tests:
		return None
	errors = False
	only_2_tailed = True
	if type(t_tests)!=list:
		t_tests = [t_tests]
	for t in t_tests:
		if not t.data["pval_correct"]:
			dp = t.data["pval_dp"]
			print_error(msgs["t_test"])
			print_obj_text(t.data["obj"], text)
			print "With a t statistic between {0} an {1} and {2} degrees of freedom, your p value".format(t.data["lower_tval"], t.data["upper_tval"], t.data["df"])
			print "should lie between {0} and {1} for a 2 tailed test, or between {2} and {3} for a 1 tailed test".format(\
			round(t.data["correct_pval_2tail"]["lower"], dp+1), round(t.data["correct_pval_2tail"]["upper"], dp+1),\
			round(t.data["correct_pval_1tail"]["lower"], dp+1), round(t.data["correct_pval_1tail"]["upper"], dp+1))
		else:
			if t.data["one_tail_pval"]:
				if t.data["one_tail_mention"]:
					print_ok(msgs["one_tailed_t_test"])
					only_2_tailed = False
				else:
					print_error(msgs["one_tailed_t_test"])
					errors = True
	if only_2_tailed:
		print_ok(msgs["two_tailed_t_test"])
	if t_tests and not errors:
		print_ok(msgs["t_test"])

def print_f_test_results(f_tests, text):
	if not f_tests:
		return None
	errors = False
	for f in f_tests:
		if not f["pval_correct"]:
			dp = f["pval_dp"]
			print_error(msgs["f_test"])
			print_obj_text(f["obj"], text)
			print "With an f statistic between {0} and {1} and degrees of freedom of {2} and {3},".format(f["lower_fval"], f["upper_fval"], f["df1"], f["df2"])
			print "your p value should lie between {0} and {1}".format(round(f["correct_pval_1tail"]["lower"], dp), round(f["correct_pval_1tail"]["upper"], dp))
			errors = True
	if not errors:
		print_ok(msgs["f_test"])

def print_r_test_results(r_tests, text):
	if not r_tests:
		return None
	errors = False
	for r in r_tests:
		if not r["pval_correct"]:
			dp = r["pval_dp"]
			print_error(msgs["r_test"])
			print_obj_text(r["obj"], text)
			print "With {0} degrees of freedom and an r value of between {1} and {2}".format(r["df"], r["lower_rval"], r["upper_rval"])
			print "your p-value should lie between {0} and {1}".format(round(r["correct_pval_2tail"]["lower"], dp), round(r["correct_pval_2tail"]["upper"], dp))
			errors = True
	if not errors:
		print_ok(msgs["r_test"])

def print_badly_reported_r_tests(bad_r_tests, text):
	if not bad_r_tests:
		print_ok(msgs["r_tests_reported_well"])
	else:
		print_error(msgs["r_tests_reported_well"])
		for obj in bad_r_tests:
			print_obj_text(obj, text)

def print_table_dashes_results(table_dashes, text, table_mentions):
	if table_dashes:
		print_ok(msgs["tables_present"])
	else:
		print_error(msgs["tables_present"])
		for t in table_mentions:
			print_obj_text(t, text)

def print_surprise_table(table_dashes):
	if table_dashes:
		print_error(msgs["surprise_table"])
	else:
		print_ok(msgs["surprise_table"])

def print_extracted_media_results(extracted_media, text, figure_mentions):
	if extracted_media:
		print_ok(msgs["media_present"])
	else:
		print_error(msgs["media_present"])
		for f in figure_mentions:
			print_obj_text(f, text)

def print_surprise_media(extracted_media):
	if extracted_media:
		print_error(msgs["surprise_media"])
	else:
		print_ok(msgs["surprise_media"])

def print_out_of_order_table_c(out_of_order_table_c, text):
	problems = []
	for i in out_of_order_table_c:
		if i.passed:
			problems.append(i)
	if problems:
		print_error(msgs["out_of_order_table_c"])
		for i in problems:
			print "-"
			print_obj_text(i, text)
	else:
		print_ok(msgs["out_of_order_table_c"])

def print_out_of_order_figure_c(out_of_order_figure_c, text):
	problems = []
	for i in out_of_order_figure_c:
		if i.passed:
			problems.append(i)
	if problems:
		print_error(msgs["out_of_order_figure_c"])
		for i in problems:
			print "-"
			print_obj_text(i, text)
	else:
		print_ok(msgs["out_of_order_figure_c"])

def print_out_of_order_table_l(out_of_order_table_l, text):
	problems = []
	for i in out_of_order_table_l:
		if i.passed:
			problems.append(i)
	if problems:
		print_error(msgs["out_of_order_table_l"])
		for i in problems:
			print "-"
			print_obj_text(i, text)
	else:
		print_ok(msgs["out_of_order_table_l"])

def print_out_of_order_figure_l(out_of_order_figure_l, text):
	problems = []
	for i in out_of_order_figure_l:
		if i.passed:
			problems.append(i)
	if problems:
		print_error(msgs["out_of_order_figure_l"])
		for i in problems:
			print "-"
			print_obj_text(i, text)
	else:
		print_ok(msgs["out_of_order_figure_l"])

def print_missing_table_c(missing_table_c, text):
	problems = []
	for i in missing_table_c:
		if i.passed:
			problems.append(i)
	if problems:
		print_error(msgs["missing_table_c"])
		for i in problems:
			print_obj_text(i, text)
	else:
		print_ok(msgs["missing_table_c"])

def print_missing_figure_c(missing_figure_c, text):
	problems = []
	for i in missing_figure_c:
		if i.passed:
			problems.append(i)
	if problems:
		print_error(msgs["missing_figure_c"])
		for i in problems:
			print_obj_text(i, text)
	else:
		print_ok(msgs["missing_figure_c"])

def print_missing_table_l(missing_table_l, text):
	problems = []
	for i in missing_table_l:
		if i.passed:
			problems.append(i)
	if problems:
		print_error(msgs["missing_table_l"])
		for i in problems:
			print_obj_text(i, text)
	else:
		print_ok(msgs["missing_table_l"])

def print_missing_figure_l(missing_figure_l, text):
	problems = []
	for i in missing_figure_l:
		if i.passed:
			problems.append(i)
	if problems:
		print_error(msgs["missing_figure_l"])
		for i in problems:
			print_obj_text(i, text)
	else:
		print_ok(msgs["missing_figure_l"])

def print_bias_results(annotations):
	for i in annotations["marginalia"]:
		print_title("Checking for mention of " + i["title"].lower())
		if i["description"].endswith("high/unclear"):
			print_error(msgs[i["title"]])
		if i["description"].endswith("low"):
			print_ok(msgs[i["title"]])
			for s in i["annotations"]:
				print colors.GREY + s["content"] + colors.ENDC

def print_results_clinical_trial_registration(registration, text):
	if registration:
		print_ok(msgs["clinical_trial_registration"])
# 		for r in registration:
# 			print_obj_text(r, text)
	else:
		print_error(msgs["clinical_trial_registration"])



class colors:
    HEADER = '\033[95m'
    OKBLUE = '\033[94m'
    OKGREEN = '\033[92m'
    GREY = '\033[90m'
    AQUA = '\033[96m'
    WARNING = '\033[93m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'
