# -*- coding: utf-8 -*-
import re
from registry_regexs import registry_regex_dict


## to strip non-word characters from the start/end of strings
stripping_pattern = re.compile(r"(^\W+|\W+$)")
strip_punc_pattern = re.compile(r"[^a-zA-Z0-9_\s]")
strip_punc_pattern_start_and_end = re.compile(r"(^[^a-zA-Z0-9_\s]+|[^a-zA-Z0-9_\s]+$)")


### general words
and_words = r"(\s*(&|and|nd\.|\/|\+)\s*)" # captures "and" variations
cont = r"(\s*(continued|continues|cont\.|cont|conts\.|conts)\s*)" # captures "continued" variations

########## GENERAL HEADINGS REGEX

## Make regex for formatted headings
formatted_headings = re.compile(r"[\*\#\_]+(?:\s)?.{2,200}?(?:\s)?[\*\#\_]+", flags = re.DOTALL)

## Make regex for unformatted headings
## First we accept more than just a new line. Some authors label headings with 
## an asterix, hash, or a superscript symbol or html inside <>
# start_of_line = r"^\s*(?:\*|\#|\[|(<.+?>)(\.{0,3}<.+?>)*|\d[\)\.\d]*|(?:\!\[\]\(.*\)))*" # deleted this because it was taking too long
triangles = r"(<.*>)[(.*{0,10})<.*>|<.*>]*" # this is to catch stuff in html
start_of_line = r"^\s*(?:\*|\#|\[|"+triangles+"|\d[\)\.\d]*|(?:\!\[\]\(.*\)))*"
end_of_heading = r"[:;.!?\n]"
short_headings = re.compile(start_of_line+r"[\w\d\s\-'–]{4,50}?"+end_of_heading)

## Put heading regex together
heading_regex = re.compile(r"(?:{0}|{1})".format(formatted_headings.pattern, short_headings.pattern), flags=re.MULTILINE)



########## GENERAL CITATIONS REGEX

# Regex for superscript citations
sup = r"(<sup>[\\-\d,\s–]+</sup>)"

### title line

title_regex = re.compile(r"[^\n]{30,200}")

########## SECTIONS
# write regexs for specific section titles here. use _h at the end of the variable name
# to denote heading

title_h = re.compile(r"^title", flags = re.IGNORECASE)
running_head_h = re.compile(r"(Running\s*Head|Running\s*Title|Alternative\s*Head|Alternative\s*Title)", flags = re.IGNORECASE)
authors_h = re.compile(r"(^Authors*\s+(?!affiliation|contribution)|List\s*of\s*Authors)", flags = re.IGNORECASE)
corresponding_author_h = re.compile(r"(send|ad+res+\s+)*(Cor+espond([ea]nce|ing)\s*(author|to)|E[\-\s+]Mail)", flags = re.IGNORECASE)
word_count_h = re.compile(r"(Word\s*Counts?|Words)", flags = re.IGNORECASE)
key_words_h = re.compile(r"(key\s+words|mesh)", flags = re.IGNORECASE)
author_Statement_h = re.compile(r"(Authors?\s*(Statements?|contributions?))", flags = re.IGNORECASE)
conflicting_interests_h = re.compile(r"^(declarations?\s*|statements?\s*)of\s*(compete?ing|conflicting)?\s*interests?|(compete?ing|conflict[sing]*)\s*interests?|disclosure|conflicts?\s*of\s*interests?", flags = re.IGNORECASE)
data_statement_h = re.compile(r"(data\s*statement|data\s*access\s*statement|data\s*availability\s*statement)", flags = re.IGNORECASE)
funding_statement_h = re.compile(r"(Sources?\s*of\s*Funding|Funding)", flags = re.IGNORECASE)
abstract_h = re.compile(r"(Abstract|executive\ssummary)", flags = re.IGNORECASE)
purpose_h = re.compile(r"(purpose)", flags = re.IGNORECASE)
introduction_h = re.compile(r"(Introduction|background|rationale|purpose)", flags = re.IGNORECASE)
methods_h = re.compile(r"^(research\s*)?(Methods?|Materials?\s*and\s*Methods?|Methods?\s*and\s*Materials?\s*)", flags = re.IGNORECASE)
results_h = re.compile(r"(^(analys[ei]s\s(and|&)\s)?results?)", flags = re.IGNORECASE)
discussion_h = re.compile(r"(Discus+ion)", flags = re.IGNORECASE)
conclusions_h = re.compile(r"(conclusions?)", flags = re.IGNORECASE)
references_h = re.compile(r"(^References|bib+liography)", flags = re.IGNORECASE)
acknowledgements_h = re.compile(r"(A[ck]+no[wledge]+ments?)", flags = re.IGNORECASE)
appendix_h = re.compile(r"(Appendix|Sup+l[ie]ment(ary)?\s*(info(rmation)?|files?|materials?|videos?))", flags = re.IGNORECASE)
# specifically for matching the section heading for tables/figures. Not for matching Legends/mentions
table_string =  r"((sup+l[ie]ment[ea]ry\s+)?\bTables?\s*(?P<identifier>\d+(\s(\,\s\d\s)?))"+and_words+"\s\(?P<second_identifier>\d+(\s(\,\s\d\s)?))?)" 
identifier = r"\d[\d\.\,\-]*[a-z]?\b\s*"
table_string = r"(sup+l[ie]ment[ea]ry\s+)?\s*tables?\s*(?P<identifier>"+identifier+")+(\s*"+and_words+"\s*(?P<identifier2>"+identifier+"))?"
figure_string = r"(sup+l[ie]ment[ea]ry\s+)?\b(Figures?|Fig\.|Fig)s?\s*(?P<identifier>"+identifier+")+(\s*"+and_words+"\s(?P<identifier2>"+identifier+"))?"
legend_h = re.compile(start_of_line + r"(\bLegends?|captions?)", flags = re.IGNORECASE)
tables_h = re.compile(start_of_line + table_string, flags = re.IGNORECASE)
figures_h = re.compile(start_of_line + figure_string, flags = re.IGNORECASE)

# items from full text
email_regex = re.compile(r"\w+@\w+\.\w+", flags = re.IGNORECASE)
email_regex = re.compile(r"\S+@[^\s]+\.\w+")
university = re.compile(r"university", flags = re.IGNORECASE)
antibody_regex = re.compile(r"antibod(?:y|ies)", flags = re.IGNORECASE)
rrid_regex = re.compile(r"rrid:", flags = re.IGNORECASE)

# design specific items
informed_consent_regex = re.compile(r"((informed|patient)\s+consent|consent\s*was\s*(given|provided)|gave\s*(their\s*)?consent)", flags = re.IGNORECASE)
declaration_of_helsinki_regex = re.compile(r"deck?l[ea]ration\s*of\shel+sinki", flags = re.IGNORECASE)
ethics_regex = re.compile(r"ethic", flags = re.IGNORECASE)
arvo_regex = re.compile(r"\barvo\b", flags = re.IGNORECASE)
PRISMA_regex = re.compile(r"\bprisma\b", flags = re.IGNORECASE)
MOOSE_regex = re.compile(r"\bmoose\b", flags = re.IGNORECASE)
ARRIVE_regex = re.compile(r"\barrive\s*(guidelines|rec+om+endations?|statement)", flags = re.IGNORECASE)
ENTREQ_regex = re.compile(r"\bentreq\b", flags = re.IGNORECASE)
CARE_regex = re.compile(r"\bcare\s*(guidelines|rec+om+endations?|statement)", flags = re.IGNORECASE)
SRQR_regex = re.compile(r"\bsrqr\b", flags = re.IGNORECASE)
CONSORT_regex = re.compile(r"\bconsort\b", flags = re.IGNORECASE)
STROBE_regex = re.compile(r"\bstrobe\b", flags = re.IGNORECASE)
STARD_regex = re.compile(r"\bstard\b", flags = re.IGNORECASE)
REMARK_regex = re.compile(r"\bremark\s*(guidelines|rec+om+endations?|statement)\b", flags = re.IGNORECASE)
TRIPOD_regex = re.compile(r"\btripod\b", flags = re.IGNORECASE)

# table or figure mentions in the body of the text in general, will catch headings and non headings
tables_m = re.compile(table_string, flags = re.IGNORECASE)
figures_m = re.compile(figure_string, flags = re.IGNORECASE)
# specifically for matching legends (which don't follow the standard heading extraction route)
start_of_line_for_legends = re.sub(r"\^", r"\n", start_of_line)
table_l_len = "200" # maximum legend length that we consider (might be different to the maximum length dictated by the journal
figure_l_len = "200"
tables_l = re.compile(r"" + start_of_line_for_legends+table_string + r"[\s\n]?[^\|\n]{0,"+table_l_len+"}\n", flags = re.IGNORECASE)
figures_l = re.compile(r"" + start_of_line_for_legends+figure_string + r"[\s\n]?[^\|\n]{0,"+figure_l_len+r"}\n", flags = re.IGNORECASE)

# citation regexs
name_prefix = r"\b(?:(?:[vV][oa]n(?:\s?t|\s+[dD]e[rn]?|\s+het)?|op(?:\s+het|\s+t)|v\/d|de)\s+|[OoDd]\'|[Mm]a?c)"
names = name_prefix + r"?([A-Z][a-z,-]+(?:[ +,.;&]|and|et al)*)"
organisation = r"\b[A-Z]+\s"
apa_date = r"(18|19|20)\d{2}"
apa_citations = r"(?:%s+|%s),?\(?" % (names, organisation,)
apa_citations = apa_citations + apa_date+"[A-Za-z]?(?:;? ?"+apa_date+"[A-Za-z]?)*"
apa_citation_regex = re.compile(apa_citations) # NB don't ignore case here

# num_citation_regex
num_citation = r'[-\d,; –\s]+'
sq_br_num_citations = r"\["+num_citation+"\]"
br_num_citations = r"\("+num_citation+"\)"
curl_br_num_citations = r"\{"+num_citation+"\}"
curly_brackets_citation = r"("+br_num_citations+"|"+curl_br_num_citations+")"
square_bracket_citation_regex = re.compile(sq_br_num_citations) # NB don't ignore case here
curly_bracket_citation_regex = re.compile(curly_brackets_citation) # NB don't ignore case here

#superscript citation
num_citation_ss = r'[-\d,; –\s\\]+'
superscript_citation = r'(?<!\b\w)<sup>'+num_citation_ss+'</sup>'
# superscript_citation = r'<sup>'+num_citation+'</sup>'
superscript_citation_regex = re.compile(superscript_citation) # NB don't ignore case here

#date
date_string = r"(?:1|2)\d\d\d"
date_regex = re.compile(date_string)

#statistical regexs

# little helpers
s = r"[\s\*\,]*"
obr = r"[\(\[\{]"
cbr = r"[\)\]\}]"
df = r"df"+s+"="+s+"\d+"

#1 or 2 tailed
tailed = r"(tail(ed)?|tail|sided|direction(al)?)"
one = r"\b(one|1)"
two = r"\b(two|2)"
one_tailed = one + s + tailed
two_tailed = two + s + tailed
one_tailed_regex = re.compile(one_tailed, flags = re.IGNORECASE)
two_tailed_regex = re.compile(two_tailed, flags = re.IGNORECASE)
# digits = r"(\d+|\d+\.\s?\d+|\.\s?\d+)"
# digits = r"\d*\s*\.*\s*\d+" ## getting rid of this because it wasnt handling things like p = 0.042 properly. It would ignore everything from the . onwards
digits = r"\d*\.*\d+"

digits_regex = re.compile(digits, flags = re.IGNORECASE)

# to catch p values
p_str = r"\bp\b"+s+"(val(ue)?)?"

# p_string = p_str+s+r"(?P<operand>[\\\<>=≤≥\&glt;]+)"+s+"(?P<{}>(\d*\.\s?\d*)(\W+10\<sup\>\-?\d+)?|n\.?s\.?)"+s
p_string = p_str+s+r"(?P<operand>[\\\<>=≤≥\&glt;]+)"+s+"(?P<{}>"+digits+"(\W+10\<sup\>\-?\d+)?|n\.?s\.?)"+s

p_regex = re.compile(p_string.format("p_value"), flags = re.IGNORECASE)
confidence_interval_string = r"(confiden[sc]e\s+interval|\b\d+%\s*ci\b)"
confidence_interval_regex = re.compile(confidence_interval_string, flags = re.IGNORECASE)


### t catch t tests
t_str = r"\bt\b"+s+"(\-?test)?"+s
t_string = s+t_str+s+"("+obr+s+"(?P<t_test_df>\d+)"+s+cbr+"|"+df+")"+s+"="+s+"(?P<t_value>[\-\d\.\,]+)"+s
t_test_regex = re.compile(t_string+"\,?\s*"+p_string.format("t_test_p_value"), flags = re.IGNORECASE)
bad_t_str = r"\bt\b"+s+"="+s+digits
bad_t_regex = re.compile(bad_t_str, flags = re.IGNORECASE)

### to catch f tests
f_str = r"\bf"+s+"(\-?test)?"+s
f_string = s+f_str+obr+"?"+s+"(?P<f_df1>\d+)"+s+"\,?"+s+"(?P<f_df2>\d+)"+s+cbr+"?"+s+"="+s+"(?P<f_value>[\-\d\.\,]+)"+s
f_test_regex = re.compile(f_string+"\,?\s*"+p_string.format("f_test_p_value"), flags = re.IGNORECASE)
bad_f_str = r"\bf\b"+s+"="+s+digits
bad_f_regex = re.compile(bad_f_str, flags = re.IGNORECASE)

### to catch correlation test
r_only = s+r"\br\b"+s+"="+s+"[\d\.]+"
r_only_regex = re.compile(r_only, flags = re.IGNORECASE)
r_string_1 = s+r"\br\b"+s+"("+obr+"?"+s+"(?P<r_df>\d+)"+s+cbr+"?)?"+s+"\="+s+"(?P<r_value1>[\d\.]+)"+s
r_string_2 = s+r"\br\b"+s+"\="+s+"(?P<r_value2>[\d\.]+)"+s+"\,?"+s+"n"+s+"="+s+"((?P<r_N>\d+)"+s+"\,?)?"+s
r_test_regex = re.compile(r"("+r_string_1+"|"+r_string_2+")"+"\,?\s*"+p_string.format("r_test_p_value"), flags = re.IGNORECASE)

### To catch standard error of the mean
sem_only = r"\b(se|sem|standard\s*error(\s*of\s*the\s*mean)?)\b\s*[=\+\-±]\s*[\d\,\.\+\-±]"
sem_regex = re.compile(sem_only, flags = re.IGNORECASE)

# WRITING STYLE CHECKS
however = r"however"
moreover = r"moreover"
studies_show = r"studies[\w\s]+{1,20}(show|suggest)"
in_the_present_paper = r"in\s*(the|this)\s*(present)?\s*(paper|experiment)"
references_herein = r"references\s*herein"

#to check within a sentence
commas = r"\,"
because = r"because"
although = r"although"
ands = r"and"

#clinical trial registry regex
registry_string = r"(\b" + registry_regex_dict.values()[0]
for t in registry_regex_dict.values()[1:]:
	registry_string = registry_string + r"|\b" + t
registry_string = registry_string + ")"
registry_regex = re.compile(registry_string, flags = re.IGNORECASE)
prospero_regex = re.compile(r"\b" + registry_regex_dict["Prospero"] + r"\b", flags = re.IGNORECASE)

#to extract references (requires all references to have a date)
ref_str = r"(\n+[^\n]+\d\d\d\d[^\n]+)+"
ref_regex = re.compile(ref_str, flags = re.IGNORECASE)

## Figure Capture
# specifically for matching figure media files
figure_media_regex = re.compile('(!\[\]\(media\/image\d\.(\w{2,7})\))', flags = re.IGNORECASE)

## Table Capture
# simply matches the |----| part of all instances of tables within the text
table_confirm = re.compile('(\|-+)+\|\n', flags = re.IGNORECASE)
# shy captures most tables apart from those with a linebreak within a cell
table_shy = re.compile('(\|.*\|\n(\|-+)+\|\n(\|.*\|\n)+)', flags = re.IGNORECASE)
# very greedy captures all tables including those with a linebreak within a cell. However, does not distinguish tables from one another 
table_greedy = re.compile('(\|.*\|\n(\|-+)+\|\n(\|[^\|]*)+\|\n)', flags = re.IGNORECASE)

#### Table cell no. matching program (incomplete) #####

# cd /Users/Govind/Dropbox/ResearchWell/play_code
# from file_fns import test_text as t
# import re
# 
# # regex for all consecutive sequences of |--------|
# dash = re.compile('((?:\|-+)+\|\s)', re.IGNORECASE)
# 
# # finds all instances of consecutive sequences of |--------|
# H = dash.findall(t)
# H
# 
# # counts all | within |--------| sequences to figure out number of row cells
# line = re.compile('\|')
# for x in range(len(H)):
#     H[x] = len(line.findall(H[x]))
# # number of row cells in sequence is number of | minus 1
# for x in range(len(H)):
#     H[x] = H[x]-1
#  
# # H is now a list of numbers representing the number of row cells in each table        
# H



## ALL REGEXES PUT INTO A DICTIONARY
all_regexs = {
"heading_regex":heading_regex,\
"title_h":title_h,\
"running_head_h":running_head_h,\
"authors_h":authors_h,\
"corresponding_author_h":corresponding_author_h,\
"word_count_h":word_count_h,\
"key_words_h":key_words_h,\
"author_Statement_h":author_Statement_h,\
"conflicting_interests_h":conflicting_interests_h,\
"data_statement_h":data_statement_h,\
"funding_statement_h":funding_statement_h,\
"abstract_h":abstract_h,\
"purpose_h_ab_sub" : introduction_h,\
"methods_h_ab_sub" : methods_h,\
"results_h_ab_sub" : results_h,\
"conclusions_h_ab_sub" : conclusions_h,\
"purpose_h":purpose_h,\
"introduction_h":introduction_h,\
"methods_h":methods_h,\
"results_h":results_h,\
"discussion_h":discussion_h,\
"conclusions_h":conclusions_h,\
"references_h":references_h,\
"acknowledgements_h":acknowledgements_h,\
"appendix_h":appendix_h,\
"legend_h":legend_h,\
"tables_h":tables_h,\
"figures_h":figures_h,\
"tables_l":tables_l,\
"figures_l":figures_l,\
"tables_m":tables_m,\
"figures_m":figures_m,\
"t_test":t_test_regex
}

##### IDEAL TITLES FOR FUZZY MATCHING
# Put all ideal titles into a dictionary so that we can use fuzzy matching. Each value should be a list

ideal_titles = {
"title_h":["title"],\
"running_head_h":["running head", "running title", "alternative title", "alternative head"],\
"authors_h":["authors", "list of authors"],\
"corresponding_author_h":["corresponding author", "correspondence to", "e-mail"],\
"word_count_h":["word count", "words"],\
"key_words_h":["key words", "mesh"],\
"author_Statement_h":["author statement"],\
"conflicting_interests_h":["declaration of interests","declaration of competing interests", "declaration of conflicting interests", "competing interests", "conflicting interests", "conflicts of interests", "disclosure"],\
"data_statement_h":["data statement", "data access statement", "data availability statement"],\
"funding_statement_h":["sources of funding", "funding"],\
"abstract_h":["abstract"],\
"introduction_h":["introduction"],\
"methods_h":["methods", "methods and materials", "materials and methods"],\
"results_h":["results"],\
"discussion_h":["discussion"],\
"references_h":["references"],\
"acknowledgements_h":["acknowledgements"],\
"appendix_h":["appendix", "supplementary information", "supplementary files"],\
"legend_h":["legend"],\
"tables_h":["table"],\
"figures_h":["figure", "fig"],\
}