import os
from os import walk
import re
import sys
reload(sys)
import subprocess
import unicodedata
sys.setdefaultencoding('utf-8')
span_regex = re.compile(r"<span[^\n]*span>")

def save_md_from_docx(save_as, save_as_md):
	options = ["pandoc", "-s", save_as, "-t", "markdown_github+yaml_metadata_block", "--verbose","-o", save_as_md, "--atx-headers"]
	subprocess.check_call(options, stdin=None, stdout=None, stderr=None, shell=False)
	
	
def get_clean_text_from_md_filepath(save_as_md):
	text = get_full_text_from_md_filepath(save_as_md)
	text = text.replace("\\", "")
	text = span_regex.sub("", text)
	# these two lines replaces accented letters with their ascii equivalent. I got it from:
	# http://stackoverflow.com/questions/517923/what-is-the-best-way-to-remove-accents-in-a-python-unicode-string/518232#518232
	text = unicodedata.normalize("NFKD", unicode(text))
	text = text.encode("ASCII", "ignore")	
	return text	


def get_all_test_md_filepaths(path):
    all_filepaths = []
    for (dirpath, dirnames, filenames) in walk(path):
        for dir in dirnames:
            filepaths = get_md_filepaths_from_dirpath(path + "/" + dir)
            all_filepaths.extend(filepaths)
    return all_filepaths

def get_list_of_all_filenames_from_dirpath(dirpath):
# give it a directory path and it'll return all the files within
# NB only works at one level. So if the file has another file inside then it won't go in there
    all_filenames = [] #setup an empty list
    for (dirpath, dirnames, filenames) in walk(dirpath): # returns the path along with directories and filenames
        all_filenames.extend(filenames) #append to a list
        break
    return all_filenames

def get_md_filepaths_from_all_filenames(all_filenames, dirpath):
# takes a list of all filenames and returns the filepaths for md files only
    md_filepaths = []
    for filename in all_filenames:
        if filename.endswith(".md"):
            md_filepaths.append(dirpath + "/" + filename)
    return md_filepaths

def get_md_filepaths_from_dirpath(dirpath):
# give it a directory path and it'll return the paths for markdown files contained
    all_filenames = get_list_of_all_filenames_from_dirpath(dirpath)
    md_filepaths = get_md_filepaths_from_all_filenames(all_filenames, dirpath)
    return md_filepaths

def get_full_text_from_md_filepath(md_filepath):
#opens a file from a filepath, gets the full text, then closes the file
    file = open(md_filepath, "r")
    text = file.read()
    file.close()
    return text

def get_paths_text_on_james_computer():
	example_files_path = os.path.expanduser("~/Dropbox/researchwell info/example_word_files/")
	academic_dirpath = example_files_path + "Academic"
	osf_dirpath = example_files_path + "OSF_Set"
	govind_dep_dirpath = example_files_path + "Govind department Set"
	test_set_2_dirpath = example_files_path + "Test_set_2"
	all_md_filepaths = []
# 	all_md_filepaths += get_md_filepaths_from_dirpath(academic_dirpath)
	all_md_filepaths += get_all_test_md_filepaths(example_files_path)
# 	all_md_filepaths += get_md_filepaths_from_dirpath(osf_dirpath)
# 	all_md_filepaths += get_md_filepaths_from_dirpath(govind_dep_dirpath)
# 	all_md_filepaths += get_md_filepaths_from_dirpath(test_set_2_dirpath)
	test_path = get_md_filepaths_from_dirpath(academic_dirpath)[1]
	test_text = get_full_text_from_md_filepath(test_path)
	return all_md_filepaths, test_text