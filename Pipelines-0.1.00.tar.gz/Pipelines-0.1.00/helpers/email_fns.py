#! /usr/bin/python

import smtplib
import pdfkit
import time

from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

from email.MIMEBase import MIMEBase
from email import encoders

from helpers.print_fns import *
from general_medical.pipeline import *
from resources.email_test_messages import email_msgs

import os


# me == my email address
# you == recipient's email address
alex = "alex@peneloperesearch.com"
alexs_password = "ar3g0lag"
me = "james@peneloperesearch.com"
you = "jamesrharwood@gmail.com"
password = "w3ndElag"

my_dir_path = os.path.expanduser("~/Penelope/files/")
my_css_path = os.path.expanduser("~/Penelope/files/my_css.css")
my_footer_path = os.path.expanduser("~/Penelope/files/my_footer.html")

checklist_attachment_dict = {
	"arrive":[("The ARRIVE checklist for animal research. You should include a completed version of this when you submit to a journal.", "checklists/NC3Rs ARRIVE Guidelines Checklist (fillable).pdf")],\
	"consort":[("The CONSORT checklist for randomised trials. You should include a completed version of this when you submit to a journal.", "checklists/CONSORT-2010-Checklist-MS-Word.docx"),\
		("The CONSORT flow diagram. You should include this as a figure in your manuscript.","checklists/CONSORT-2010-Flow-Diagram-MS-Word.doc")],\
	"moose":None,#[("The MOOSE checklist for reviews and meta-analyses of observational studies. You should include a completed version of this when you submit to a journal.","checklists/MOOSE.docx")],\
	"prisma":[("The PRISMA checklist for systematic reviews. You should include a completed version of this when you submit to a journal.", "checklists/PRISMA-2009-Checklist-MS-Word.doc"),\
		("The PRISMA flow diagram. You should include this as a figure in your manuscript.","checklists/PRISMA-2009-Flow-Diagram-MS-Word.doc")],\
	"care":[("The CARE checklist for clinical case reports and case series. You should include a completed version of this when you submit to a journal.","checklists/CAREchecklist-Eng-20160131.docx")],\
	"entreq":None,#[("The ENTREQ checklist for the synthesis of qualitative research. You should include a completed version of this when you submit to a journal.","checklists/ENTREQ.docx")],\
	"stard":[("The STARD checklist for diagnostic accuracy studies. You should include a completed version of this when you submit to a journal.","checklists/STARD-2015-Checklist.docx")],\
	"remark":["The REMARK checklist for prognostic modelling studies using biomarkers. You should include a completed version of this when you submit to a journal.","checklists/REMARK.docx"],\
	"srqr":None,#[("The SRQR checklist for qualitative research. You should include a completed version of this when you submit to a journal.","checklists/SRQR.docx")],\
	"strobe":[("The STROBE checklist for observational studies. You should include a completed version of this when you submit to a journal.","checklists/STROBE-Checklist-v4-MS-Word.doc")],\
	"tripod":[("The TRIPOD checklist for prediction modelling studies of prognosis or diagnosis. You should include a completed version of this when you submit to a journal.","checklists/Tripod_Checklist_v2_090215.docx")]}

def get_feedback_pdf_from_text(all_checks, text, design_type, journal, doc_name, user_name):
	create_feedback_pdf(all_checks, doc_name, user_name, text)

def create_feedback_pdf(flat_results, doc_name, user_name, text):
	processeded_time = time.ctime()
	organised_list = organise_flat_list_by_manuscript_section(flat_results, email_msgs)
	message_to_pdf = "![](image1.png)\n\n#Feedback on your manuscript that you submitted on {0}".format(processeded_time)
	message_to_pdf += "\n\nYour manuscript was checked against guidelines set out by the International Committee of Medical Journal Editors. We hope these suggestions help you prepare for journal submission." 
# 	message_to_pdf += "\n\nPlease note, this automated system is intended for for original research articles."
# 	message_to_pdf += " If your manuscript was something different then some of the advice might seem odd, but hopefully you'll still find some of the suggestions useful."
	important = ""
	checks_to_pdf = ""
	previous_check = "just starting"
	previous_correct = "unknown"
	for sublist in organised_list:
		if sublist[1]:			
			checks_to_pdf += "\n\n\n##"+sublist[0] # Writes the broad manuscript section heading
			for i in sublist[1]:
				if ((i.passed == False) and email_msgs[i.test]["important"]):
					important += "\n\n* " + email_msgs[i.test]["fail"]
				
				
				if (i.test != previous_check):
					checks_to_pdf += "\n\n" +get_message_to_email(i, text)
					if email_msgs[i.test].get("quote_all"):
						if (email_msgs[i.test]["quote_all"]==True or not i.passed):
							checks_to_pdf += email_obj_text(i, text, context = True)
				elif (i.passed != previous_correct):
					checks_to_pdf += "\n\n" +get_message_to_email(i, text)
					checks_to_pdf += email_obj_text(i, text, context = True)
				else:
					if email_msgs[i.test].get("quote_all"):
						if (email_msgs[i.test]["quote_all"]==True or not i.passed):
							checks_to_pdf += email_obj_text(i, text, context = True)
				previous_check = i.test
				previous_correct = i.passed										
					
				
# 				if (i.test == previous_check):
# 					if (i.passed != previous_correct):
# 						checks_to_pdf += "\n\n" +get_message_to_email(i, text)
# 						previous_correct = i.passed
# # 					else:
# # 						checks_to_pdf += email_obj_text(i, text, context = True)
# 					if email_msgs[i.test].get("quote_all"):
# 						if email_msgs[i.test]["quote_all"]:
# 							checks_to_pdf += email_obj_text(i, text, context = True)								
# 				else:
# 					checks_to_pdf += "\n\n" +get_message_to_email(i, text)
# 					previous_check = i.test
# 					previous_correct = i.passed

						

	if important:
		important = "\n\n##Important things for you to check\n\nMake sure you have done these things, or else an editor might not be able to send your manuscript for peer review." + important
	message_to_pdf += important
	message_to_pdf += checks_to_pdf			
	message_to_pdf += "\n\n\n\n\n#We hope you found this useful. Good luck with your work!"
	create_pdf(message_to_pdf, doc_name)

def create_email_html_message(name, report_type, attachment_filepath):
	if attachment_filepath.endswith(".pdf"):
		message_to_email = "A summary of this feedback is attached as a PDF. "
	else:
		message_to_email = "Penelope has added comments to your manuscript. "
	if (report_type and checklist_attachment_dict.get(report_type)):
		message_to_email += "You will also find:"
		for item in checklist_attachment_dict[report_type]:
			message_to_email += "\n\n* " + item[0]		
# 	else:
# 		message_to_email += " a PDF version copy of the feedback on your manuscript."
		
	message_to_email += "\n\nThis is a beta version of an automated tool that compares medical research manuscripts against the recommendations of the International Committee of Medical Journal Editors. "
	message_to_email += "I would love to hear what you think about it, so if you have any feedback or questions then please let me know.\n\nI hope that you find these suggestions useful and wish you all the best with your research."
	message_to_email += "\n\nAlex"
	
	with tempfile.NamedTemporaryFile(delete=True, dir = os.path.expanduser("~/Penelope/files/")) as tmp:
		tmp.write(message_to_email)
		tmp.flush()
		options = ["pandoc", "-S", "-c", my_css_path, "-A", my_footer_path, tmp.name, "-o", my_dir_path+"email_message.html"]
		options = ["pandoc", "-S", "-c", my_css_path, tmp.name, "-o", my_dir_path+"email_message.html"]
		subprocess.check_call(options)
				
def organise_flat_list_by_manuscript_section(flat_results, email_msgs):
	all_sections = [email_msgs[i.test]["section"] for i in flat_results]
	ordered_set = []
	for b in all_sections:
		if b not in ordered_set:
			ordered_set.append(b)
	results_dict = {}
	for b in ordered_set:
		results_dict.update({b:[]})
	for i in flat_results: # append all that have passed first
		if i.passed:
			results_dict[email_msgs[i.test]["section"]].append(i)
	for i in flat_results: # append all that have failed first
		if not i.passed:
			results_dict[email_msgs[i.test]["section"]].append(i)	
	list_to_return = []
	for b in ordered_set:
		list_to_return.append([b, results_dict[b]])
	return list_to_return
		
def create_pdf(message_to_pdf, doc_name, dir_path = my_dir_path, css_path = my_css_path, footer_path = my_footer_path):
# 	with tempfile.NamedTemporaryFile(delete=True, dir = os.path.expanduser("~/Penelope/pipelines/email_user")) as tmp:		
	with open(dir_path+"new_file.md", "w") as tmp:
		# do stuff with a temp file
		tmp.write(message_to_pdf)
	time.sleep(2)
	options = ["pandoc", "-S", "-c", css_path, "-A", footer_path, tmp.name, "-o", dir_path+"feedback.html"]
	print "writing to file"
	a = subprocess.check_call(options)#, stdin=None, stdout=None, stderr=None, shell=False)
	pdfkit_options = {
		'page-size': 'Letter',\
		'margin-top': '1.25in',\
		'margin-right': '1.25in',\
		'margin-bottom': '1.25in',\
		'margin-left': '1.25in',\
		'encoding': "UTF-8",
		'no-outline': None
	}
	pdfkit.from_file(dir_path+'feedback.html', dir_path+'Feedback_on_'+doc_name+'.pdf', options = pdfkit_options)		
# 		options = ["pisa", "feedback.html", "Feedback_on_"+doc_name+".pdf"]
# 		subprocess.check_call(options)		

def send_email_with_attachment(users_email, users_name, attachments, feedback_url): 
	msg = MIMEMultipart()
 
	msg['From'] = alex
	msg['To'] = users_email
	msg['Subject'] = "Your feedback is ready"
 
 	with open(os.path.expanduser("~/Penelope/files/email_message.html")) as file:
 		message_to_send = file.read()
 		
 	with open(os.path.expanduser("~/Penelope/files/penelope_html_template.html")) as file:
	 	html_message = file.read()
	html_message = html_message.replace("REPLACE_NAME", users_name)
	html_message = html_message.replace("REPLACE THIS", message_to_send)
	html_message = html_message.replace("REPLACE_URL", feedback_url)
	
	text = message_to_send

	part1 = MIMEText(text, 'plain')
	part2 = MIMEText(html_message, 'html')
			 
	# Attach parts into message container.
	# According to RFC 2046, the last part of a multipart message, in this case
	# the HTML message, is best and preferred.
# 	msg.attach(part1)
	msg.attach(part2)
	
 	for a in attachments:
		filepath = a
		filename = filepath.split("/")[-1]
		attachment = open(filepath, "rb")
 
		part = MIMEBase('application', 'octet-stream')
		part.set_payload((attachment).read())
		encoders.encode_base64(part)
		part.add_header('Content-Disposition', "attachment; filename= %s" % filename)
 
		msg.attach(part)
 
	server = smtplib.SMTP('smtp.gmail.com', 587)
	server.starttls()
	server.login(alex, alexs_password)
	text = msg.as_string()
	server.sendmail(alex, users_email, text)
	server.quit()

def send_user_fail_mail(users_email, users_name):
	msg = MIMEMultipart()
	msg['From'] = alex
	msg['To'] = users_email
	msg['Subject'] = "There was a problem processing your file"
 
 	text = "Hi "+users_name+",\n\nThere was a problem processing your file. We've made a note of the error and will investigate what went wrong.\n\nThank you for your patience,\n\nThe Penelope Team"

	part1 = MIMEText(text, 'plain')
			 
	# Attach parts into message container.
	# According to RFC 2046, the last part of a multipart message, in this case
	# the HTML message, is best and preferred.
	msg.attach(part1)

 
	server = smtplib.SMTP('smtp.gmail.com', 587)
	server.starttls()
	server.login(alex, alexs_password)
	text = msg.as_string()
	server.sendmail(alex, users_email, text)
	server.quit()

def send_error_warning(my_email, error_text):
	msg = MIMEMultipart()
	msg['From'] = me
	msg['To'] = my_email
	msg['Subject'] = "There was a problem on the server"
 
 	text = error_text

	part1 = MIMEText(text, 'plain')
			 
	# Attach parts into message container.
	# According to RFC 2046, the last part of a multipart message, in this case
	# the HTML message, is best and preferred.
	msg.attach(part1)

 
	server = smtplib.SMTP('smtp.gmail.com', 587)
	server.starttls()
	server.login(me, password)
	text = msg.as_string()
	server.sendmail(me, my_email, text)
	server.quit()	

def warn_user(users_email, users_name):
	msg = MIMEMultipart()
	msg['From'] = alex
	msg['To'] = users_email
	msg['Subject'] = "Did you upload a docx file?"
 
 	text = "Hi "+users_name+",\n\nThere was a problem checking your manuscript. Are you sure you uploaded a .docx file? You should make sure that the file name ends with .docx. At the moment we can only process those kinds of files, so if you tried to upload a .pdf or .doc file it won't work. We hope to be able to process more file types in the future.\n\nThanks for your patience!\n\nThe Penelope Team"

	part1 = MIMEText(text, 'plain')
			 
	# Attach parts into message container.
	# According to RFC 2046, the last part of a multipart message, in this case
	# the HTML message, is best and preferred.
	msg.attach(part1)

 
	server = smtplib.SMTP('smtp.gmail.com', 587)
	server.starttls()
	server.login(alex, alexs_password)
	text = msg.as_string()
	server.sendmail(alex, users_email, text)
	server.quit()	



