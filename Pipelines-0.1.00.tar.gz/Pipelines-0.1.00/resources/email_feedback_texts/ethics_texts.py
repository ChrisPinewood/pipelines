ethics_texts_dict = {

"informed_consent":\
{"pass":"You have addressed informed consent",\
"fail":"Did participants give informed consent?",\
"explain":"""If your research involved human subjects, you must say whether or not participants gave informed consent to be in the study. This should go in your methods section.""",\
"none":"",\
"section":"Methods",\
"important":True,\

},\

"helsinki":\
{"pass":"You have addressed the Declaration of Helsinki",\
"fail":"Does your work adhere to the Declaration of Helsinki?",\
"explain":"""If your research involved human subjects, you must say whether or not your study adheres to the [Declaration of Helsinki](http://www.wma.net/en/30publications/10policies/b3/). This should go in your methods section.""",\
"none":"",\
"section":"Methods",\
"important":True,\

},\

"ethics":\
{"pass":"You have addressed ethical approval",\
"fail":"Did you receive ethical approval for this study?",\
"explain":"""If your research involved humans or animals you must explain whether ethical approval was sought and, if so, who granted it.""",\
"none":"",\
"section":"Methods",\
"important":True,\

}

}