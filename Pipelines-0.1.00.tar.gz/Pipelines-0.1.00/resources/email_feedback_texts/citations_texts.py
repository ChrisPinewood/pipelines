citations_texts_dict = {

"correct_cit_style_used_num":\
{"pass":"Your citations are numerical",\
"fail":"Should your citations be numerical?",\
"explain":"""Most medical journals follow the [Vancouver citation style](https://en.wikipedia.org/wiki/Vancouver_system), where citations are written as superscript numbers. You should allocate a number to a reference source in the order in which it is cited in the text. If the source is referred to again, the same number is used.""",\
"none":"",\
"section":"Referencing",\
"important":False,\
},\

"correct_cit_style_used_alpha":\
{"pass":"Your citations follow a harvard system",\
"fail":"Have you used the correct citing style?",\
"explain":"""Make sure your citations follow the [Harvard citation style](https://en.wikipedia.org/wiki/Parenthetical_referencing#How_to_cite). This style uses the names of authors and years of publication, rather than a numerical system.""",\
"none":"",\
"section":"Referencing",\
"important":False,\
},\

"anomaly_cit_style_used":\
{"pass":"All citations are in the correct style",\
"fail":"Is this citation in the correct style?",\
"explain":"Make sure all citations follow the same style according to journal guidelines. Does this citation fit with the style you've used throughout the rest of your manuscript?",\
"none":"",\
"section":"Referencing",\
"important":False,\
"quote_all":True,\
},\

"citation_in_abstract":\
{"pass":"There are no citations in your abstract",\
"fail":"Have you made sure there are no citations in your abstract?",\
"explain":"""Your abstract shouldn't have any citations in it. When the abstract is displayed in search engines, the citations won't be displayed properly.""",\
"none":"",\
"section":"Referencing",\
"important":False,\
"quote_all":True,\
},\

"verify_citation_in_references":\
{"pass":"You've referenced all of your citations",\
"fail":"Have you referenced this citation?",\
"explain":"Make sure these citations have entries in your reference list.",\
"none":"",\
"section":"Referencing",\
"important":False,\
"quote_all":True,\
},\

"verify_num_citation_seq:numerical_order":\
{"pass":"Your citations are in an ascending sequence",\
"fail":"Are all your citations in the right order?",\
"explain":"""Make sure your citations are in the right order.""",\
"none":"",\
"section":"Referencing",\
"important":False,\
"quote_all":True,\
},\

"verify_num_citation_seq:full_sequence":\
{"pass":"You haven't skipped any citation numbers",\
"fail":"Have you skipped a citation number?",\
"explain":"Make sure you haven't skipped a citation here. This can happen after you delete a section of text containing a citation and forget to update the remaining citations. Look for the citations with values one higher and lower than this one.",\
"none":"",\
"section":"Referencing",\
"important":False,\
"quote_all":True,\
},

"all_alpha_citations_referenced":\
{"pass":"You have referenced all of your citations",\
"fail":"Have you referenced all of your citations?",\
"explain":"Make sure this citation has an entry in your reference list and that the names and dates match up.",\
"none":"",\
"section":"Referencing",\
"important":False,\
"quote_all":True,\
}

}