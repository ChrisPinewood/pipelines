risk_of_bias_texts_dict = {
"Random sequence generation":\
{"pass":"You have explained how you generated a random sequence",\
"fail":"Have you explained whether you generated a random sequence?",\
"explain":"You should describe the method used to generate the allocation sequence",\
"none":"",\
"section":"Methods",\
"important":False,\

},\

"Allocation concealment":\
{"pass":"You have explained how you concealed allocation",\
"fail":"Have you explained allocation concealment?",\
"explain":"You should describe any methods used to conceal the allocation sequence so that readers \
can tell whether there's any chance that experimenters culd have forseen \
intervention allocations in advance of, or during, enrolment.",\
"none":"",\
"section":"Methods",\
"important":False,\

},\

"Blinding of participants and personnel":\
{"pass":"You have explained whether participants and personnel were blinded",\
"fail":"Have you explained whether participants and personnel were blinded to experimental condition? ",\
"explain":"You should describe all measures used, if any, to blind study participants and personnel \
from knowledge of which intervention a participant received. Provide any information \
relating to whether the intended blinding was effective",\
"none":"",\
"section":"Methods",\
"important":False,\

},\

"Incomplete outcome data":\
{"pass":"Completeness of outcome data addressed",\
"fail":"Have you addressed completeness of data?",\
"explain":"Describe the completeness of outcome data for each main outcome, including \
attrition and exclusions from the analysis. State whether attrition and exclusions were \
reported, the numbers in each intervention group (compared with total randomized \
participants), reasons for attrition/exclusions where reported, and any re-inclusions in \
analyses performed by the review authors.",\
"none":"",\
"section":"Methods",\
"important":False,\

},\

"Selective reporting":\
{"pass":"Low risk of selective reporting",\
"fail":"Possible risk of selective reporting",\
"explain":"Explain that all outcomes measured have been reported, ideally by linking to a \
protocol",\
"none":"",\
"section":"Methods",\
"important":False,\

},\

"Blinding of outcome assessment":\
{"pass":"Low risk of outcome assessment bias",\
"fail":"Have you explained whether participants/personel were blinded during outcome assessment?",\
"explain":"Describe all measures used, if any, to blind study participants and personnel \
during outcome assessment. Provide any information relating to whether the intended \
blinding was effective.",\
"none":"",\
"section":"Methods",\
"important":False,\

}
}
