# -*- coding: utf-8 -*-

from helpers.general_fns import *

def find_antibody_rrids(text, references_h):
	text = text[:references_h.position[0]] if references_h else text
	found_antibodies = find_in_full_text(antibody_regex, text, "antibodies")
	rrids = find_in_full_text(rrid_regex, text, "rrid")
	antibodies = []
	if (found_antibodies and not rrids):
		antibodies = [TestResult("antibody_rrids_used", False, (get_surrounding_sentence(i, text))) for i in found_antibodies]
	return antibodies 