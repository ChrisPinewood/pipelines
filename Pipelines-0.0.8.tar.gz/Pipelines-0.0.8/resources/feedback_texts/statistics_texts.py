statistics_texts_dict = {

"correct_f_test":\
{"pass":"This f statistic is consistent with the its p-value",\
"fail":"Is this F statistic correct?",\
"explain":"You should double check these values as the p-value you've provided is not \
consistent with a 1 tailed test using the f statistic and degrees of freedom you've \
supplied. If you've applied special calculations you should make sure these are clear",\
"none":"It looks like you've not reported any f-tests in the main body of text"},\

"correct_t_test_2tail":\
{"pass":"This t-test is consistent with its p-value using a 2 tailed test",\
"fail":"Is this t statistic correct?",\
"explain":"You should double check these values as the p-value you've provided is not \
consistent with a 2 tailed test using the t statistic and degrees of freedom you've \
supplied. If you've used special calculations you should make sure these are clear",\
"none":"It looks like you've not reported t-tests in the main body of text"},\

"correct_t_test_1tail":\
{"pass":"This t-test is consistent with its p-value using a 1 tailed test",\
"fail":"Is this t statistic correct?",\
"explain":"You should double check these values as the p-value you've provided is not \
consistent with either a 1 or 2 tailed test using the t statistic and degrees of freedom you've \
supplied. If you've used special calculations you should make sure these are clear",\
"none":""},\

"correct_r_test":\
{"pass":"This pearson correlations is consistent with its p-value",\
"fail":"Is this pearson correlation correct?",\
"explain":"You should double check these values as the p-value you've provided is not \
consistent with the r statistic and degrees of freedom you've \
supplied. If you've used special calculations you should make sure these are clear",\
"none":""},\

"one_tailed_t_test_declared":\
{"pass":"1 tailed t-test declared",\
"fail":"Have you justified using a 1 tailed t-test?",\
"explain":"If you perform a 1 tailed t-test you should declare it and justify why \
a 2 tailed test is not necessary",\
"none":""},\

"two_tailed_t_test":\
{"pass":"No 1 tailed t tests found",\
"fail":"",\
"explain":"",\
"none":""},\

"t_tests_reported_well":\
{"pass":"You've reported all t-tests with their degrees of freedom",\
"fail":"Have you reported the degrees of freedom for this test?",\
"explain":"When reporting a t-test you should include the degrees of freedom and the \
t statistic. You should write this as t(df) = t statistic",\
"none":""},\

"f_tests_reported_well":\
{"pass":"You have reported all f-tests with their degrees of freedom",\
"fail":"Have you reported the degrees of freedom for this test?",\
"explain":"When reporting an f-test you should include both of the degrees of freedom \
you used to calculate the f statistic. You should write this as F(df1, df2) = F-statistic",\
"none":""},

"r_tests_reported_well":\
{"pass":"You have reported all Pearson's correlations without their degrees of freedom",\
"fail":"Have you included the degrees of freedom for this Pearson's correlation?",\
"explain":"When reporting a Pearson's correlation you should include the degrees of freedom \
you used to calculate the r statistic. You should write this as r(df) = r statistic",\
"none":"It looks like you've not reported any Pearson correlations in the main body text"},

"pval_as_equalities":\
{"pass":"You have given the exact p-value",\
"fail":"Have you given the exact p-value here?",\
"explain":"All p-values should be reported as exact figures, not as inequalities, \
except for p-values smaller than .001",\
"none":"It looks like you've not reported any p-values in the main text"}

}