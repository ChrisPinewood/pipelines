import argparse
import codecs
import sys
from pipeline import check_manuscript

def run_tests(fileobj, to_screen):
    """ run pipeline tests on an incoming file object"""
    with fileobj:
        try:
            full_text = fileobj.read()
        except KeyboardInterrupt:
            parser.print_help()
            sys.exit(1)

    check_manuscript(full_text, not(to_screen))


## Argument parser to run this module ##
parser = argparse.ArgumentParser(prog='OPO-Pipeline',
                                 description='OPO-Pipeline, runs tests from Penelope. Pipe the input text via stdin. '
                                             'If neither command-line nor pipe present, will expect typed text followed by ^D')

parser.add_argument('-f', '--file', help='Run pipeline on specified file')
parser.add_argument('-p', '--pretty', action='store_true', help='Pretty print to terminal')

args = parser.parse_args()

pretty_print = False

if args.pretty:
    pretty_print = True

# Get the input for tests, and run them
if args.file:
    # a single file
    f = codecs.open(args.file, 'r', encoding='utf8')
    run_tests(f, pretty_print)

else:
    # take piped or typed input
    UTF8Reader = codecs.getreader('utf8')
    sys.stdin = UTF8Reader(sys.stdin)
    f = sys.stdin
    run_tests(f, pretty_print)
