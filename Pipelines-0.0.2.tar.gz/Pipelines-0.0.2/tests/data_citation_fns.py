from helpers.test_result import *

def tell_penelope_data_citation(text, references, result = None):
	if not result:
		result = check_for_data_citation(references, text)
	tell_penelope(result)

def check_for_data_citation(references, text):
	#takes references a a list of strings and checks to see if they contain mention of a data repositor
	passed = False
	p1 = None
	p2 = None
	for r in references:
		if r.find("data")>-1:
			passed = True
			p1 = text.find(r)
			p2 = text.find(r) + len(r)
	result = [TestResult("has_data_citation", passed, (p1, p2))]
	return result
