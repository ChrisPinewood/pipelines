import os
from os import walk

def get_all_test_md_filepaths(path):
    all_filepaths = []
    for (dirpath, dirnames, filenames) in walk(path):
        for dir in dirnames:
            filepaths = get_md_filepaths_from_dirpath(path + "/" + dir)
            all_filepaths.extend(filepaths)
    return all_filepaths

def get_list_of_all_filenames_from_dirpath(dirpath):
# give it a directory path and it'll return all the files within
# NB only works at one level. So if the file has another file inside then it won't go in there
    all_filenames = [] #setup an empty list
    for (dirpath, dirnames, filenames) in walk(dirpath): # returns the path along with directories and filenames
        all_filenames.extend(filenames) #append to a list
        break
    return all_filenames

def get_md_filepaths_from_all_filenames(all_filenames, dirpath):
# takes a list of all filenames and returns the filepaths for md files only
    md_filepaths = []
    for filename in all_filenames:
        if filename.endswith(".md"):
            md_filepaths.append(dirpath + "/" + filename)
    return md_filepaths

def get_md_filepaths_from_dirpath(dirpath):
# give it a directory path and it'll return the paths for markdown files contained
    all_filenames = get_list_of_all_filenames_from_dirpath(dirpath)
    md_filepaths = get_md_filepaths_from_all_filenames(all_filenames, dirpath)
    return md_filepaths

def get_full_text_from_md_filepath(md_filepath):
#opens a file from a filepath, gets the full text, then closes the file
    file = open(md_filepath, "r")
    text = file.read()
    file.close()
    return text
