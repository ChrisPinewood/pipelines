# -*- coding: utf-8 -*-

import re
import scipy.stats as stats
from helpers.file_fns import *
from helpers.parker_regexs import t_test_regex, p_regex
from helpers.general_fns import *
from decimal import Decimal
from helpers.test_result import *

comma_regex = re.compile("[\,\.]$")


# main function for penelope

def tell_penelope_t_tests_match_pvals(text, t_tests = None):
	if not t_tests:
		t_tests = check_t_tests_in_text(text)
	for t in t_tests:
		tell_penelope(t)

def check_t_tests_in_text(text):
	# returns all t tests reported in the article body
	# it divides the results into 2 tail and 1 tail tests, depending on which fits the p value
	# a pass = False when the given p value matches neither a 1 or 2 tailed recomputed p-value
	results = []
	t_tests = extract_and_compute_t_tests(text)
	if not t_tests:
		return results
	for t in t_tests:
		if not t["pval_correct"]:
			p1 = t["obj"].position[0]
			p2 = t["obj"].position[1]
			correct = t["correct_pval_2tail"]
			result = TestResult("correct_t_test_2tail", False, (p1, p2), {"correct":correct})
		else:
			if t["one_tail_pval"]:
				p1 = t["obj"].position[0]
				p2 = t["obj"].position[1]
				correct = t["correct_pval_1tail"]
				result = TestResult("correct_t_test_1tail", True, (p1, p2), {"correct":correct})
			else:
				p1 = t["obj"].position[0]
				p2 = t["obj"].position[1]
				correct = t["correct_pval_2tail"]
				result = TestResult("correct_t_test_2tail", True, (p1, p2), {"correct":correct})
		results.append(result)
	return results


# sub functions

def extract_and_compute_t_tests(text):
	t_tests = extract_t_tests(text)
	components = None
	if t_tests:
		components = extract_t_test_components(text, t_tests)
	return components

def extract_t_tests(text):
    t_tests = find_in_full_text(t_test_regex, text, "t_tests")
    return list(t_tests)

def extract_t_test_components(text, t_tests):
# 	one_tail_match = find_in_full_text(one_tailed_regex, text, "1 tailed mention")
# 	if one_tail_match:
# 		one_tail_mention = True
# 	else:
# 		one_tail_mention = False
	t_test_components = []
	for t in t_tests:
		string = text[t.position[0]:t.position[1]]
		matchgroup = t_test_regex.search(string)
		groupdict = matchgroup.groupdict()
		df = groupdict["t_test_df"]
		df = float(df.strip())
		tval = groupdict["t_value"]
		tval = float(comma_regex.sub("", tval).strip())
		pval = groupdict["t_test_p_value"]
		pval = float(comma_regex.sub("", pval).strip())
		operand = groupdict["operand"]
		lower_tval, upper_tval = compute_lower_and_upper_rounding_bounds(abs(tval))
		upper_pval_1_tail = compute_correct_pval_1tail(df, lower_tval)
		lower_pval_1_tail = compute_correct_pval_1tail(df, upper_tval)
		exact_pval_1_tail = compute_correct_pval_1tail(df, float(tval))
		upper_pval_2_tail = compute_correct_pval_2tail(df, lower_tval)
		lower_pval_2_tail = compute_correct_pval_2tail(df, upper_tval)
		exact_pval_2_tail = compute_correct_pval_2tail(df, float(tval))
		dp = abs(Decimal(str(pval)).as_tuple().exponent)
		pval_correct, one_tail_pval = check_pval_for_t_statistic(operand, pval, lower_pval_2_tail, upper_pval_2_tail, lower_pval_1_tail, upper_pval_1_tail)

		t_test_components.append({
		"obj":t,\
		"df":float(df),\
		"tval":float(tval), \
		"lower_tval":lower_tval,\
		"upper_tval":upper_tval,\
		"pval":float(pval),\
		"pval_dp":dp,\
		"operand":operand, \
		"correct_pval_1tail":{"lower":lower_pval_1_tail, "upper":upper_pval_1_tail, "exact":exact_pval_1_tail},\
		"correct_pval_2tail":{"lower":lower_pval_2_tail, "upper":upper_pval_2_tail, "exact":exact_pval_2_tail},\
# 		"one_tail_mention":one_tail_mention,\
		"pval_correct":pval_correct,\
		"one_tail_pval":one_tail_pval
		})
	return t_test_components

def compute_correct_pval_2tail(df, tval):
	correct_pval = stats.t.sf(abs(tval), df)*2
	return correct_pval

def compute_correct_pval_1tail(df, tval):
	correct_pval = stats.t.sf(abs(tval), df)
	return correct_pval

def check_pval_for_t_statistic(operand, pval, lower_pval_2_tail, upper_pval_2_tail, lower_pval_1_tail, upper_pval_1_tail):
	if "=" in operand:
		if ((round(lower_pval_2_tail, dp) <= pval) and (pval <= round(upper_pval_2_tail, dp))):
			pval_correct = True
			one_tail_pval = False
		elif (round(lower_pval_1_tail, dp) <= pval <= round(upper_pval_1_tail, dp)):
			pval_correct = True
			one_tail_pval = True
		else:
			pval_correct = False
			one_tail_pval = False
	elif (">" in operand or "≥" in operand or "&gt" in operand):
		if (upper_pval_2_tail > pval):
			pval_correct = True
			one_tail_pval = False
		elif (upper_pval_1_tail > pval):
			pval_correct = True
			one_tail_pval = True
		else:
			pval_correct = False
			one_tail_pval = False
	else:
		if (lower_pval_2_tail < pval):
			pval_correct = True
			one_tail_pval = False
		elif (lower_pval_1_tail < pval):
			pval_correct = True
			one_tail_pval = True
		else:
			pval_correct = False
			one_tail_pval = False
	return pval_correct, one_tail_pval


#### OLD CODE

#
#
#
# def get_t_test_details_for_multiple_filepaths(md_filepath_list):
#     all_results = {}
#     for path in md_filepath_list:
#         text = get_full_text_from_md_filepath(path)
#         t_test_components = extract_and_compute_t_tests(text)
#         if t_test_components:
# 			all_results.update({path:components})
#     return all_results
#
# def check_t_test(t):
# 	print "I've emtiped out the test: check_t_tests. No need to use it"
# # 	operand = t["operand"]
# # 	if operand == "=":
# # # 		dp = abs(Decimal(str(t["pval"])).as_tuple().exponent)
# # # 		correct_rounded = round(t["correct_pval_2tail"], dp)
# # # 		if round(abs(t["pval"] - correct_rounded), 4) > 0.001:
# # 		if not t["pval_correct"]:
# # 			print "this p value may be wrong: pval: {0}, correct for a 2 tail test: {1}, correct for a 1 tail test: {2}".format(t["pval"], t["correct_pval_2tail"]["exact"], t["correct_pval_1tail"]["exact"])
# # 	if (">" in operand or "<" in operand or "≤" in operand or "≥" in operand or "&gt" in operand or "&lt" in operand):
# # 		if (">" in operand or "≥" in operand or "&gt" in operand):
# # 			if (t["correct_pval_2tail"]["exact"] < float(t["pval"])):
# # 				print "found operand in {0}".format(p)
# # 				print "ERROR, correct pvalue is not > {0}".format(t["pval"])
# # 		else:
# # 			if (t["correct_pval_2tail"]["exact"] > float(t["pval"])):
# # 				print "found operand in {0}".format(p)
# # 				print "ERROR, correct pvalue is not < {0}".format(t["pval"])
#
# def compare_t_test_details_multiple_files(all_results):
# 	for p in all_results.keys():
# 		if all_results[p]:
# 			for t in all_results[p]:
# 				check_t_test(t)
#
#
# def run_t_test_checks(md_filepath_list):
# 	a = get_t_test_details_for_multiple_filepaths(md_filepath_list)
# 	compare_t_test_details_multiple_files(a)
#
