import sys

def tell_penelope(result):
	print result

# The format for returning tests to Penelope
TEST_RESULT = {
    'test': None,       # string, required
    'passed': None,     # boolean, required
    'position': {       # optional
        'start': None,   # int, starting character position of result in report
        'end': None     # int, ending character position of result in report
    },
	'data':None	# extra, optional, data

}


class TestResult(object):
    """ wrapper object for the result of a test """

    def __init__(self, test, passed, position=None, data=None):
        self._test = test
        self._passed = passed
        self._position = position       # (start, end) as in re.matchobj.span()
        self._data = data

    def __str__(self):
        from json import dumps
        this_result = TEST_RESULT.copy()

        if self.test:
        	this_result['test'] = self.test
        else:
			del(this_result['test'])

        if self.passed is None:
            del(this_result['passed'])
        else:
            this_result['passed'] = self.passed

        # Add the position if present, or remove it
        if self.position and self.position[0] and self.position[1]:
        	(s, e) = self.position
        	this_result['position'] = {'start': s, 'end': e}
        else:
            del(this_result['position'])

        if self.data:
        	this_result['data'] = self.data
        else:
			del(this_result['data'])

        return dumps(this_result)

    def print_match(self, text):
        """
        Print the span in text of this result
        :param text: the text this result is for
        """
        if self.position:
            (s, e) = self.position
            file=sys.stdout
            print(text[s:e], file)

    def match_string(self, text):
        """
        return as string the span in text of this result
        :param text: the text this result is for
        :return the matching string
        """
        if self.position:
            (s, e) = self.position
            return text[s:e]
        else:
            return None

    @property
    def test(self):
        return self._test

    @property
    def passed(self):
        return self._passed

    @property
    def position(self):
        return self._position

    @property
    def data(self):
    	return self._data
