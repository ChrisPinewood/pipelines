other_heading_texts_dict = {

"acknowledgements_h":\
{"pass":"You have included an acknowledgements section",\
"fail":"Have you included an acknowledgements section?",\
"explain":"You should include an 'Acknowledgements' section where you mention\
contributors who did not meet the criteria for authorship ((see http://www.icmje.org/ \
and GPP2 guidelines for industry-sponsored studies)",\
"none":"It wasn't possible to check your manuscript for an Acknowledgements section"},\

"conflicting_interests_h":\
{"pass":"You have included a disclosure section",\
"fail":"Have you included a disclosure section?",\
"explain":"You should include a 'Disclosure' section where you declare any potential \
conflict of interest. You should include any association with a commercial organisation \
or any financial interest in a product that may give rise to the perception of a \
potential conflict of interest. You should indicate if the sponsors had any specific role \
in the production of the paper (e.g.involvement in writing, analysis, or control over \
publication). If there are no conflicts of interest, state: 'The authors report no \
conflicts of interest and have no proprietary interest in any of the materials mentioned \
in this article.'",\
"none":"It wasn't possible to check your manuscript for a Conflicts of Interest section"},\

"data_statement_h":\
{"pass":"You have included a data statement section",\
"fail":"Have you included a data statement section?",\
"explain":"Your manuscript should have a 'Data Statement' where you explain how the raw data underlying your\
results can be accessed.",\
"none":"It wasn't possible to check your manuscript for a Data Statement section"},\

"funding_statement_h":\
{"pass":"You have included a section about funding",\
"fail":"Have you included a funding statement section?",\
"explain":"All manuscripts should have a section titled 'Funding Statement' where they axplain\
who funded the research, and give grant reference codes.",\
"none":"It wasn't possible to check your manuscript for a Funding section"}
}