# -*- coding: utf-8 -*-
import re
from helpers.parker_regexs import p_regex
from helpers.general_fns import find_in_full_text, get_match_text
from helpers.test_result import *

digits_regex = re.compile(r"\.?\s?\d+(\.\d+)?")

### MAIN FUNCTION FOR PENELOPE ###


def tell_penelope_pval_as_equalities(text, results = None):
	if not results:
		results = check_for_pval_as_equalities(text)
	for result in results:
		tell_penelope(result)


### SUB FUNCTIONS ###

# overall subfunction
def check_for_pval_as_equalities(text):
	# test returns as passed when p value is reported using an "="
	# or when it's reported with a "<" and is less than .001
	# So "p = .43" and "p<.001" will both pass, but "p>.05" or "p<.01" won't
	results = []
	p_values = extract_p_values(text)
	for p in p_values:
		reported_well = check_for_equality_in_pval(p.match_string(text))
		result = TestResult("pval_as_equalities", reported_well, position = (p.position[0], p.position[1]))
		results.append(result)
	return results

# First we extract p values from the text
def extract_p_values(text):
	p_values = find_in_full_text(p_regex, text, "p_values")
   	return list(p_values)

# then we see if the p value includes an inequality sign
# if so, we see whether the p value is less than .001
def check_for_equality_in_pval(p_str):
	ans = True #assume p_val is reported with an equality
	if (">" in p_str or "<" in p_str or "≤" in p_str or "≥" in p_str or "&gt" in p_str or "&lt" in p_str):
		digits = digits_regex.search(p_str) #if an inequality is found, pull out the pval
		if not digits:
			return False #something is fishy if there's no digits. They've probably said "p = ns"
		value = round(float(digits.group().replace(" ", "")), 3)
		if (value > 0.001):
			ans = False
	return ans



##### Old functions

# def print_p_value_sentences(md_filepath_list):
#     for path in md_filepath_list:
#         text = get_full_text_from_md_filepath(path)
#     	p_values = find_in_full_text(p_regex, text, "p_values")
#     	if p_values:
#     		for p in p_values:
#     			sentence = get_surrounding_sentence(text, p.position[0], p.position[1])
#     			print "~ ~ ~"
#     			print sentence

# def print_p_values(results_dict):
# 	total = len(results_dict.keys())
# 	papers_with_inequalities = 0
# 	total_inequalities = 0
# 	for p in results_dict.keys():
# 		if results_dict[p]:
# 			print "file: ", p
# 			papers_with_inequalities += 1
# 			total_inequalities += len(results_dict[p])
# 			for i in results_dict[p]:
# 				print i
# 	print "Number of papers: {0}".format(total)
# 	print "Number of papers with p_values as inequalities: {0}".format(papers_with_inequalities)
# 	print "Total number of p_values as inequalities: {0}".format(total_inequalities)

# def run_extract_pvalues_with_inequalities(md_filepath_list):
# 	results_dict = {}
# 	for path in md_filepath_list:
# 		text = get_full_text_from_md_filepath(path)
# 		p_values = extract_p_values(text)
# 		inequalities = find_inerqualities(p_values, text)
# 		results_dict.update({path:inequalities})
# 	print_p_values(results_dict)
# 	return results_dict


# See if the match string contains an inequality
# def find_inequalities(p_values, text):
# 	inequalities = []
# 	for p in p_values:
# 		p_string = get_match_text(p, text)
# 		match = p_regex.search(p_string)
# 		groupdict = match.groupdict()
# 		operand = groupdict["operand"]
# 		if (">" in p_string or "<" in p_string or "≤" in p_string or "≥" in p_string or "&gt" in p_string or "&lt" in p_string):
# 			inequalities.append(p)
# 	return inequalities
#
# Extract the p value itself and see if is greater than .001
# def find_bad_inequalities(inequalities, text):
# 	bad_inequalities = []
# 	for i in inequalities:
# 		digits = re.search(r"\.?\d+(\.\d+)?", i.match_string(text))
# 		if not digits:
# 			print "found no digits for the p value: ", text[i.position[0]-10:i.position[1]+10]
# 			bad_inequalities.append(i)
# 		else:
# 			value = round(float(digits.group()), 3)
# 			if value > 0.001:
# 				bad_inequalities.append(i)
# 	return bad_inequalities
#
