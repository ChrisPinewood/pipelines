# -*- coding: utf-8 -*-

import re
import scipy.stats as stats
from decimal import Decimal
import math

from helpers.file_fns import *
from helpers.parker_regexs import r_test_regex, p_regex
from helpers.general_fns import *
from helpers.test_result import *

comma_regex = re.compile("[\,\.]$")


# main functions
def tell_penelope_r_tests_match_pvals(text, valid_r_tests = None):
	if not valid_r_tests:
		valid_r_tests, invalid_r_tests  = check_r_tests_in_text(text)
	for r in valid_r_tests:
		tell_penelope(r)

def check_r_tests_in_text(text):
	# returns all t tests reported in the article body
	# it divides the results into 2 tail and 1 tail tests, depending on which fits the p value
	# a pass = False when the given p value matches neither a 1 or 2 tailed recomputed p-value
	valid_results = []
	valid_r_tests, invalid_r_tests = extract_and_compute_r_tests(text)
	if valid_r_tests:
		for r in valid_r_tests:
			if not r["pval_correct"]:
				p1 = r["obj"].position[0]
				p2 = r["obj"].position[1]
				correct = r["correct_pval_2tail"]
				result = TestResult("correct_r_test_2tail", False, (p1, p2), {"correct":correct})
			else:
				if r["one_tail_pval"]:
					p1 = r["obj"].position[0]
					p2 = r["obj"].position[1]
					correct = r["correct_pval_1tail"]
					result = TestResult("correct_r_test_1tail", True, (p1, p2), {"correct":correct})
				else:
					p1 = r["obj"].position[0]
					p2 = r["obj"].position[1]
					correct = r["correct_pval_2tail"]
					result = TestResult("correct_r_test_2tail", True, (p1, p2), {"correct":correct})
			valid_results.append(result)
	invalid_results = []
	if invalid_r_tests:
		for r in invalid_r_tests:
			result = TestResult("r_tests_reported_well", False, (r.position[0], r.position[1]))
			invalid_results.append(result)
	if not (valid_results or invalid_results):
		valid_results = TestResult("r_tests_reported_well", None, (None, None))
	return valid_results, invalid_results


# sub functions

def extract_and_compute_r_tests(text):
	r_tests = extract_r_tests(text)
	components = None
	bad_r_tests = None
	if r_tests:
		components, bad_r_tests = extract_r_test_components(text, r_tests)
	return components, bad_r_tests

def extract_r_tests(text):
    r_tests = find_in_full_text(r_test_regex, text, "r_tests")
    return list(r_tests)

def extract_r_test_components(text, r_tests):
	r_test_components = []
	bad_r_tests = []
	for f in r_tests:
		string = text[f.position[0]:f.position[1]]
		matchgroup = r_test_regex.search(string)
		groupdict = matchgroup.groupdict()
		df = groupdict.get("r_df") or None
		df = float(df.strip()) if df else None
		N = groupdict.get("r_N") or None
		N = float(N.strip()) if N else None
		if (N and not df):
			df = N - 2
		if not (df or N):
			bad_r_tests.append(f)
			continue
		rval = groupdict.get("r_value1") or groupdict.get("r_value2")
		rval = float(comma_regex.sub("", rval).strip())
		pval = groupdict["r_test_p_value"]
		pval = float(comma_regex.sub("", pval).strip())
		lower_rval, upper_rval = compute_lower_and_upper_rounding_bounds(abs(rval))
		lower_pval_1tail, lower_pval_2tail = compute_correct_pval_r_test(lower_rval, df)
		upper_pval_1tail, upper_pval_2tail = compute_correct_pval_r_test(upper_rval, df)
		exact_pval_1tail, exact_pval_2tail = compute_correct_pval_r_test(rval, df)
		operand = groupdict["operand"]
		dp = abs(Decimal(str(pval)).as_tuple().exponent)
		pval_correct, one_tail_pval = check_pval_for_r_statistic(operand, pval, lower_pval_2tail, upper_pval_2tail, lower_pval_1tail, upper_pval_1tail)
		r_test_components.append({
		"obj":f,\
		"df":df,\
		"N":N,\
		"rval":rval,\
		"pval":pval,\
		"operand":operand,\
		"lower_rval":lower_rval,\
		"upper_rval":upper_rval,\
		"lower_pval":lower_pval,\
		"upper_pval":upper_pval,\
		"pval_dp":dp,\
		"correct_pval_2tail":{"lower":lower_pval_2tail, "upper":upper_pval_2tail, "exact":exact_pval_2tail},\
		"correct_pval_1tail":{"lower":lower_pval_1tail, "upper":upper_pval_1tail, "exact":exact_pval_2tail},\
		"one_tail_pval":one_tail_pval,\
		"pval_correct":pval_correct
		})
	return r_test_components, bad_r_tests

def check_pval_for_r_statistic(operand, pval, lower_pval_2tail, upper_pval_2tail, lower_pval_1tail, upper_pval_1tail):
	pval_correct = False
	one_tail = False
	if "=" in operand:
		if ((round(lower_pval_2tail, dp) <= pval) and (pval <= round(upper_pval_2tail, dp))):
			pval_correct = True
		elif ((round(lower_pval_1tail, dp) <= pval) and (pval <= round(upper_pval_1tail, dp))):
			pval_correct = True
			one_tail = True
	elif (">" in operand or "≥" in operand or "&gt" in operand):
		if (upper_pval_2tail > pval):
			pval_correct = True
	else:
		if (lower_pval_1tail < pval):
			pval_correct = True
	return pval_correct, one_tail

def compute_correct_pval_r_test(rval, df):
	if not df:
		return None
	t = rval/math.sqrt((1-rval*rval)/(df))
	correct_pval_1tail = stats.t.sf(t, df)
	correct_pval_2tail = correct_pval_1tail*2
	return correct_pval_1tail, correct_pval_2tail

def get_r_test_details_for_multiple_filepaths(md_filepath_list):
    all_results = {}
    for path in md_filepath_list:
        text = get_full_text_from_md_filepath(path)
        components, bad_r_tests = extract_and_compute_r_tests(text)
        if components:
			all_results.update({path:{"good_r_test_components":components, "bad_r_tests": bad_r_tests}})
    return all_results

def compare_r_test_details(all_results):
	for p in all_results.keys():
		if all_results[p]:
			for t in all_results[p]:
				operand = t["operand"]
				correct_rounded = t["correct_pval_2tail_r_test"]
				if not correct_rounded:
					print "Wrong r reporting format for {0}".format(p)
					continue
				dp = abs(Decimal(str(t["pval"])).as_tuple().exponent)
				correct_rounded = round(correct_rounded, dp)
				if operand == "=":
					if round(abs(t["pval"] - correct_rounded), 4) > 0.001:
						print "problem with {0}".format(p)
						print "found mismatch: pval: {0}, correct: {1}".format(t["pval"], correct_rounded)#t["correct_pval_2tail_r_test"])
				if (">" in operand or "<" in operand or "≤" in operand or "≥" in operand):
					if (">" in operand or "≥" in operand):
						if (t["correct_pval_2tail_r_test"] < t["pval"]):
							print "found operand in {0}".format(p)
							print "ERROR, correct pvalue is not > {0}".format(t["pval"])
					else:
						if (t["correct_pval_2tail_r_test"] > t["pval"]):
							print "found operand in {0}".format(p)
							print "ERROR, correct pvalue is not < {0}".format(t["pval"])

def how_many_manuscripts_have_r_value(md_filepath_list):
	all_results = {}
	print len(md_filepath_list)
	for path in md_filepath_list:
		text = get_full_text_from_md_filepath(path)
		r_tests = find_in_full_text(r_only_regex, text, "r_tests")
		print len(list(r_tests))
		if r_tests:
			print "YES"
			all_results.update({path:list(r_tests)})
	return all_results

def run(md_filepath_list):
	a = get_r_test_details_for_multiple_filepaths(md_filepath_list)
	compare_r_test_details(a)
