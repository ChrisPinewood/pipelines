from helpers.general_fns import *
from helpers.test_result import TestResult
from helpers.parker_regexs import *

def check_for_title(text):
	p1 = None
	p2 = None
	passed = False
	raw_lines = text[0:800].split("\n\n")
	lines = [strip_punc_pattern_start_and_end.sub("", l) for l in raw_lines]
	for l in lines:
		if (len(l) > 40):
			if (len(l) < 200):
				p1 = text.find(l)
				p2 = p1 + len(l)
				passed = True
				break
# 	title_matches = find_in_full_text(title_regex, text[0:800], "title")
# 	result = title_matches[0] if title_matches else None
# 	if not result:
# 		result = TestResult("title", False, (None, None))
	result = TestResult("title_present", passed, (p1, p2))
	return result

def check_title_length(title_result, max):
	p1 = None
	p2 = None
	passed = False
	if title_result.passed:
		p1 = title_result.position[0]
		p2 = title_result.position[1]
		if ((p2 - p1) < max):
			passed = True
	result = TestResult("title_length", passed, (p1, p2))
	return result


def check_for_email(text, headings):
	intro = headings.get("introduction_h")
	cutoff = intro.position[0] if intro else -1
	results = find_in_full_text(email_regex, text[0:cutoff], "email")
	if not results:
		result = [TestResult("email", False, (None, None))]
	else:
		result = results[0]
	return result

def check_for_corresponding_author(text, headings):
	intro = headings.get("introduction_h")
	cutoff = intro.position[0] if intro else -1
	result = find_in_full_text(corresponding_author_h, text[0:cutoff], "corresponding_author")
	if not result:
		result = [TestResult("corresponding_author", False, (None, None))]
	return result
