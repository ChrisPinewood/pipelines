from helpers.parker_regexs import ref_regex
from helpers.general_fns import find_in_full_text
from helpers.test_result import TestResult
import re
match_num_ref = re.compile('^[#*_]*\d+\. *.*?$', flags=re.MULTILINE)
names = "(?:[.a-zA-Z' ,\-\-\&\:\*]+)"
# names = r"(?:[\D]+)"
match_alpha_ref = re.compile("^%s\([12]\d{3}\).*(?=\s)$" % names, flags=re.MULTILINE)


def get_references_simple(text, ref_h):
	#takes a reference heading object and returns reference entries after it
	references = []
	if ref_h:
		match = ref_regex.search(text[ref_h.position[0]:])
		if match:
			references = match.group()
			references = references.split("\n")
	return references

def find_num_references(text, passed, ref_h = None):
    """ find references starting with a number """
    offset = ref_h.position[1] if (ref_h and ref_h.passed) else 0
    text = text[offset:]
    matches = find_in_full_text(match_num_ref, text, 'find_num_references')
    if matches:
	    results = [TestResult('find_num_references', passed, (i.position[0] + offset, i.position[1] + offset)) for i in matches]
    else:
    	results = []
    return results

def find_alpha_references(text, passed, ref_h = None):
    """ find references organised alphabetically """
    offset = ref_h.position[1] if (ref_h and ref_h.passed) else 0
    if not offset:
    	return []
    text = text[offset:]
    matches = find_in_full_text(match_alpha_ref, text, 'find_alpha_references')
    results = [TestResult('find_alpha_references', passed, (i.position[0] + offset, i.position[1] + offset)) for i in matches]
    return results
    
def get_and_check_ref_style(text, ref_h, correct_style = "num"):
	""" checks that references are (predominantly) in the correct format, whether that's numerical or alphabetical
	returns a result, along with all references (in correct and incorrect format) and references that are only in correct format """
	test_results_to_return = []
	passed = None
	p1 = None
	p2 = None
	all_refs = []
	
	# check that the correct style has been used
	if ref_h:
		num_refs = find_num_references(text, True, ref_h)
		alpha_refs = find_alpha_references(text, passed, ref_h)
		num_refs.sort(key=lambda x: x.position[0], reverse=False)
		alpha_refs.sort(key=lambda x: x.position[0], reverse=False)
		correct_refs = num_refs if (correct_style == 'num') else alpha_refs
		incorrect_refs = alpha_refs if (correct_style == 'num') else num_refs
		all_refs += correct_refs
		all_refs += incorrect_refs
		if (correct_refs or incorrect_refs):
			if (len(correct_refs) > len(incorrect_refs)):
				passed = True
				p1 = correct_refs[0].position[0]
				p2 = correct_refs[-1].position[1]
			else:
				passed = False
				p1 = incorrect_refs[0].position[0]
				p2 = incorrect_refs[-1].position[1]
	test_results_to_return.append(TestResult("correct_ref_style_used_"+correct_style, passed, (p1, p2)))
	
	# check for any anomalous references that are a mismatch of style
	if ref_h:
		for i in incorrect_refs:
			test_results_to_return.append(TestResult("anomaly_ref_style_used", False, (i.position[0], i.position[1])))
			
	return test_results_to_return, all_refs, correct_refs
			
def get_reference_numbers(references, text):
    """ extract a list of reference numbers from list of reference objects """
    ints = []
    for r in references:
        # find the first number group (the reference's number)
        ref = r.match_string(text)
        num = re.search('\d+', ref).group()
        ints.append(int(num))
    return ints		
		
		
		