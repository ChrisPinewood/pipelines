from helpers.print_fns import *
from helpers.general_fns import find_in_full_text
from helpers.parker_regexs import *
from helpers.test_result import TestResult
from helpers.ethical_fns import *
from title_page_checks import *
from design_specific_auxiliary_checks import *



def do_study_design_checks(text, references, ref_h, type):
	if type == "consort":
		checks = do_consort_checks(text, references, ref_h)
	elif type == "arrive":
		checks = do_arrive_checks(text, references, ref_h)
	elif type == "prisma":
		checks = do_prisma_checks(text, references, ref_h)
	elif type == "moose":
		checks = do_moose_checks(text, references, ref_h)
	elif type == "entreq":
		checks = do_entreq_checks(text, references, ref_h)
	elif type == "care":
		checks = do_care_checks(text, references, ref_h)
	elif type == "srqr":
		checks = do_srqr_checks(text, references, ref_h)
	elif type == "strobe":
		checks = do_strobe_checks(text, references, ref_h)
	elif type == "stard":
		checks = do_stard_checks(text, references, ref_h)
	elif type == "remark":
		checks = do_remark_checks(text, references, ref_h)
	elif type == "tripod":
		checks = do_tripod_checks(text, references, ref_h)
	else:
		checks = []

	return checks

def do_consort_checks(text, references, ref_h):

	#Check registry code
	registration = extract_registration(text)

	# Check for declaration of Helsinki
	helsinki = extract_helsinki(text)

	# Check for informed consent
	consent = extract_consent(text)

	#Check for checklist citation
	checklist_citation = check_for_checklist_citation("consort", references, text)

	#Check for ethical approval
	ethics = extract_ethics(text)

	title = check_for_title(text)
	title_keywords = check_title_for_keywords(title, text, "consort")
	power_calculation = check_for_power_calculation(text)
	randomisation = check_for_randomisation(text)
	blinding = check_for_blinding(text)
	participant_flow_diagram = check_for_flow_diagram(text)

	return [registration, helsinki, consent, checklist_citation, ethics, title_keywords, power_calculation, randomisation, blinding, participant_flow_diagram]

def do_arrive_checks(text, references, ref_h):

	# check for arvo
	arvo = find_in_full_text(arvo_regex, text, "arvo")
	if not arvo:
		arvo = TestResult("arvo", False, (None, None))

	# check for mention of ethics
	ethics = extract_ethics(text)

	# check for title keywords
	title = check_for_title(text)
	title_keywords = check_title_for_keywords(title, text, "arrive")

	# check for citation
	citation = check_for_checklist_citation("arrive", references, text)
	return [arvo, ethics, citation]

def do_prisma_checks(text, references, ref_h):
	citation = check_for_checklist_citation("prisma", references, text)
	return [citation]

def do_moose_checks(text, references, ref_h):
	citation = check_for_checklist_citation("moose", references, text)
	return [citation]

def do_entreq_checks(text, references, ref_h):
	citation = check_for_checklist_citation("entreq", references, text)
	return [citation]

def do_care_checks(text, references, ref_h):
	citation = check_for_checklist_citation("care", references, text)
	return [citation]

def do_srqr_checks(text, references, ref_h):
	citation = check_for_checklist_citation("srqr", references, text)
	return [citation]

def do_strobe_checks(text, references, ref_h):
	citation = check_for_checklist_citation("strobe", references, text)
	return [citation]

def do_stard_checks(text, references, ref_h):
	citation = check_for_checklist_citation("stard", references, text)
	return [citation]

def do_remark_checks(text, references, ref_h):
	citation = check_for_checklist_citation("remark", references, text)
	return [citation]

def do_tripod_checks(text, references, ref_h):
	citation = check_for_checklist_citation("tripod", references, text)
	return [citation]
