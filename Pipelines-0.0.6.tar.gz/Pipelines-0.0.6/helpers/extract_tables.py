# -*- coding: utf-8 -*-

import re
from general_fns import *
from file_fns import *
from parker_regexs import p_str, t_str, f_str

dashes_regex = re.compile(r"(\|(\-+\|)+)")
cells_pre_string = "(\|(.*\|){"
cells_after_string = "^(\n\|([^\|\n]*\|)+)+"#{"
p_str_regex = re.compile(p_str)
t_str_regex = re.compile(t_str)
f_str_regex = re.compile(f_str)

def extract_dash_rows(text):
	dash_rows = find_in_full_text(dashes_regex, text, "dash_rows")
	return list(dash_rows)

def get_cell_widths(row_obj, text):
	row_str = text[row_obj.position[0]:row_obj.position[1]]
	cells = row_str.split("|")[1:-1]
	cell_widths = [len(c) for c in cells]
	return cell_widths

def get_top_row(row_obj, cell_widths, text):
	string = r"\|([^\|]{"+str(cell_widths[0])+","+str(cell_widths[0]+2)+"}\|)"
	string = r"\n("+string+r"((.|(?<!\|)\n(?!\|))*\|)?\n)+" #here we have (?<!\|)\n(?!\|) which will match new lines within cells
# 	for c in cell_widths[1:]:
# 		string = string + "([^\|]{"+str(c)+","+str(c+2)+"}\|)?"
	before_string = string + "$"
	before_pattern = re.compile(before_string)
	cells_before = before_pattern.search(text[:row_obj.position[0]])
	return cells_before

def get_rows_below(row_obj, cell_widths, text):
	string = r"\|([^\|]{"+str(cell_widths[0])+","+str(cell_widths[0]+2)+"}\|)"
	after_string = r"^(\n"+string+")"
	after_string = r"^\n("+string+r"((.|(?<!\|)\n(?!\|))*\|)?\n)+" #here we have (?<!\|)\n(?!\|) which will match new lines within cells
	after_pattern = re.compile(after_string)
	cells_after = after_pattern.search(text[row_obj.position[1]:])
	return cells_after

def get_column_headings(top_row_text):
	column_headings = top_row_text.split("|")[1:-1]
	column_headings = [c.strip() for c in column_headings]
	return column_headings

def get_rows_and_columns(table_rows_text):
	rows = table_rows_text.split("|\n|")
	results = []
	for r in rows:
		if r.startswith("\n|"):
			r = r[3:]
		if r.endswith("|\n"):
			r = r[:-3]
		columns = r.split("|")
		columns = [c.strip() for c in columns]
		results.append(columns)
	return results


# rows = extract_dash_rows(ex_text)
# row_obj = rows[0]
# cell_widths = get_cell_widths(row_obj, ex_text)
# top_row = get_top_row(row_obj, cell_widths, ex_text)
# table_rows = get_rows_below(row_obj, cell_widths, ex_text)
# headings = get_column_headings(top_row.group())
# table_cells = get_rows_and_columns(table_rows.group())

def run(md_filepath_list):
	for path in md_filepath_list:
		try:
			print "extracting tables for ", path.split("/")[-1]
			text = get_full_text_from_md_filepath(path)
			rows = extract_dash_rows(text)
			print "found {0} tables".format(len(rows))
			for row_obj in rows:
				cell_widths = get_cell_widths(row_obj, text)
				top_row = get_top_row(row_obj, cell_widths, text)
				table_rows = get_rows_below(row_obj, cell_widths, text)
				headings = get_column_headings(top_row.group())
				table_cells = get_rows_and_columns(table_rows.group())
				for heading in headings:
					p = p_str_regex.search(heading)
					if p:
						print "Found table with p values in ", path.split("/")[-1]
						print headings
					t = t_str_regex.search(heading)
					if t:
						print "Found table with t tests in ", path.split("/")[-1]
						print headings
					f = f_str_regex.search(heading)
					if f:
						print "Found table with f tests in ", path.split("/")[-1]
						print headings
		except:
			print "had probelm with a table in ", path.split("/")[-1]
		print "~~~"
		print ""
