import re

registry_regex_dict = {
"Australian New Zealand Clinical Trials Registry" : r"ACTRN\w+",\
"Brazilian Clinical Trials Registry" : r"RBR\-\w+",\
"Chinese Clinical Trial Registry" : r"ChiCTR[\-\w]+",\
"Clinical Research Information Service" : r"KCT\w+",\
"Clinical Trials Registry - India" : r"CTRI[/\w]+",\
"Cuban Public Registry of Clinical Trials" : r"RPCEC\w+",\
"EU Clinical Trials Register (EU-CTR)" : r"20\d\d\-\w+\-\w+",\
"German Clinical Trials Register (DRKS)" : r"DRKS\w+",\
"Iranian Registry of Clinical Trials (IRCT)" : r"IRCT\w+",\
"ISRCTN.org" : r"ISRCTN\w+",\
"Japan Primary Registries Network (JPRN)" : r"UMIN\w+",\
"Thai Clinical Trials Registry (TCTR)" : r"TCTR\w+",\
"The Netherlands National Trial Register (NTR)" : r"NTR\w+",\
"Pan African Clinical Trial Registry (PACTR)" : r"PACTR\w+",\
"Sri Lanka Clinical Trials Registry (SLCTR)" : r"SLCTR[\w/]+",\
"U.S. National Institute of Health - American" : r"NCT\w+",\
"CenterWatch" : r"20\d\d\d\d",\
"Prospero":"CRD\w+"
}

# Australian New Zealand Clinical Trials Registry (ANZCTR)	http://www.anzctr.org.au/	ACTRN12615000851561	ACTRN12615000851561	ACTRN12615000766516	
# Brazilian Clinical Trials Registry (ReBec)	http://www.ensaiosclinicos.gov.br/	RBR-4tbd4p	RBR-7b5ycz	RBR-9vw39v	
# Chinese Clinical Trial Registry (ChiCTR)	http://www.chictr.org/en/	ChiCTR-TRC-14005250	ChiCTR-PRC-06000005	ChiCTR-TRC-14004375	
# Clinical Research Information Service (CRiS), Republic of Korea	http://cris.nih.go.kr/cris/en/use_guide/cris_introduce.jsp	KCT0001411	KCT0001181	KCT0001164	
# Clinical Trials Registry - India (CTRI)	http://ctri.nic.in/Clinicaltrials/login.php	CTRI/2007/091/000002	CTRI/2011/11/002119	CTRI/2015/08/006094	
# Cuban Public Registry of Clinical Trials (RPCEC)	http://registroclinico.sld.cu/en/home	RPCEC00000173	RPCEC00000142	RPCEC00000135	
# EU Clinical Trials Register (EU-CTR)	https://www.clinicaltrialsregister.eu/	2010-023457-11	2012-001661-32	2007-005245-37	
# German Clinical Trials Register (DRKS)	https://drks-neu.uniklinik-freiburg.de/drks_web/	DRKS00003535	DRKS00003767	DRKS00006542	
# Iranian Registry of Clinical Trials (IRCT)	http://www.irct.ir/	IRCT138706271258N1	IRCT138712121731N1	IRCT138810142976N1	
# ISRCTN.org	http://www.isrctn.com/	ISRCTN33682933	ISRCTN13314752	ISRCTN81349560	
# Japan Primary Registries Network (JPRN)	http://rctportal.niph.go.jp/	UMIN000015683	UMIN000018449	UMIN000018682	
# Thai Clinical Trials Registry (TCTR)	http://www.clinicaltrials.in.th/	TCTR20150420001	TCTR20141212001	TCTR20150720002	
# The Netherlands National Trial Register (NTR)	http://www.trialregister.nl/trialreg/index.asp	NTR5268	NTR5260	NTR5263	
# Pan African Clinical Trial Registry (PACTR)	http://www.pactr.org/	PACTR201506001172164	PACTR201111000336400	PACTR201508001220273	
# Sri Lanka Clinical Trials Registry (SLCTR)	http://www.slctr.lk/	SLCTR/2015/013	SLCTR/2007/006	SLCTR/2012/008	
# Clinical Trial Registry of the University Medical Center Freiburg	-	Same as (DRKS)			
# DeReG - German Registry for Somatic Gene-Transfer Trials	-	Same as (DRKS)			
# Centre for Clinical Trials, Clinical Trials Registry - Chinese	http://www2.ccrb.cuhk.edu.hk/web/	Same as (ChiCTR)			
# U.S. National Institute of Health - American	https://clinicaltrials.gov/	NCT02017795	NCT00149461	NCT00509028	
# CenterWatch	http://www.centerwatch.com/	202406	202400	208658	
# South African National Clinical Trial Register	http://www.sanctr.gov.za/	Not Found			
# Cancer Trials Australia	http://www.cancertrialsaustralia.com/	2012-000138-20	CT646	115523	HS110-201
# EORTC Brain Tumor Group	http://www.eortc.org/clinical-trials/	EORTC-1320-BTG	EORTC-1221-ETF	EORTC-06083-LG	
# UK Clinical Research Network Portfolio Database	http://public.ukcrn.org.uk/Search/Portfolio.aspx	18555	5842	6890	
# Health Canada	http://www.hc-sc.gc.ca/dhp-mps/prodpharma/databasdonclin/index-eng.php	TCZ001	CQGE031B2204	D589SC00001	I3Y-MC-JPBL