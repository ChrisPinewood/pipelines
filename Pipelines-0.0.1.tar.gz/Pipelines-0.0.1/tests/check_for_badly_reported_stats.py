from helpers.general_fns import *
from helpers.test_result import *
from helpers.parker_regexs import *

def check_for_badly_reported_t_test(text, t_tests):
	matches = find_in_full_text(bad_t_regex, text, "t_tests_reported_well")
	if matches:
		results = [TestResult("t_tests_reported_well", False, (i.position[0], i.position[1])) for i in matches]
	else:
		if t_tests:
			results = [TestResult("t_tests_reported_well", True, (None, None))]
		else:
			results = []
	return results

def check_for_badly_reported_f_test(text, f_tests):
	matches = find_in_full_text(bad_f_regex, text, "f_tests_resported_well")
	if matches:
		results = [TestResult("f_tests_reported_well", False, (i.position[0], i.position[1]))]
	else:
		if f_tests:
			results = [TestResult("f_tests_reported_well", True, (None, None))]
		else:
			results = []
	return results
