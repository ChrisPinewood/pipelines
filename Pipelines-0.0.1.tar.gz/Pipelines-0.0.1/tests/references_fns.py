from helpers.parker_regexs import ref_regex

def get_references(text, ref_h):
	#takes a reference heading object and returns reference entries after it
	references = []
	if ref_h:
		match = ref_regex.search(text[ref_h.position[0]:])
		if match:
			references = match.group()
			references = references.split("\n")
	return references
