from setuptools import setup, find_packages

setup(
    name = 'Pipelines',
    version = '0.0.1',
    packages = find_packages(),
    install_requires = [
        "argparse",
    ],
    url = 'http://www.peneloperesearch.com/',
    author = 'Chris Westcott',
    author_email = 'chris@pinewood-solutions.com',
    description = 'Serve Penelope with Python tests'
)
# To build distributable:
#   python setup.py sdist
