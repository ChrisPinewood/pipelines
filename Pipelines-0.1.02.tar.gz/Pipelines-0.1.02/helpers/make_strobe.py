# -*- coding: utf-8 -*-
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

from email.MIMEBase import MIMEBase
from email import encoders

import urllib2
from urllib2 import Request, urlopen, URLError
import json

from resources.strobe_content import content
import tempfile
import subprocess
import time
import os

title = "#STROBE Statement—checklist of items that should be included in reports of observational studies"
instructions = "[INSERT INSTRUCTION TO AUTHOR HERE. TELL THEM HOW TO USE THE CHECKLIST AND HOW TO CITE IT]"
reference = "[INSERT REFERENCE OF ORIGINAL GUIDELINE HERE]"
additional_reference = "[INSERT REFERENCE FOR ADDITIONAL EXTENSION]"

header = r"| **Section** | **Have you reported these items?** | **Yes/No** |"
divider = "|--------------------|----------------------------------------------------------------|--------------|"
row = "| {0} | {1} |        |"

strobe_url = "https://api.typeform.com/v0/form/Lz47GB?key=8e5fc5954f3adfafa58cbf426d7c3c4c7bbf10eb&completed=true"

alex = "alex@peneloperesearch.com"
alexs_password = "ar3g0lag"

QUESTION = "strega"
EMAIL = "email"
answers = {"strega":1, "email":"jamesrharwood@gmail.com"}

def monitor_strobe_form(url):
	delay = 5
	print "monitoring strobe form every {} (+5) seconds".format(delay) # extra 2 second delay put in urlopen line below 
	finished = False
	cutoff = time.time()
	recurring_error = 0
	errors = []
	while not finished:
		try:
			url_now = url + "&since=" + str(cutoff)
			cutoff = time.time()	
			check_strobe_typeform(url_now)
			time.sleep(delay)
			recurring_error = 0
			errors = []
		except Exception as a:
			errors.append(str(a))
			print "There was an error in monitor_form: "+str(a)
			recurring_error += 1
			if recurring_error > 3:
				finished = True
				e = "There were 3 errors in a row so the STROBE server shut down. The errors were: "+str(a)
				for i in errors:
					e += i + "\n"
				send_error_warning("james@peneloperesearch.com", e)	

def check_strobe_typeform(url_now):
	try:
		request = Request(url_now)
	except urllib2.URLError as ex:
		print "problem wih requesting url: " + url_now
	try: 
		response = urlopen(request)
		time.sleep(5)
	except urllib2.URLError as ex:
		print "problem wih urlopen() with url: " + url_now
	data = json.loads(response.read())
	if data["responses"]:
		print "found {0} response(s)".format(len(data["responses"]))
		for r in data["responses"]:
			email_user_strobe(r["answers"])

def email_user_strobe(answers):
	add_ons = []
	if answers["list_19155575_choice_24561042"]:
		add_ons.append("strega")
	if answers["list_19155575_choice_24561043"]:
		add_ons.append("rds")
	make_strobe(add_ons)
	users_email = answers["email_19024504"]
	send_strobe_in_email(users_email)

def send_strobe_in_email(users_email): 
	msg = MIMEMultipart()
 
	msg['From'] = alex
	msg['To'] = users_email
	msg['Subject'] = "Your custom checklist"
 
 	text = "Here is your custom STROBE checklist"

	part1 = MIMEText(text, 'plain')
# 	part2 = MIMEText(html_message, 'html')
# 			 
# 	# Attach parts into message container.
# 	# According to RFC 2046, the last part of a multipart message, in this case
# 	# the HTML message, is best and preferred.
	msg.attach(part1)
# 	msg.attach(part2)
	
	filepath = os.path.expanduser("~/Penelope/files/custom_strobe.docx")
	filename = filepath.split("/")[-1]
	attachment = open(filepath, "rb")

	part = MIMEBase('application', 'octet-stream')
	part.set_payload((attachment).read())
	encoders.encode_base64(part)
	part.add_header('Content-Disposition', "attachment; filename= %s" % filename)

	msg.attach(part)
 
	server = smtplib.SMTP('smtp.gmail.com', 587)
	server.starttls()
	server.login(alex, alexs_password)
	text = msg.as_string()
	server.sendmail(alex, users_email, text)
	server.quit()


def make_strobe(add_ons):
# 	with tempfile.NamedTemporaryFile(delete=True, dir = os.path.expanduser("~/Penelope/files/")) as tmp:
	with open(os.path.expanduser("~/Penelope/files/md_construct.md"), "w") as tmp:
		tmp.write(title + "\n \n \n \n")
		tmp.write(instructions + "\n\n\n\n")
		tmp.write("You should reference the original guidelines as: \n\n\n<sup>1</sup>"+reference+"\n\n\n")
		if add_ons:
			for a in add_ons:
				tmp.write("<sup>"+str(add_ons.index(a)+2)+"</sup>"+additional_reference+"\n\n")		
		tmp.write(header)
		tmp.flush()
		tmp.write("\n" + divider)

		current_section = None
		current_subsection = None
		for item in content:
			section = item["section"]
			subsection = item["subsection"]
			if (section != current_section):
				tmp.write("\n"+row.format("**"+section+"**", "",))
				tmp.flush()
			current_section = section
			
			if (subsection and (subsection != current_subsection)):
				report_subsection = subsection
				current_subsection = subsection
			else:
				report_subsection = ""

			text = ""
			if item.get("item"):
				text += item["item"] 
				text += "<sup>1</sup>"
				tmp.write("\n"+row.format(report_subsection, text))
				report_subsection = ""
		
			if add_ons:
				for a in add_ons:
					if item.get(a):
# 						text += " " + item[a]
						text = item[a]
						text += "<sup>"+str(add_ons.index(a) + 2)+"</sup>"
						tmp.write("\n"+row.format(report_subsection, text))
		
# 			tmp.write("\n" + row.format(report_subsection, text))
			tmp.flush()

# 		with open(os.path.expanduser("~/Penelope/files/strobe_md_test.txt"), "w") as file:
# 			file.write(s)

		options = ["pandoc", "-f", "markdown", "-t", "html", tmp.name, "-o", os.path.expanduser("~/Penelope/files/custom_strobe.html")]
		subprocess.check_call(options)
		options = ["pandoc", "-f", "html", "-t", "docx", os.path.expanduser("~/Penelope/files/custom_strobe.html"), "-o", os.path.expanduser("~/Penelope/files/custom_strobe.docx")]
		subprocess.check_call(options)

		