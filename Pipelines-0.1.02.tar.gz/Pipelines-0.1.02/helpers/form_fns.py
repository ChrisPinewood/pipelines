import time
import json
import re
from general_medical.pipeline import *
from helpers.email_fns import *
import urllib
import urllib2
from urllib2 import Request, urlopen, URLError
import unicodedata
import sys
from helpers.docx_fns import *

reload(sys)
sys.setdefaultencoding('utf-8')
#paths, t = get_paths_text_on_james_computer()

my_email = "james@peneloperesearch.com"

file_dir = os.path.expanduser("~/Penelope/files/")
save_as = file_dir+"users_doc.docx"
save_as_md = file_dir+"users_doc.md"


url = "https://api.typeform.com/v0/form/YSO6Hv?key=8e5fc5954f3adfafa58cbf426d7c3c4c7bbf10eb&completed=true"

url2 = "https://api.typeform.com/v0/form/UU7dm2?key=8e5fc5954f3adfafa58cbf426d7c3c4c7bbf10eb&completed=true"

def monitor_form(url):
	delay = 5
	print "monitoring form every {} (+5) seconds".format(delay) # extra 2 second delay put in urlopen line below 
	finished = False
	cutoff = time.time()
	recurring_error = 0
	errors = []
	while not finished:
		try:
			url_now = url + "&since=" + str(cutoff)
			cutoff = time.time()	
			check_typeform(url_now)
			time.sleep(delay)
			recurring_error = 0
			errors = []
		except Exception as a:
			errors.append(str(a))
			print "There was an error in monitor_form: "+str(a)
			recurring_error += 1
			if recurring_error > 3:
				finished = True
				e = "There were 3 errors in a row so the server shut down. The errors were: "+str(a)
				for i in errors:
					e += i + "\n"
				send_error_warning("james@peneloperesearch.com", e)	
		
			

def check_typeform(url_now):
	try:
		request = Request(url_now)
	except urllib2.URLError as ex:
		print "problem wih requesting url: " + url_now
	try: 
		response = urlopen(request)
		time.sleep(5)
	except urllib2.URLError as ex:
		print "problem wih urlopen() with url: " + url_now
	data = json.loads(response.read())
	if data["responses"]:
		print "found {0} response(s)".format(len(data["responses"]))
		for r in data["responses"]:
			if r["answers"].get("textfield_18319548"): # switched away from email field as not all emails worked
# 			if r["answers"].get("email_17667971"):
				email_user(r["answers"])

def email_user(r):
# 	users_email = r["email_17667971"]
	users_email = r["textfield_18319548"]
	users_name = r["textfield_17671508"]
	report_type = get_equator_type(r)
	doc_addr = r["fileupload_17671918"]
	try:
		if doc_addr:
			if doc_addr.find(".docx") > -1:
				file = urllib.urlretrieve(doc_addr, save_as)
				save_md_from_docx(save_as, save_as_md)
				
				text = get_clean_text_from_md_filepath(save_as_md)
				
				doc_name = doc_addr.split("/")[-1]
				doc_name = doc_name.split(".")[0].split("-",1)[-1]
				
				journal = "icmje"
				
				all_checks = get_results(text, report_type, journal)

				feedback_url = "http://penelope-demo.herokuapp.com/check?type="+report_type+"&journal="+journal+"&file="+doc_addr.split("/")[-1].split("?key=")[0]

				try:
					text_list_from_docx = get_text_from_docx(save_as)
					docx_text = "".join(text_list_from_docx)
					conv_list = get_conversion_list_for_two_strings(text, docx_text)
					docx_text_map = get_mapping_for_text_elems(text_list_from_docx)
					comments, reminders = turn_check_results_into_comments(all_checks, conv_list, docx_text_map)
					max_id = get_max_comment_id(save_as)
					commented_filepath = doc_name + "_commented.docx"
					print "expecting to add reminders: ", len(reminders)
					make_commented_docx(save_as, commented_filepath, comments, reminders, max_id, feedback_url)
					attachment_filepath = commented_filepath
					attachments = [attachment_filepath]
				except:
					attachment_filepath = file_dir+"Feedback_on_"+doc_name+".pdf"
					get_feedback_pdf_from_text(all_checks, text, report_type, journal, doc_name, users_name)				
					attachments = [attachment_filepath]
				
				if (report_type and checklist_attachment_dict.get(report_type)):
					for item in checklist_attachment_dict[report_type]:
						attachments.append(file_dir+item[1])

				create_email_html_message(users_name, report_type, attachment_filepath)

				send_email_with_attachment(users_email, users_name, attachments, feedback_url)

				os.remove(attachment_filepath)
			else: 
				warn_user(users_email, users_name)
		else:
			print "couldn't send. No document"
	except Exception as a:
		e = "There was an error. The user was notified. The error was:\n\n"+str(a)
		e+="\n\nThe typeform response was:\n\n"
		e += str(r)
		send_user_fail_mail(users_email, users_name)
		send_error_warning(my_email, e)
	

report_type_logic_dict = {
	"arrive":{"1":["yesno_17667959"], "0":["yesno_17667958"]},\
	"entreq":{"1":["yesno_17667968"], "0":["yesno_17667960"]},\
	"care":{"1":["yesno_17667969"], "0":[]},\
	"srqr":{"1":[], "0":["yesno_17667969"]},\
	"moose":{"1":["yesno_17667962"], "0":[]},\
	"prisma":{"1":[], "0":["yesno_17667962"]},\
	"consort":{"1":["yesno_17667963"], "0":[]},\
	"strobe":{"1":["yesno_17667964"], "0":[]},\
	"stard":{"1":["yesno_17667965"], "0":[]},\
	"remark":{"1":["yesno_17667966"], "0":[]},\
	"tripod":{"1":["yesno_17667967"], "0":[]},
	}
	
def get_equator_type(r):
	if r["list_18035029_choice"] == 'Research article':
		for k in report_type_logic_dict.keys():
			correct = True
			for yn in report_type_logic_dict[k].keys():
				for id in report_type_logic_dict[k][yn]:
					if r.get(id):
						if r[id] != yn:
							correct = False
					else:
						correct = False
			if correct:
				print "found report type: ", k
				return k
	elif r["list_18035029_choice"] == 'Invited review':
		return "review"
	elif r["list_18035029_choice"] == 'Letter':
		return "letter"
	else:
		return None 

### HERE is a copy of current question list

# [{u'id': u'fileupload_17671918', u'question': u'Upload your manuscript'},
#  {u'id': u'email_17667971',
#   u'question': u'What email should we send feedback to?'},
#  {u'id': u'textfield_17671508',
#   u'question': u'Got it. And what should we call you?'},
#  {u'id': u'list_18035029_choice',
#   u'question': u'Thanks\xa0{{answer_17671508}}, what kind of manuscript is this?'},
#  {u'id': u'list_18035029_other',
#   u'question': u'Thanks\xa0{{answer_17671508}}, what kind of manuscript is this?'},
#  {u'id': u'yesno_17667958', u'question': u'Was your research on humans?'},
#  {u'id': u'yesno_17667959',
#   u'question': u'Was your research on animals in the lab?'},
#  {u'id': u'yesno_17667960',
#   u'question': u'Did your research generate quantitative data?'},
#  {u'id': u'yesno_17667961',
#   u'question': u'Did you combine and analyse (review) the results of previous studies?'},
#  {u'id': u'yesno_17667962',
#   u'question': u'Did you review observational (cohort, case-control, or cross-sectional) studies?'},
#  {u'id': u'yesno_17667963',
#   u'question': u'Was your study a randomized trial comparing two or more health interventions?'},
#  {u'id': u'yesno_17667964',
#   u'question': u'Did your study explore the relationship between exposure to risk or protective factors and outcomes?'},
#  {u'id': u'yesno_17667965',
#   u'question': u'Did you compare the accuracy of a new or alternative diagnostic test against an established one (reference standard)?'},
#  {u'id': u'yesno_17667966',
#   u'question': u'Did the study evaluate the prognostic value of one or more biomarkers?'},
#  {u'id': u'yesno_17667967',
#   u'question': u'Did the research develop, validate or update a general prediction model for diagnosis or prognosis?'},
#  {u'id': u'yesno_17667968',
#   u'question': u'Did you combine and analyse (review) the results of previous studies?'},
#  {u'id': u'yesno_17667969',
#   u'question': u'Did you study a clinical case, or series of cases?'}]