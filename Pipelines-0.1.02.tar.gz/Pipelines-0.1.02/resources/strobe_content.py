# -*- coding: UTF-8 -*-

content = [
## Title and Abstract

#1a
{
"item":"Indicate the study's design with a commonly used term in the title or the abstract. ",\
"rds":"Indicate “respondent-driven sampling” in the title or abstract. ",\
"section":"Title and Abstract",\
"subsection": None,\
"requirements": None
},\

#1b
{
"item":"Provide in the abstract an informative and balanced summary of what was done and what was found",\
"section":"Title and Abstract",\
"subsection": None,\
"requirements": None
},\

#2
{
"item":"Explain the scientific background and rationale for the investigation being reported",\
"section":"Introduction",\
"subsection": "Background",\
"requirements": None
},\

#3
{
"item":"State specific objectives, including any prespecified hypotheses",\
"strega":"State if the study is the first report of a genetic association, a replication effort, or both.",\
"section":"Introduction",\
"subsection": "Objectives",\
"requirements": None
},\

#4
{
"item":"Present key elements of study design early in the paper",\
"rds":"State why respondant driven sampling was chosen as the sampling method",\
"section":"Methods",\
"subsection": "Study Design",\
"requirements": None
},\

#5
{
"item":"Describe the setting, locations, and relevant dates, including periods of recruitment, exposure, follow-up, and data collection",\
"rds":"Describe formative research findings used to inform RDS study.",\
"section":"Methods",\
"subsection": "Setting",\
"requirements": None
},\

#6a & b
{
"item":"""*Cohort study* - Give the eligibility criteria, and the sources and methods of \
selection of participants. Describe methods of follow-up. For matched studies, give matching criteria and number of exposed and unexposed \
*Case-control study* - Give the eligibility criteria, and the sources and methods of \
case ascertainment and control selection. Give the rationale for the choice of cases and controls. For matched studies, give matching criteria and the number of controls per case \
*Cross-sectional study* - Give the eligibility criteria, and the sources and methods of selection of participants""",\
"rds":"Describe how participants were trained/instructed to recruit others, number of coupons issued per person, any time limits for referral. \
Describe methods of seed selection and state number at start of study and number added later. \
State if there was any variation in study procedures during data collection (e.g., changing numbers of coupons per recruiter, interruptions in sampling, or stopping recruitment chains). \
Report wording of personal network size question(s). \
Describe incentives for participation and recruitment",\

"strega":"Give information on the criteria and methods for selection of subsets of participants from a larger study, when relevant.",\
"section":"Methods",\
"subsection": "Participants",\
"requirements": None
},\

#7
{
"item":"Clearly define all outcomes, exposures, predictors, potential confounders, and effect modifiers. Give diagnostic criteria, if applicable",\
"rds":"Clearly define correlates if applicable. State how recruiter–recruit relationship was tracked. ",\
"strega":"Clearly define genetic exposures (genetic variants) using a widely-used nomenclature system. Identify variables likely to be associated with population stratification (confounding by ethnic origin).",\
"section":"Methods",\
"subsection": "Variables",\
"requirements": None
},\

#8
{
"item":"For each variable of interest, give sources of data and details of methods of assessment (measurement). Describe comparability of assessment methods if there is more than one group",\
"strega":" (b) Describe laboratory methods, including source and storage of DNA, genotyping methods and platforms (including the allele calling algorithm used, and its version), error rates and call rates. State the laboratory/centre where genotyping was done. Describe comparability of laboratory methods if there is more than one group. Specify whether genotypes were assigned using all of the data from the study simultaneously or in smaller batches.",\
"rds":"Describe methods to assess eligibility and reduce repeat enrollment (e.g., coupon manager software, biometrics)",\
"section":"Methods",\
"subsection": "Data sources",\
"requirements": None
},\

#9
{
"item":"Describe any efforts to address potential sources of bias",\
"strega":"For quantitative outcome variables, specify if any investigation of potential bias resulting from pharmacotherapy was undertaken. If relevant, describe the nature and magnitude of the potential bias, and explain what approach was used to deal with this.",\
"section":"Methods",\
"subsection": "Bias",\
"requirements": None
},\

#10
{
"item":"Explain how the study size was arrived at",\
"section":"Methods",\
"subsection": "Study size",\
"requirements": None
},\

#11
{
"item":"Explain how quantitative variables were handled in the analyses. If applicable, describe which groupings were chosen and why",\
"strega":"If applicable, describe how effects of treatment were dealt with.",\
"section":"Methods",\
"subsection": "Quantitative variables",\
"requirements": None
},\

#12a
{
"item":"Describe all statistical methods, including those used to control for confounding",\
"rds":"Describe any methods used to account for sampling strategy (e.g., the estimator used). State data analysis software, version number, and specific analysis settings used.",\
"strega":"State software version used and options (or settings) chosen.",\
"section":"Methods",\
"subsection": "Statistical methods",\
"requirements": None
},\

#12b
{
"item":"Describe any methods used to examine subgroups and interactions",\
"section":"Methods",\
"subsection": "Statistical methods",\
"requirements": None
},\

#12c
{
"item":"Explain how missing data were addressed",\
"section":"Methods",\
"subsection": "Statistical methods",\
"requirements": None
},\

#12d
{
"item":"*Cohort study* - If applicable, explain how loss to follow-up was addressed \
*Case-control study* - If applicable, explain how matching of cases and controls was addressed \
*Cross-sectional study* - If applicable, describe analytical methods taking account of sampling strategy",\
"section":"Methods",\
"subsection": "Statistical methods",\
"requirements": None
},\

#12e
{
"item":"Describe any sensitivity analyses",\
"section":"Methods",\
"subsection": "Statistical methods",\
"requirements": None
},\

#12f
{
"item":None,\
"strega":"State whether Hardy-Weinberg equilibrium was considered and, if so, how.",\
"section":"Methods",\
"subsection": "Statistical methods",\
"requirements": None
},\

#12g
{
"item":None,\
"strega":"Describe any methods used for inferring genotypes or haplotypes.",\
"section":"Methods",\
"subsection": "Statistical methods",\
"requirements": None
},\

#12h
{
"item":None,\
"strega":"Describe any methods used to assess or address population stratification.",\
"section":"Methods",\
"subsection": "Statistical methods",\
"requirements": None
},\

#12i
{
"item":None,\
"strega":"Describe any methods used to address multiple comparisons or to control risk of false positive findings.",\
"section":"Methods",\
"subsection": "Statistical methods",\
"requirements": None
},\

#12j
{
"item":None,\
"strega":"Describe any methods used to address and correct for relatedness among subjects",\
"section":"Methods",\
"subsection": "Statistical methods",\
"requirements": None
},\

#12k
{
"item":None,\
"rds":"Report any criteria used to support statements on whether estimator conditions or assumptions were appropriate. ",\
"section":"Methods",\
"subsection": "Statistical methods",\
"requirements": None
},\

#12l
{
"item":None,\
"rds":"Explain how seeds were handled in analysis",\
"section":"Methods",\
"subsection": "Statistical methods",\
"requirements": None
},\

#13a
{
"item":"Report numbers of individuals at each stage of study-eg numbers potentially eligible, examined for eligibility, confirmed eligible, included in the study, completing follow-up, and analysed",\
"strega":"Report numbers of individuals in whom genotyping was attempted and numbers of individuals in whom genotyping was successful.",\
"section":"Results",\
"subsection": "Participants",\
"requirements": None
},\

#13b
{
"item":"Give reasons for non-participation at each stage",\
"section":"Results",\
"subsection": "Participants",\
"requirements": None
},\

#13c
{
"item":"Consider use of a flow diagram",\
"section":"Results",\
"subsection": "Participants",\
"requirements": None
},\

#13d
{
"item":None,\
"rds":"Report number of coupons issued and returned. ",\
"section":"Results",\
"subsection": "Participants",\
"requirements": None
},\

#13e
{
"item":None,\
"rds":"Report number of recruits by seed and number of RDS recruitment waves for each seed. Consider showing graph of entire recruitment network. ",\
"section":"Results",\
"subsection": "Participants",\
"requirements": None
},\


#13f
{
"item":None,\
"rds":"Report recruitment challenges (e.g., commercial exchange of coupons, imposters, duplicate recruits) and how addressed. ",\
"section":"Results",\
"subsection": "Participants",\
"requirements": None
},\


#13g
{
"item":None,\
"rds":"Consider reporting estimated design effect for outcomes of interest. ",\
"section":"Results",\
"subsection": "Participants",\
"requirements": None
},\

#14a
{
"item":"Give characteristics of study participants (eg demographic, clinical, social) and information on exposures and potential confounders",\
"strega":"Consider giving information by genotype.",\
"rds":"If applicable, give information on correlates and potential confounders. Report unweighted sample size and percentages, estimated population proportions or means with estimated precision (e.g., 95% confidence interval)",\
"section":"Results",\
"subsection": "Descriptive data",\
"requirements": None
},\

#14b
{
"item":"Indicate number of participants with missing data for each variable of interest",\
"section":"Results",\
"subsection": "Descriptive data",\
"requirements": None
},\

#14c
{
"item":"*Cohort study* - Summarise follow-up time (eg, average and total amount)",\
"section":"Results",\
"subsection": "Descriptive data",\
"requirements": None
},\

#15
{
"item":"*Cohort study* - Report numbers of outcome events or summary measures over time \
*Case-control study* - Report numbers in each exposure category, or summary measures of exposure \
*Cross-sectional study* - Report numbers of outcome events or summary measures. ",\
"strega":"Report  outcomes (phenotypes) for each genotype category over time",\
"section":"Results",\
"subsection": "Outcome data",\
"requirements": None
},\

#16a
{
"item":"Give unadjusted estimates and, if applicable, confounder-adjusted estimates and their precision (eg, 95% confidence interval). Make clear which confounders were adjusted for and why they were included",\
"rds":"Give study design–adjusted estimates.",\
"section":"Results",\
"subsection": "Main results",\
"requirements": None
},\

#16b
{
"item":"Report category boundaries when continuous variables were categorized",\
"section":"Results",\
"subsection": "Main results",\
"requirements": None
},\

#16c
{
"item":"If relevant, consider translating estimates of relative risk into absolute risk for a meaningful time period",\
"rds":"If adjustment of primary outcome leads to marked changes, report information on factors influencing the adjustments (e.g., personal network sizes, recruitment patterns by group, key confounders). ",\
"section":"Results",\
"subsection": "Main results",\
"requirements": None
},\

#16d
{
"item":None,\
"strega":"Report results of any adjustments for multiple comparisons.",\
"section":"Results",\
"subsection": "Main results",\
"requirements": None
},\

#17
{
"item":"Report other analyses done-eg analyses of subgroups and interactions, and sensitivity analyses",\
"rds":"Report different RDS estimators and definitions of personal network size.",\
"section":"Results",\
"subsection": "Other analyses",\
"requirements": None
},\

#17b
{
"item":None,\
"strega":"If numerous genetic exposures (genetic variants) were examined, summarize results from all analyses undertaken.",\
"section":"Results",\
"subsection": "Other analyses",\
"requirements": None
},\

#17c
{
"item":None,\
"strega":"If detailed results are available elsewhere, state how they can be accessed.",\
"section":"Results",\
"subsection": "Other analyses",\
"requirements": None
},\

#18
{
"item":"Summarise key results with reference to study objectives",\
"section":"Discussion",\
"subsection": "Key results",\
"requirements": None
},\

#19
{
"item":"Discuss limitations of the study, taking into account sources of potential bias or imprecision. Discuss both direction and magnitude of any potential bias",\
"section":"Discussion",\
"subsection": "Limitations",\
"requirements": None
},\

#20
{
"item":"Give a cautious overall interpretation of results considering objectives, limitations, multiplicity of analyses, results from similar studies, and other relevant evidence",\
"section":"Discussion",\
"subsection": "Interpretation",\
"requirements": None
},\

#21
{
"item":"Discuss the generalisability (external validity) of the study results",\
"section":"Discussion",\
"subsection": "Generalisability",\
"requirements": None
},\

#22
{
"item":"Give the source of funding and the role of the funders for the present study and, if applicable, for the original study on which the present article is based",\
"section":"Other Information",\
"subsection": "Funding",\
"requirements": None
}

]
