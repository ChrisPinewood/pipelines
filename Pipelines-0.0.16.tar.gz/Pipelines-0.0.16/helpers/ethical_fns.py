# -*- coding: utf-8 -*-

import re
from file_fns import *
from parker_regexs import t_test_regex, p_regex
from general_fns import *
from decimal import Decimal
comma_regex = re.compile("[\,\.]$")


def extract_registration(text):
	registration = find_in_full_text(registry_regex, text, "clinical_trial_registration")
	if not registration:
		registration = TestResult("clinical_trial_registration", False, (None, None))
	return registration

def extract_helsinki(text):
	# Check for declaration of Helsinki
	helsinki = find_in_full_text(declaration_of_helsinki_regex, text, "helsinki")
	if not helsinki:
		helsinki = TestResult("helsinki", False, (None, None))
	return helsinki

def extract_consent(text):
	# Check for informed consent
	consent = find_in_full_text(informed_consent_regex, text, "informed_consent")
	if not consent:
		consent = TestResult("informed_consent", False, (None, None))
	return consent

def extract_ethics(text):
    ethics = find_in_full_text(ethics_regex, text, "ethics")
    if not ethics:
    	ethics = TestResult("ethics", False, (None, None))
    return ethics

def extract_arvo(text):
	arvo = find_in_full_text(arvo_regex, text, "arvo")
	return arvo

def run(md_filepath_list):
	for path in md_filepath_list:
		print "processing ", path.split("/")[-1]
		text = get_full_text_from_md_filepath(path)
		ethics = extract_ethics(text)
		if ethics:
			print "found ethics"
		consent = extract_consent(text)
		if consent:
			print "found consent"
		arvo = extract_arvo(text)
		if arvo:
			print "found arvo"
		registration = extract_registration(text)
		if registration:
			print "found registration"
			for r in registration:
				print text[r.position[0]:r.position[1]]
