# -*- coding: utf-8 -*-
import re
import numpy
from test_result import TestResult
from parker_regexs import *
from collections import OrderedDict
from decimal import Decimal
num_pat = re.compile(r"(\d+)")
letter_pat = re.compile(r"[\w\)]")
cap_pat = re.compile(r"[\s\*]*[A-Z\r]")

def strip_punc(string, start_and_end = False):
    if not start_and_end:
	    stripped_string = strip_punc_pattern.sub("", string)
    else:
    	stripped_string = strip_punc_pattern_start_and_end.sub("", string)
    return stripped_string

def clean_string(string):
    string = strip_punc(string)
    string = string.lower()
    string = re.sub(r"^[\d\.\s]+", "", string) # removes numbers from start. Important for manuscripts with line numbers.
#     string = re.sub(triangles, "", string) # removes things between < and >
    return string

def remove_all_punctuation(string):
	new_string = re.sub("[^\w\s]", "", string)
	return new_string

def remove_all_spaces(string):
	new_string = re.sub(r"\s", "", string)
	return new_string

def find_in_full_text(regex, text, test_label):
    matches = []
    res = regex.search(text)
    results = regex.finditer(text)
    if res:
        for r in results:
            resultobj = TestResult(test_label, bool(res), position=r.span())
            matches.append(resultobj)

    return matches

def get_match_text(match_obj, text):
	s = text[match_obj.position[0]:match_obj.position[1]]
	return s

def return_nearest_neighbours(short_list, long_list):
	# takes two lists of integers, goes through the shorter list, item by item, and
	# matching it to its nearest neighbour from the longer list
	if (len(long_list) < len(short_list)):
		short_list, long_list = long_list, short_list
	x, y = map(numpy.asarray, (short_list, long_list))
	y_idx = numpy.arange(len(y))
	n = numpy.empty((len(x),), dtype=numpy.intp)
	for j, xj in enumerate(x):
		idx = numpy.argmin(numpy.abs(y - xj))
		n[j] = y_idx[idx]
		y = numpy.delete(y, idx)
		y_idx = numpy.delete(y_idx, idx)
		if not y.any():
			break
	return n

def return_out_of_order_integers_from_lists(mylist):
	mylist_no_duplicates = list(OrderedDict.fromkeys(mylist))
	mylist_pairs = zip(mylist_no_duplicates, mylist_no_duplicates[1:])
	problem_pair_indicies = []
	problem_index_pairs = []
	for s in mylist_pairs:
		if (s[0] > s[1]):
			index1 = mylist.index(s[0])
			index2 = mylist.index(s[1])
# 			problem_index_pairs.append((mylist_pairs.index(s), mylist_pairs.index(s) + 1))
			problem_index_pairs.append((index1, index2))
# 		elif (s[1] != s[0] + 1.0):
# 			index1 = mylist.index(s[0])
# 			index2 = mylist.index(s[1])
# # 			problem_index_pairs.append((mylist_pairs.index(s), mylist_pairs.index(s) + 1))
# 			problem_index_pairs.append((index1, index2))			
	return problem_index_pairs

def get_sentence_start(text, start):
	char = text[start]
	char_before = text[start - 1]
	chars_before = text[start-2:start-1]
	new_line = (chars_before == "\n")
	char_before_letter = letter_pat.search(char_before)
	chars_after = text[start+1:start+5]
	char_after_cap = cap_pat.search(chars_after)
	while not (new_line or (char == "." and char_before_letter and char_after_cap)):
		start -= 1
		char = text[start]
		char_before = text[start - 1]
		char_before_letter = letter_pat.search(char_before)
		chars_after = text[start+1:start+5]
		char_after_cap = cap_pat.search(chars_after)
	return start

def get_sentence_end(text, end):
	char = text[end]
	char_before = text[end - 1]
	char_before_letter = letter_pat.search(char_before)
	chars_after = text[end+1:end+5]
	char_after_cap = cap_pat.search(chars_after)
	while not (char == "." and char_before_letter and char_after_cap):
		try:
			end += 1
			char = text[end]
			char_before = text[end - 1]
			char_before_letter = letter_pat.search(char_before)
			chars_after = text[end+1:end+5]
			char_after_cap = cap_pat.search(chars_after)
		except:
			char_after_cap = True # reached the end of the manuscript
			char_before_letter = True
			char = "."
	return end

def get_surrounding_sentence(obj, text):
	start = obj.position[0]
	end = obj.position[1]
	sent_start = get_sentence_start(text, start)
	sent_end = get_sentence_end(text, end)
	sentence = text[sent_start:sent_end]
	return sentence

def compute_lower_and_upper_rounding_bounds(n):
	dp = abs(Decimal(str(n)).as_tuple().exponent)
	lower_bound = n - (0.5/float(10**dp))
	upper_bound = n + (0.49/float(10**dp))
	return lower_bound, upper_bound
