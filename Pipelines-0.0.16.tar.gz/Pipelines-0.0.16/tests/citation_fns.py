#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Tests for a variety of citation styles.
Note: this file is explicitly encoded utf-8 because of the specific use of dash/hyphen symbols : - –
"""
from helpers.parker_regexs import *
from helpers.general_fns import find_in_full_text
from helpers.test_result import TestResult
# from nltk.tokenize.regexp import wordpunct_tokenize
# from parker.data import stopwords
# from parker.helpers.references import get_reference_numbers
# from parker.helpers.citations import *
from copy import deepcopy
import re

def get_citations_and_style(text, references, abs_h, intro_h, correct_style = "num", ref_style = "num"):
    """
    Check which citation style a document uses, by finding which regex counts the most matches
    :param text: the text we are checking for citations
    :return: a str identifier for which style
    
    """
    if references:
	    references_s_and_e = (references[0].position[0], references[-1].position[1])
    else: 
    	references_s_and_e = (0, len(text))
    max_citations = len(references) + 20 if references else 20
    res_apa = find_apa_citations(text, references_s_and_e)
    res_sq_num = find_numbered_sq_citations(text, references_s_and_e)
    res_curly_num = find_numbered_curly_citations(text, references_s_and_e)
    res_sup = find_superscript_citations(text, references_s_and_e)
    
    #now we parse them and see how long each resulting set is
    # we have to do this as otherwise, manuscripts that have lots of superscript 2s (for example)
    # will be incorrectly identified as using superscript citations
    set_res_apa = set([c.match_string(text) for c in res_apa])
    g = []
    for c in res_sq_num:
	    g += parse_numbered_citation(c.match_string(text))
    set_res_sq_num = set(g)
    
    g = []
    for c in res_sup:
    	g += parse_numbered_citation(c.match_string(text))
    set_res_sup = set(g)
    
    g = []
    for c in res_curly_num:
    	g += parse_numbered_citation(c.match_string(text))
    set_res_curly_num = set(g)
        
    cit_style = ''
#   res_ordered = [res_apa, res_num, res_sup]
    if ref_style == "num":
    	res_ordered = [set_res_sq_num, set_res_curly_num, set_res_sup]
    else:
	    res_ordered = [set_res_apa, set_res_sq_num, set_res_curly_num, set_res_sup]

    res_ordered.sort(key=len)
    
    if references:
    	length_comparisons = [abs(len(references) - len(s)) for s in res_ordered]
    	most_likely = res_ordered[length_comparisons.index(min(length_comparisons))]
    else:
    	most_likely = res_ordered[-1]
    
    if (most_likely == set_res_apa):
    	cit_style = 'apa'
    	probable_citations = res_apa
    elif (most_likely == set_res_sq_num):
    	cit_style = 'num'
    	probable_citations = res_sq_num
    elif (most_likely == set_res_curly_num):
    	cit_style = 'num'
    	probable_citations = res_curly_num    
    elif (most_likely == set_res_sup):
    	cit_style = 'num'
    	probable_citations = res_sup
    

    if (cit_style == correct_style):
    	cit_style_result = TestResult ("correct_cit_style_used_"+correct_style, True, (None, None))
    else:
    	cit_style_result = TestResult ("correct_cit_style_used_"+correct_style, False, (None, None))
	
    cit_in_abs = []
    if intro_h:
	    cit_after_intro = []
	    cit_in_abs = []
	    for c in probable_citations:
    		if c.position[0] > intro_h.position[0]:
    			cit_after_intro.append(c)
    		elif (abs_h.passed and intro_h.passed):
    			if c.position[0] > abs_h.position[0]:
    				cit_in_abs.append(TestResult("citation_in_abstract", False, (c.position[0], c.position[1])))
    else:
    	cit_after_intro = probable_citations
    return cit_style_result, cit_after_intro, cit_in_abs, cit_style

def get_citation_numbers(citations, text):
	all_citation_ints = []
	set_citation_ints = []           # we can't use an actual set because ordering is useful here
	set_citation_ints_detail = []
	
	for r in citations:
		s = r.position[0]
		e = r.position[1]
		ints_in_citations = parse_numbered_citation(r.match_string(text))
		for i in ints_in_citations:
			if i not in all_citation_ints:
				cit_string = r.match_string(text)
				c_s = cit_string.find(str(i))
				if c_s > -1:
					p1 = s + c_s
					p2 = s + c_s + len(str(i))
				else:
					p1 = s
					p2 = e
				set_citation_ints_detail.append([int(i), p1, p2])
# 		[set_citation_ints_detail.append([int(i), s, e]) for i in ints_in_citations if i not in all_citation_ints]
		all_citation_ints.extend(ints_in_citations)
# 		[set_citation_ints.append(i) for i in ints_in_citations if i not in set_citation_ints]
	
	return set_citation_ints_detail

def verify_sequence_of_num_citations(cit_nums, text):
	"""
	Check that numbered citations are correct. Three tests:
	* ensure the citations appear in the correct order
	* ensure there are no numbers missing from sequence
	"""
	sorted_set = sorted(cit_nums, key=lambda x: x[0])
	results = []
	
	# Check if we see the citations in the right order
	if cit_nums != sorted_set:
		for i in range(len(cit_nums)-1):
			present = cit_nums[i+1]
			prev = cit_nums[i]
# 			if (int(present[0]) != (int(prev[0]))+1):
			if (int(present[0])-1) not in [y[0] for y in cit_nums[:i+1]]:
				p1 = present[1]
				p2 = present[2]
# 				c_start = text[present[1]:present[2]].find(str(present[0]))
# 				if c_start > 0:
# 					p1 = present[1]+c_start
# 					p2 = present[1] + c_start + len(str(present[0]))
# 				else:
# 					p1 = present[1]
# 					p2 = present[2]
				results.append(TestResult('verify_num_citation_seq:numerical_order', False, (p1, p2)))		
	# Check there are no missing citations	
	for i in range(len(sorted_set)-1):
		if sorted_set[i][0] != (sorted_set[i+1][0] - 1):
			result = TestResult('verify_num_citation_seq:full_sequence', False, (sorted_set[i+1][1], sorted_set[i+1][2]))
			results.append(result)		
	# We only have results if the checks failed; report these or return a successful result
	if results:
		return results
	else:
		results.append(TestResult('verify_num_citation_seq:numerical_order', True))
		results.append(TestResult('verify_num_citation_seq:full_sequence', True))
		return results
        
def parse_numbered_citation(citation):
    """
    (helper function) Get a list of integers for a numbered citation (bracketed or superscript), including enumerating ranges
    :param citation: a single numbered citation string, e.g. '[5-8, 11]'
    :return: a list of integers referred to, e.g. [5, 6, 7, 8, 11]
    """
    stripped = re.sub('\.*<sup>|</sup>|\[|\]|\(|\)|\\\\', '', citation)

    ints = []
    for s in re.split('[,; ]+', stripped):
        try:
            i = int(s)
            ints.append(i)
        except ValueError:
            match_dashes = re.compile('[- –]+')
            if match_dashes.search(s):
                # we have a range; enumerate it
                split = match_dashes.split(s)
                (start, end) = (split.pop(0), split.pop())
                if start.isdigit() and end.isdigit():
                    ints.extend(range(int(start), int(end) + 1))
    return ints
    
def find_apa_citations(text, references_s_and_e):
    """ The favoured method for finding citations. Checks for a name followed by a date. Requires filtering for good results."""
    all_results = find_in_full_text(apa_citation_regex, text, 'find_apa_citations_name_prefix')
    not_in_ref_section = []
    refs, refe = references_s_and_e
    for a in all_results:
    	if ((a.position[1] < refs) or (a.position[0] > refe)):
    		not_in_ref_section.append(a)
    return not_in_ref_section

def find_numbered_sq_citations(text, references_s_and_e):
    """ Find numbers or ranges of numbers within [] brackets. """
    all_results = find_in_full_text(square_bracket_citation_regex, text, 'find_numbered_citations')
    not_in_ref_section = []
    refs, refe = references_s_and_e
    for a in all_results:
    	if ((a.position[1] < refs) or (a.position[0] > refe)):
    		not_in_ref_section.append(a)
    return not_in_ref_section

def find_numbered_curly_citations(text, references_s_and_e):
    """ Find numbers or ranges of numbers within () or {} brackets. """
    all_results = find_in_full_text(curly_bracket_citation_regex, text, 'find_numbered_citations')
    not_in_ref_section = []
    refs, refe = references_s_and_e
    for a in all_results:
    	if ((a.position[1] < refs) or (a.position[0] > refe)):
    		if not (date_regex.search(a.match_string(text))):
	    		not_in_ref_section.append(a)
    return not_in_ref_section
    
def find_superscript_citations(text, references_s_and_e):
    """ Numbers or ranges within superscript tags. Tends to also pick up formulae """
    all_results = find_in_full_text(superscript_citation_regex, text, 'find_superscript_citations')
    not_in_ref_section = []
    refs, refe = references_s_and_e
    for a in all_results:
    	if ((a.position[1] < refs) or (a.position[0] > refe)):
    		not_in_ref_section.append(a)
    return not_in_ref_section