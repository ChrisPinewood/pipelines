#!/usr/bin/env python
# -*- coding: utf-8 -*-
import re
from helpers.test_result import TestResult
from tests.citation_fns import *


def verify_num_citation_in_references(cit_nums, ref_nums, text):
    """ The main functions we runt to check that a citation found in the text exists in the references section """
    just_ref_nums = [c[0] for c in ref_nums] #ref_nums is a list of lists, with each sublist being the number followed by position of the reference
    all_citation_ints = []
    set_citation_ints = []           # we can't use an actual set because ordering is useful here
    results = []

    for r in cit_nums:
    	s = r[1]
    	e = r[2]
    	#         ints_in_citations = set(parse_numbered_citation(r.match_string(text)))
    	#         missing_citations = ints_in_citations.difference(just_ref_nums)
    	#         if missing_citations:
    	if r[0] not in just_ref_nums:
            result = TestResult(test='verify_citation_in_references', passed=False, position=(s, e))
            results.append(result)

    if results:
        return results
    else:
        result = TestResult('verify_citation_in_references', True)
        return [result]
    
def verify_num_references_in_citations(references, cit_nums, ref_h, text):
    """ The main functions we run to check that references section contains found citations """
    just_cit_nums = [c[0] for c in cit_nums] #cit_nums is a list of lists, with each sublist being the number followed by position of the citation
    results = []
    if ref_h:
        (s, e) = ref_h.position
	for ref in references:
		(refs, refe) = ref.position
		num = re.search('\d+', ref.match_string(text)).group()
		if int(num) not in just_cit_nums and refs > e:
			# the following search is to find the end of the numeric section
			# we'll use this so we don't cock up the lists' numbers
# 			dotGroup = re.search('\. ', ref.match_string(text))
# 			if dotGroup:
# 				(dots, dote) = re.search('\. ', ref.match_string(text)).span()
# 
# 				result = TestResult('verify_references_in_citations', False, position=(refs + dote, refe))
# 				results.append(result)
			result = TestResult('verify_references_in_citations', False, position=(refs, refe))
			results.append(result)
    if results:
        return results
    else:
        result = TestResult('verify_references_in_citations', True)
        return [result]