# -*- coding: utf-8 -*-
import re

from helpers.file_fns import *
from helpers.parker_regexs import all_regexs as rexs
from helpers.general_fns import *
from helpers.extract_tables import *
letter_regex = re.compile(r"[a-z]+", flags = re.IGNORECASE)

### main functions

def perform_table_and_figure_checks(text, ref_h):

	#Check for figure/table legends
	table_legends, figure_legends = extract_legends(text)
	
	all_table_mentions = extract_table_mentions(text)
	table_citations = separate_citations_legends(all_table_mentions, table_legends)
	table_dashes = extract_dash_rows(text)
	tables = extract_all_tables(text)
	
	all_figure_mentions = extract_figure_mentions(text)
	figure_citations = separate_citations_legends(all_figure_mentions, figure_legends)
	extracted_media = find_in_full_text(figure_media_regex, text, "extracted_media")

	# find missing or unexpected tables
	# if the manuscript doesn't mention or include tables we send back empty results, except for 
	# tables_present_if_mentioned which will tell the user we didn't find any evidence of tables
	if not (table_citations or table_legends or tables):
		tables_present_if_mentioned  = []#TestResult("tables_present_if_mentioned", None, (None, None))
		surprise_tables, out_of_order_table_c, out_of_order_table_l = [], [], []
		missing_table_citations, missing_table_legends = [], []
	else:
		tables_present_if_mentioned, surprise_tables = find_missing_or_surprising_items("tables", table_legends, table_citations, tables, ref_h)
		#Check for figure/table citations that are out of order
		out_of_order_table_c = find_out_of_order_items(table_citations, "table_c", text)
		#check for figure/table legends that are out of order
		out_of_order_table_l = find_out_of_order_items(table_legends, "table_l", text)
		#check for missing tables/figure citations and legends
		missing_table_citations, missing_table_legends = compare_item_c_and_l("tables", table_citations, table_legends, text)

	# find missing or unexpected figures/media
	# if the manuscript doesn't mention or include figures we send back empty results, except for 
	# figures_present_if_mentioned which will tell the user we didn't find any evidence of figures

	if not (figure_legends or figure_citations or extracted_media):
		figures_present_if_mentioned = [] #TestResult("figures_present_if_mentioned", None, (None, None))
		surprise_figures, out_of_order_figure_c, out_of_order_figure_l = [], [], []
		missing_figure_citations, missing_figure_legends = [], []
	else:
		figures_present_if_mentioned, surprise_figures = find_missing_or_surprising_items("figures", figure_legends, figure_citations, extracted_media, ref_h)
		#Check for figure/figure citations that are out of order
		out_of_order_figure_c = find_out_of_order_items(figure_citations, "figure_c", text)
		#check for figure/figure legends that are out of order
		out_of_order_figure_l = find_out_of_order_items(figure_legends, "figure_l", text)
		#check for missing figures/figure citations and legends
		missing_figure_citations, missing_figure_legends = compare_item_c_and_l("figures", figure_citations, figure_legends, text)

	results_dict = {
	"tables_present_if_mentioned":tables_present_if_mentioned,\
# 	"legends_missing_tables":legends_missing_tables,\
	"surprise_tables":surprise_tables,\
	"out_of_order_table_c":out_of_order_table_c,\
	"out_of_order_table_l":out_of_order_table_l,\
	"missing_table_citations":missing_table_citations,\
	"missing_table_legends":missing_table_legends,\
	"figures_present_if_mentioned":figures_present_if_mentioned,\
# 	"legends_missing_figures":legends_missing_figures,\
	"surprise_figures":surprise_figures,\
	"out_of_order_figure_c":out_of_order_figure_c,\
	"out_of_order_figure_l":out_of_order_figure_l,\
	"missing_figure_citations":missing_figure_citations,\
	"missing_figure_legends":missing_figure_legends
	}

	return results_dict

#### Sub functions


def extract_legends(text):
	table_legends = find_in_full_text(rexs["tables_l"], text, "table_legends")
	figure_legends = find_in_full_text(rexs["figures_l"], text, "figure_legends")
	return table_legends, figure_legends

def extract_table_mentions(text):
	matches = find_in_full_text(rexs["tables_m"], text, "table_citations")
	return matches

def extract_figure_mentions(text):
	matches = find_in_full_text(rexs["figures_m"], text, "figure_citations")
	return matches

def separate_citations_legends(mentions, legends):
	legend_portions = [(h.position[0], h.position[1]) for h in legends]
	citations = []
	for c in mentions:
		to_append = True
		start = c.position[0]
		for p in legend_portions:
			if ((start > p[0]) and (start < p[1])):
				to_append = False
		if to_append:
			citations.append(c)
	return citations

def get_item_identifier(string, name):
	if (name.find("table")>-1):
		id_matches = get_table_or_figure_identifier(string, "tables_m")
	elif (name.find("figure")>-1):
		id_matches = get_table_or_figure_identifier(string, "figures_m")
	else:
		print "problem in 'get_item_identifier', the passed name ("+string+") doesn't specify whether it's a table of figure"
	return id_matches

def get_table_or_figure_identifier(text, regex_key):
	id_match = None
	raw_id_matches = []
	clean_ids = []
	match = rexs[regex_key].search(text)
	if match:
		raw_id_match = match.groupdict()["identifier"]
		if id_match == "":
			id_match = "0"
		raw_id_matches.append(raw_id_match)
		if match.groupdict().get("identifier2"):
			second_id = match.groupdict()["identifier2"]
			if second_id == "":
				second_id = "0"
			raw_id_matches.append(second_id)
	for r in raw_id_matches:
		r = r.replace(",", "")
		r = r.strip()
# commenting this out now as we aren'r doing anything useful with this info
# 		r = r.lower().replace("a", ".1").replace("b", ".2").replace("c", ".3").replace("d", ".4")
# 		r = r.replace("e", ".5").replace("f", ".6").replace("g", ".7").replace("h", ".8")
# 		r = r.replace("i", ".9").replace("j", ".91").replace("k", ".92").replace("l", ".93")		
		r = letter_regex.sub("", r)
		r = strip_punc(r, True)
		clean_ids.append(r)
	return clean_ids


def find_missing_or_surprising_items(table_or_fig, item_legends, item_citations, item_present, ref_h):
	if not ((table_or_fig.find("tables")>-1) or (table_or_fig.find("figures")>-1)):
		print "warning in find_missing_or_surprising_items: table_or_fig doesn't specify table or figure. The value given was: ", table_or_fig
	# see whether a manuscript contains items if it mentions them, and vice versa
	items_present_if_mentioned = []
	surprise_items = []
	# we assume that things like |---|---| are a table, and files ending with .png (for example) are figures.
	# I've called these item_present
	# First we see if items are mentioned when there are no items present
	if not item_present:
		if item_citations:
			# commented out this line because we only need to report this once
# 			for c in item_citations:
# 				items_present_if_mentioned.append(TestResult(table_or_fig + "_present_if_mentioned", False, (c.position[0], c.position[1])))
			items_present_if_mentioned.append(TestResult(table_or_fig + "_present_if_mentioned", False, (item_citations[0].position[0], item_citations[0].position[1])))

		elif item_legends:
			# commented this out because we only need to report this once
# 			for l in item_legends:
# 				items_present_if_mentioned.append(TestResult(table_or_fig + "_present_if_mentioned", False, (l.position[0], l.position[1])))
			items_present_if_mentioned.append(TestResult(table_or_fig + "_present_if_mentioned", False, (item_legends[0].position[0], item_legends[0].position[1])))

		else:
			pass
# 			items_present_if_mentioned.append(TestResult(table_or_fig + "_present_if_mentioned", None, (None, None)))
# 			surprise_items.append(TestResult("no_surprise_" + table_or_fig, None, (None, None)))
	# then we see if items are present if there aren't any mentioned
	else:
		if not (item_citations or item_legends):
			for d in item_present:
				p1 = d.position[0] if d else None
				p2 = d.position[1] if d else None
				surprise_items.append(TestResult("no_surprise_" + table_or_fig, False, (p1, p2)))
		else:
			surprise_items.append(TestResult("no_surprise_" + table_or_fig, True, (None, None)))
			items_present_if_mentioned.append(TestResult(table_or_fig + "_present_if_mentioned", True, (None, None)))
		if item_legends:
			# put the table/legend check here?!
			pass

	return items_present_if_mentioned, surprise_items

def find_out_of_order_items(objlist, name, text):
	identifiers = [get_item_identifier(obj.match_string(text), name) for obj in objlist]
	expanded_objlist = []
	for i in identifiers:
		a = []
		for t in range(len(i)):
			a.append(objlist[identifiers.index(i)])
		expanded_objlist += a

	identifiers = [item for sublist in identifiers for item in sublist]
	identifiers = [float(i) for i in identifiers]
	out_of_order_pairs = return_out_of_order_integers_from_lists(identifiers)
	out_of_order_objs = [(expanded_objlist[i[0]], expanded_objlist[i[1]]) for i in out_of_order_pairs]
	results = []
	if out_of_order_objs:
		for tuple in out_of_order_objs:
			s1 = tuple[0].position[0]
			e1 = tuple[0].position[1]
			s2 = tuple[1].position[0]
			e2 = tuple[1].position[1]
			result = TestResult("numerically_ordered_" + name, False, (s1, e1), {"other_citation_start":s2, "other_citation_end":e2})
			results.append(result)
	elif identifiers:
		result = TestResult("numerically_ordered_" + name, True, (None, None))
		results.append(result)
	else:
		result = TestResult("numerically_ordered_" + name, None, (None, None))
	return results

def compare_item_c_and_l(table_or_fig, item_citations, item_legends, text):
	
	# work out whether we are dealing with tables or figures
	item_l = "table_l" if (table_or_fig.find("tables")>-1) else "figure_l"
	item_c = "table_c" if (table_or_fig.find("tables")>-1) else "figure_c"
	
	# if the manuscript has no table/figure citations or legends then we tell the user we couldn't do 
	# these tests
	if not (item_citations or item_legends):
		missing_cs = TestResult("no_missing_" + item_c, None, (None, None))
		missing_ls = []
		return missing_cs, missing_ls	
		
	# get the identifiers from the string and put them into a flattened list
	# e.g. "Tables 1 & 2", "Table 3" -> [[1, 2], [3]] -> [1, 2, 3] 
	item_c_ids_grouped = [get_item_identifier(t.match_string(text), table_or_fig) for t in item_citations]
	item_c_ids = [item for sublist in item_c_ids_grouped for item in sublist]
	item_l_ids_grouped = [get_item_identifier(t.match_string(text), table_or_fig) for t in item_legends]
	item_l_ids = [item for sublist in item_l_ids_grouped for item in sublist]
	
	# compare citations with legends and find missing ones
	missing_c_ids = set(item_c_ids).difference(item_l_ids)
	missing_l_ids = set(item_l_ids).difference(item_c_ids)
	
	# work out the position in the lists
	missing_c_idxs = [i for i, x in enumerate(list(item_c_ids)) if x in list(missing_c_ids)]
	missing_l_idxs = [i for i, x in enumerate(list(item_l_ids)) if x in list(missing_l_ids)]
	missing_ls_separate = [item_c_ids[i] for i in missing_c_idxs]
	missing_cs_separate = [item_l_ids[i] for i in missing_l_idxs]
	
	# make TestResults for all
	missing_cs = []
	missing_ls = []
	done_cs = []
	done_ls = []
	for m in missing_ls_separate:
		if m not in done_ls:
			for i, x in enumerate(list(item_c_ids_grouped)):
				if m in x:
					if (item_citations[i] not in missing_ls) and (m not in done_ls): # we only want to prompt authors once for each missing table/figure legend
						s1 = item_citations[i].position[0]
						e1 = item_citations[i].position[1]
						result = TestResult("no_missing_" + item_l, False, (s1, e1))
						missing_ls.append(result)
						done_ls.append(m)

	for m in missing_cs_separate:
		if m not in done_cs:
			for i, x in enumerate(list(item_l_ids_grouped)):
				if m in x:
					if (item_legends[i] not in missing_cs) and (m not in done_cs):
						s1 = item_legends[i].position[0]
						e1 = item_legends[i].position[1]
						result = TestResult("no_missing_" + item_c, False, (s1, e1))
						missing_cs.append(result)
						done_cs.append(m)
	if not missing_cs:
		missing_cs.append(TestResult("no_missing_" + item_c, True, (None, None)))
	if not missing_ls:
		missing_ls.append(TestResult("no_missing_" + item_l, True, (None, None)))
	return missing_cs, missing_ls

# def check_amount_of_items(table_or_fig, items, item_ls):
# 	item_l = "table_l" if (table_or_fig.find("tables")>-1) else "figure_l"
#  
	

#### OLD CODE
#
# def get_table_identifier(string):
# 	id_matches = get_table_or_figure_identifier(string, "tables_m")
# 	return id_matches
#
# def get_figure_identifier(string):
# 	id_matches = get_table_or_figure_identifier(string, "figures_m")
# 	return id_matches
#
#
# def find_out_of_order_tables(objlist, name, text):
# 	identifiers = [get_table_identifier(obj.match_string(text)) for obj in objlist]
# 	identifiers = [item for sublist in identifiers for item in sublist]
# 	identifiers = [float(i) for i in identifiers]
# 	out_of_order_pairs = return_out_of_order_integers_from_lists(identifiers)
# 	out_of_order_objs = [(objlist[i[0]], objlist[i[1]]) for i in out_of_order_pairs]
# 	results = []
# 	if out_of_order_objs:
# 		for tuple in out_of_order_objs:
# 			s1 = tuple[0].position[0]
# 			e1 = tuple[0].position[1]
# 			s2 = tuple[1].position[0]
# 			e2 = tuple[1].position[1]
# 			result = TestResult("numerically_ordered_" + name, False, (s1, e1), {"other_citation_start":s2, "other_citation_end":e2})
# 			results.append(result)
# 	elif identifiers:
# 		result = TestResult("numerically_ordered_" + name, True, (None, None))
# 		results.append(result)
# 	else:
# 		result = TestResult("numerically_ordered_" + name, None, (None, None))
# 	return results
#
# def find_out_of_order_tables(objlist, name, text):
# 	identifiers = [get_table_identifier(obj.match_string(text)) for obj in objlist]
# 	identifiers = [item for sublist in identifiers for item in sublist]
# 	identifiers = [float(i) for i in identifiers]
# 	out_of_order_pairs = return_out_of_order_integers_from_lists(identifiers)
# 	out_of_order_objs = [(objlist[i[0]], objlist[i[1]]) for i in out_of_order_pairs]
# 	results = []
# 	if out_of_order_objs:
# 		for tuple in out_of_order_objs:
# 			s1 = tuple[0].position[0]
# 			e1 = tuple[0].position[1]
# 			s2 = tuple[1].position[0]
# 			e2 = tuple[1].position[1]
# 			result = TestResult("numerically_ordered_" + name, False, (s1, e1), {"other_citation_start":s2, "other_citation_end":e2})
# 			results.append(result)
# 	elif identifiers:
# 		result = TestResult("numerically_ordered_" + name, True, (None, None))
# 		results.append(result)
# 	else:
# 		result = TestResult("numerically_ordered_" + name, None, (None, None))
# 	return results
#
# def find_out_of_order_figures(objlist, name, text):
# 	identifiers = [get_figure_identifier(t.match_string(text)) for t in objlist]
# 	identifiers = [item for sublist in identifiers for item in sublist]
# 	identifiers = [float(i) for i in identifiers]
# 	out_of_order_indicies = return_out_of_order_integers_from_lists(identifiers)
# 	out_of_order_objs = [(objlist[i[0]], objlist[i[1]]) for i in out_of_order_indicies]
# 	results = []
# 	if out_of_order_objs:
# 		for tuple in out_of_order_objs:
# 			s1 = tuple[0].position[0]
# 			e1 = tuple[0].position[1]
# 			s2 = tuple[1].position[0]
# 			e2 = tuple[1].position[1]
# 			result = TestResult("numerically_ordered_" + name, False, (s1, e1), {"other_citation_start":s2, "other_citation_end":e2})
# 			results.append(result)
# 	elif identifiers:
# 		result = TestResult("numerically_ordered_" + name, True, (None, None))
# 		results.append(result)
# 	else:
# 		result = TestResult("numerically_ordered_" + name, None, (None, None))
# 	return results
#
# def extract_table_mention_sentences(match_objs, text):
# 	matches = [get_surrounding_sentence(text, obj.position[0], obj.position[1]) for obj in match_objs]
# 	return matches
#
#
#
#
# def find_missing_or_surprising_tables(table_legends, table_citations, table_dashes, ref_h):
# 	# see whether a manuscript contains tables if it mentions them, and vice versa
# 	citations_missing_tables = []
# 	legends_missing_tables = []
# 	surprise_tables = []
# 	# we assume that things like |---|---| are a table. I've called these table_dashes
# 	# First we see if tables are mentioned when there are no tables present
# 	if not table_dashes:
# 		if table_citations:
# 			for c in table_citations:
# 				citations_missing_tables.append(TestResult("tables_present_if_cited", False, (c.position[0], c.position[1])))
# 		elif table_legends:
# 			for l in table_legends:
# 				legends_missing_tables.append(TestResult("tables_present_if_legends", False, (l.position[0], l.position[1])))
# 		else:
# 			citations_missing_tables.append(TestResult("tables_present_if_cited", None, (None, None)))
# 			legends_missing_tables.append(TestResult("tables_present_if_legends", None, (None, None)))
# 			surprise_tables.append(TestResult("no_surprise_tables", None, (None, None)))
# 	# then we see if tables are present if there aren't any mentioned
# 	else:
# 		if not (table_citations or table_legends):
# 			for d in table_dashes:
# 				surprise_tables.append(TestResult("no_surprise_tables", False, (d.position[0], d.position[1])))
# 		else:
# 			surprise_tables.append(TestResult("no_surprise_tables", True, (None, None)))
# 			citations_missing_tables.append(TestResult("tables_present_if_cited", True, (None, None)))
# 			legends_missing_tables.append(TestResult("tables_present_if_legends", True, (None, None)))
#
#
# 	return citations_missing_tables, legends_missing_tables, surprise_tables
#
# def find_missing_or_surprising_figures(figure_legends, figure_citations, extracted_media, ref_h):
# 	# this does the same as the find_missing_or_surprising_tables.
# 	# I could probably merge the two...but not done that yet.
# 	citations_missing_figures = []
# 	legends_missing_figures = []
# 	surprise_figures = []
# 	if not extracted_media:
# 		if figure_citations:
# 			for c in figure_citations:
# 				citations_missing_figures.append(TestResult("figures_present_if_cited", False, (c.position[0], c.position[1])))
# 		elif figure_legends:
# 			for l in figure_legends:
# 				legends_missing_figures.append(TestResult("figures_present_if_legends", False, (l.position[0], l.position[1])))
# 		else:
# 			citations_missing_figures.append(TestResult("figures_present_if_cited", None, (None, None)))
# 			legends_missing_figures.append(TestResult("figures_present_if_legends", None, (None, None)))
# 			surprise_figures.append(TestResult("no_surprise_figures", None, (None, None)))
# 	else:
# 		if not (figure_citations or figure_legends):
# 			for d in extracted_media:
# 				surprise_figures.append(TestResult("no_surprise_figures", False, (d.position[0], d.position[1])))
# 		else:
# 			surprise_figures.append(TestResult("no_surprise_figures", True, (None, None)))
# 			citations_missing_figures.append(TestResult("figures_present_if_cited", True, (None, None)))
# 			legends_missing_figures.append(TestResult("figures_present_if_legends", True, (None, None)))
#
# 	return citations_missing_figures, legends_missing_figures, surprise_figures

#
# def compare_table_c_and_l(table_citations, table_legends, text):
# 	table_c_ids_grouped = [get_table_identifier(t.match_string(text)) for t in table_citations]
# 	table_c_ids = [item for sublist in table_c_ids_grouped for item in sublist]
# 	table_l_ids_grouped = [get_table_identifier(t.match_string(text)) for t in table_legends]
# 	table_l_ids = [item for sublist in table_l_ids_grouped for item in sublist]
# 	missing_c_ids = set(table_c_ids).difference(table_l_ids)
# 	missing_l_ids = set(table_l_ids).difference(table_c_ids)
# 	missing_c_idxs = [i for i, x in enumerate(list(table_c_ids)) if x in list(missing_c_ids)]
# 	missing_l_idxs = [i for i, x in enumerate(list(table_l_ids)) if x in list(missing_l_ids)]
# 	missing_ls_separate = [table_c_ids[i] for i in missing_c_idxs]
# 	missing_cs_separate = [table_l_ids[i] for i in missing_l_idxs]
# 	missing_cs = []
# 	missing_ls = []
# 	for m in missing_ls_separate:
# 		for i, x in enumerate(list(table_c_ids_grouped)):
# 			if m in x:
# 				if table_citations[i] not in missing_ls:
# 					s1 = table_citations[i].position[0]
# 					e1 = table_citations[i].position[1]
# 					result = TestResult("no_missing_table_l", False, (s1, e1))
# 					missing_ls.append(result)
# 	for m in missing_cs_separate:
# 		for i, x in enumerate(list(table_l_ids_grouped)):
# 			if m in x:
# 				if table_legends[i] not in missing_cs:
# 					s1 = table_legends[i].position[0]
# 					e1 = table_legends[i].position[1]
# 					result = TestResult("no_missing_table_c", False, (s1, e1))
# 					missing_cs.append(result)
# 	if not missing_cs:
# 		missing_cs.append(TestResult("no_missing_table_c", True, (None, None)))
# 	if not missing_ls:
# 		missing_ls.append(TestResult("no_missing_table_l", True, (None, None)))
# 	return missing_cs, missing_ls
#
# def compare_figure_c_and_l(figure_citations, figure_legends, text):
# 	figure_c_ids_grouped = [get_figure_identifier(t.match_string(text)) for t in figure_citations]
# 	figure_c_ids = [item for sublist in figure_c_ids_grouped for item in sublist]
# 	figure_l_ids_grouped = [get_figure_identifier(t.match_string(text)) for t in figure_legends]
# 	figure_l_ids = [item for sublist in figure_l_ids_grouped for item in sublist]
# 	missing_c_ids = set(figure_c_ids).difference(figure_l_ids)
# 	missing_l_ids = set(figure_l_ids).difference(figure_c_ids)
# 	missing_c_idxs = [i for i, x in enumerate(list(figure_c_ids)) if x in list(missing_c_ids)]
# 	missing_l_idxs = [i for i, x in enumerate(list(figure_l_ids)) if x in list(missing_l_ids)]
# 	missing_ls_separate = [figure_c_ids[i] for i in missing_c_idxs]
# 	missing_cs_separate = [figure_l_ids[i] for i in missing_l_idxs]
# 	missing_cs = []
# 	missing_ls = []
# 	for m in missing_ls_separate:
# 		for i, x in enumerate(list(figure_c_ids_grouped)):
# 			if m in x:
# 				if figure_citations[i] not in missing_ls:
# 					s1 = figure_citations[i].position[0]
# 					e1 = figure_citations[i].position[1]
# 					result = TestResult("no_missing_figure_l", False, (s1, e1))
# 					missing_ls.append(result)
# 	for m in missing_cs_separate:
# 		for i, x in enumerate(list(figure_l_ids_grouped)):
# 			if m in x:
# 				if figure_legends[i] not in missing_cs:
# 					s1 = figure_legends[i].position[0]
# 					e1 = figure_legends[i].position[1]
# 					result = TestResult("no_missing_figure_c", False, (s1, e1))
# 					missing_cs.append(result)
# 	if not missing_cs:
# 		missing_cs.append(TestResult("no_missing_figure_c", True, (None, None)))
# 	if not missing_ls:
# 		missing_ls.append(TestResult("no_missing_figure_l", True, (None, None)))
# 	return missing_cs, missing_ls
#
# def find_missing_or_surprising_items(table_or_fig, item_legends, item_citations, item_present, ref_h):
# 	if not ((table_or_fig.find("tables")>-1) or (table_or_fig.find("figures")>-1)):
# 		print "warning in find_missing_or_surprising_items: table_or_fig doesn't specify table or figure. The value given was: ", table_or_fig
# 	# see whether a manuscript contains items if it mentions them, and vice versa
# 	items_present_if_cited = []
# 	items_present_if_legends = []
# 	surprise_items = []
# 	# we assume that things like |---|---| are a table, and files ending with .png (for example) are figures.
# 	# I've called these item_present
# 	# First we see if items are mentioned when there are no items present
# 	if not item_present:
# 		if item_citations:
# 			for c in item_citations:
# 				items_present_if_cited.append(TestResult(table_or_fig + "_present_if_cited", False, (c.position[0], c.position[1])))
# 		elif item_legends:
# 			for l in item_legends:
# 				items_present_if_legends.append(TestResult(table_or_fig + "_present_if_legends", False, (l.position[0], l.position[1])))
# 		else:
# 			items_present_if_cited.append(TestResult(table_or_fig + "_present_if_cited", None, (None, None)))
# 			items_present_if_legends.append(TestResult(table_or_fig + "_present_if_legends", None, (None, None)))
# 			surprise_items.append(TestResult("no_surprise_" + table_or_fig, None, (None, None)))
# 	# then we see if items are present if there aren't any mentioned
# 	else:
# 		if not (item_citations or item_legends):
# 			for d in item_present:
# 				surprise_items.append(TestResult("no_surprise_" + table_or_fig, False, (d.position[0], d.position[1])))
# 		else:
# 			surprise_items.append(TestResult("no_surprise_" + table_or_fig, True, (None, None)))
# 			items_present_if_cited.append(TestResult(table_or_fig + "_present_if_cited", True, (None, None)))
# 			items_present_if_legends.append(TestResult(table_or_fig + "_present_if_legends", True, (None, None)))
#
#
# 	return items_present_if_cited, items_present_if_legends, surprise_items
