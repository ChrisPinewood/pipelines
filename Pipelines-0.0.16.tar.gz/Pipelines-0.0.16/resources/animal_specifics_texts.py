animal_specific_texts_dict = {

"arrive_checklist_cited":\
{"pass":"You have cited the ARRIVE guidelines",\
"fail":"Have you cited the ARRIVE guidelines?",\
"explain":"All experiments involving animals in vivo must adhere to the ARRIVE guidelines\
for the reporting of  animal research. You should then cite the ARRIVE statement in your\
reference section",\
"none":""
},\

"arvo":\
{"pass":"You have mentioned the ARVO statement",\
"fail":"Does your work adhere to the ARVO statement?",\
"explain":"""If you used animals in your research you must state, in the methods section, whether or not your work adheres to the [ARVO statement](http://www.arvo.org/about_arvo/policies/statement_for_the_use_of_animals_in_ophthalmic_and_visual_research/)""",\
# <a href = 'http://www.arvo.org/about_arvo/policies/statement_for_the_use_of_animals_in_ophthalmic_and_visual_research/'>\
# ARVO statement</a> for the use of animals in ophthalmic and visual research
"none":""
}

}