nih_specific_texts_dict = {

"power_calculation":\
{"pass":"You have included a power calculation",\
"fail":"Have you explained how you decided what sample size you needed?",\
"explain":"""You need to state whether an appropriate sample size was computed when the study was being designed and include the statistical method of computation. 

If you didn't do a power analysis before your experiment, explain how your sample size was determined instead. 

For your next experiment, you may find this [free power analysis tool](http://www.gpower.hhu.de/en.html) useful. You can also 
[learn why statistical power is important](http://www.nature.com/nrn/journal/v14/n5/full/nrn3475.html).""",\
"none":""
},\

"randomisation":\
{"pass":"You have addressed randomisation",\
"fail":"Have you explained how you randomly allocated subjects into experimental groups?",\
"explain":"""You need to explain whether samples were randomised and, if so, the method of randomisation. Good randomisation has two steps: 

1) generation of a random sequence. You might find this free [randomiser tool](https://www.randomizer.org/) useful in future. 

2) allocation of participants to groups using the sequence. You should explain who did each step and whether or not it was the same person. Ideally the sequence should have been implemented in a way that concealed the allocation until samples had been assigned to an experimental group. You might find [this article](http://www.ncbi.nlm.nih.gov/pmc/articles/PMC3427961/) useful - it uses clinical trials as an example but the theory is relevant to other types of experiment. """,\
"none":""
},\

"blinding":\
{"pass":"You have addressed blinding",\
"fail":"Have you explained whether participants and personnel were blinded?",\
"explain":"""Describe all measures used to [blind](https://en.wikipedia.org/wiki/Blind_experiment) study participants and personnel, so they didn't know which intervention a participant received. Include any information relating to whether the intended blinding was effective. 

If you didn't blind participants and personnel then state this, and explain why it wasn't possible.""",\
"none":""
},\

}