data_citation_texts_dict = {
"has_data_citation":\
{"pass":"You have cited a dataset",\
"fail":"Have you and published and cited your data?",\
"explain":"""All original research articles should cite the underlying raw data. You should publish your data in a [suitable repository]((http://www.re3data.org/)), and then cite the dataset in the body of your article. Make sure you include the citation in your reference list so that your manuscript and dataset can be linked together. 

[Learn more about citing and linking datasets to your publication](http://www.dcc.ac.uk/resources/how-guides/cite-datasets)

Publishing your data as well as your article doubles your research outputs, and there are lots of metrics you can use to [track the impact of your data](http://www.dcc.ac.uk/resources/how-guides/track-data-impact-metrics).

Publishing your data might be a requirement of your funding, so you should [check your funder's policy](http://www.sherpa.ac.uk/juliet/index.php).

If you're worried about sharing data, not sure what data to share, or want to learn about pubishing your data with an embargo period, you can learn more at the [digital curation centre](http://www.dcc.ac.uk/resources/how-guides).""",\
"none":"Your manuscript wasn't checked for a data citation"}
}