statistics_texts_dict = {

"correct_f_test":\
{"pass":"This *f* statistic is consistent with the its *p*-value",\
"fail":"Is this *F* statistic correct?",\
"explain":"""Double check these values as the *p*-value you've provided is not consistent with a 1 tailed test using the *F* statistic and degrees of freedom you've supplied. If you've used special calculations make sure these are clear.""",\
"none":"It looks like you've not reported any f-tests in the main body of text"},\

"correct_t_test_2tail":\
{"pass":"This *t* statistic is consistent with its *p*-value using a 2 tailed test",\
"fail":"Is this *t* statistic correct?",\
"explain":"""Double check these values as the *p*-value you've provided is not consistent with a 2 tailed test using the *t* statistic and degrees of freedom you've supplied. If you've used special calculations make sure you make these clear.""",\
"none":"It looks like you've not reported t-tests in the main body of text"},\

"correct_t_test_1tail":\
{"pass":"This *t*-test is consistent with its *p*-value using a 1 tailed test",\
"fail":"Is this *t* statistic correct?",\
"explain":"""Double check these values as the *p*-value you've provided is not consistent with either a 1 or 2 tailed test using the *t* statistic and degrees of freedom you've supplied. If you've used special calculations make sure you make these clear.""",\
"none":""},\

"correct_r_test":\
{"pass":"This Pearson correlation is consistent with its *p*-value",\
"fail":"Is this Pearson correlation correct?",\
"explain":"Double check these values as the *p*-value you've provided is not consistent with the *r* statistic and degrees of freedom you've supplied. If you've used special calculations make sure these are clear.",\
"none":""},\

"one_tailed_t_test_declared":\
{"pass":"1 tailed *t*-test declared",\
"fail":"Have you justified using a 1 tailed *t*-test?",\
"explain":"""If you perform a 1 tailed *t*-test you should declare it and justify why a 2 tailed test is not necessary.""",\
"none":""},\

"two_tailed_t_test":\
{"pass":"No 1 tailed t tests found",\
"fail":"",\
"explain":"",\
"none":""},\

"t_tests_reported_well":\
{"pass":"You've reported all *t*-tests with their degrees of freedom",\
"fail":"Have you reported the degrees of freedom for this *t*-test?",\
"explain":"""When reporting a *t*-test you should include the degrees of freedom and the *t* statistic. Write this as *t*(df) = *t* statistic.

[Read more about good statistical reporting](http://www.equator-network.org/2013/02/11/sampl-guidelines-for-statistical-reporting/)""",\
"none":""},\

"f_tests_reported_well":\
{"pass":"You have reported all *F*-tests with their degrees of freedom",\
"fail":"Have you reported the degrees of freedom for this *F*-test?",\
"explain":"""When reporting an *F*-test you should include both of the degrees of freedom (df) you used to calculate the *F*-statistic. Write this as *F*(df1, df2) = *F*-statistic. The degrees of freedom are important as they help the reader understand the scale of the study. You can learn more about how to calculate each df value, and what they mean, [here](http://ron.dotsch.org/degrees-of-freedom/). 

[Read more about good statistical reporting](http://www.equator-network.org/2013/02/11/sampl-guidelines-for-statistical-reporting/)""",\
"none":""},

"r_tests_reported_well":\
{"pass":"You have reported all Pearson's correlations without their sample size or degrees of freedom",\
"fail":"Have you included the sample size for this Pearson's correlation?",\
"explain":"""When reporting a Pearson's correlation you should include the sample size (n) that was used to calculate the *r* statistic. Write this as *r*(n = ___) = r statistic. 

Alternatively, you can report the degrees of freedom (df) instead of the sample size. You calculate this as n - 2, and write it as *r*(df = ___) = r statistic. 

[Read more about good statistical reporting](http://www.equator-network.org/2013/02/11/sampl-guidelines-for-statistical-reporting/)""",\
"none":"It looks like you've not reported any Pearson correlations in the main body text"},

"pval_as_equalities":\
{"pass":"This *p*-value is reported properly",\
"fail":"Have you given the exact *p*-value here?",\
"explain":"""OPO asks that all *p*-values are reported as exact figures, not as inequalities, except for *p*-values smaller than .001. For example: *p* = .074, *p* = .042, *p* < .001. 

[Read more about good statistical reporting](http://www.equator-network.org/2013/02/11/sampl-guidelines-for-statistical-reporting/)""",\
"none":"It looks like you've not reported any *p*-values in the main text"}

}