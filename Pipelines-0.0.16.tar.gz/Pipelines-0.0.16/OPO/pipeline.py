from tests.title_page_checks import *
from tests.heading_test_fns import *
from tests.references_fns import *
from tests.data_citation_fns import *
from tests.p_value_tests import check_for_pval_as_equalities
# from tests.t_test_fns import *
from tests.check_for_badly_reported_stats import *
# from tests.f_test_fns import *
# from tests.r_test_fns import *
from tests.table_and_figure_test_fns import *
from tests.design_specific_checks import *
from tests.citation_fns import *
from tests.compare_references_and_citations import *
from helpers.print_fns import *

def check_manuscript(text, to_penelope, design_type = None):

	# Extract title
 	title = check_for_title(text)

 	# Check title length
 	title_length = check_title_length(title, 70)

 	# Extract headings
 	headings, headings_list = check_headings(text) # we generate a dictionary for use in other functions, but a list to send to penelope

 	# Look for things at start of manuscript
 	# look for email
 	emails = check_for_email(text, headings)
 	# look for corresponding author
 	corresponding_author = check_for_corresponding_author(text, headings)

 	# do some checks on references and citations
 	ref_h = headings.get("references_h") or None
 	abs_h = headings.get("abstract_h") or None
 	intro_h = headings.get("introduction_h") or None
 	
 	#do reference checks
 	reference_style_checks, all_refs, correct_refs, ref_style = get_and_check_ref_style(text, ref_h, correct_style = "num")
	
	# check citations
	cit_style_results, citations, citations_in_abstract, cit_style = get_citations_and_style(text, all_refs, abs_h, intro_h, "num", ref_style)
	
	# set up empty containers 
	cit_seq_results, citations_referenced = [], [] 
	references_cited, ref_seq_results = [], []

	if ref_style == "num":
		# check reference sequences
		ref_nums = get_reference_numbers(correct_refs, text)
		ref_seq_results = verify_num_reference_seq(ref_nums, text)
		if cit_style == "num":
			# check citation sequences
			cit_nums = get_citation_numbers(citations, text)
			cit_seq_results = verify_sequence_of_num_citations(cit_nums, text)
			# compare citations with references
			citations_referenced = verify_num_citation_in_references(cit_nums, ref_nums, text)
			# compare references with citations
			references_cited = verify_num_references_in_citations(correct_refs, cit_nums, ref_h, text)


 	#Check for data citation
 	data_citation = check_for_data_citation(all_refs, text)

	# Check statistics
	pvals = check_for_pval_as_equalities(text)
    #
	# Check t tests
 	t_tests = [] # delete this when re uncomment the line below
 # 	t_tests = check_t_tests_in_text(text)
	badly_reported_t_tests = check_for_badly_reported_t_test(text, t_tests)
    #
	# if not (t_tests or badly_reported_t_tests):
	# 	t_tests = TestResult("correct_t_test_2tail", None, (None, None))
    #
	# Check f tests
	f_tests = []
	# f_tests = check_f_tests_match_pvals(text)
	badly_reported_f_tests = check_for_badly_reported_f_test(text, f_tests)
 # 	if not (f_tests or badly_reported_f_tests):
 # 		f_tests = TestResult("correct_f_test", None, (None, None))
    #
	# #Check r tests
	# valid_r_tests, invalid_r_tests = check_r_tests_in_text(text)

	#Check tables and figures
	# I generate this as a dict so that I can use it for easily printing to screen....
	# but I guess it'll be more useful to Penelope as a list
	table_and_figure_checks_dict = perform_table_and_figure_checks(text, ref_h)
	table_and_figure_checks_list = [table_and_figure_checks_dict[k] for k in table_and_figure_checks_dict.keys()]

	# Design specific checks
	study_design_checks = do_study_design_checks(text, all_refs, ref_h, design_type)

	# append everything to one list
	all_checks = [
#     	[headings[h] for h in headings.keys()],
		headings_list,
    	emails,
    	data_citation,
    	study_design_checks,
    	pvals,
    	badly_reported_t_tests,
    	# t_tests,
    	badly_reported_f_tests,
    	# f_tests,
    	# valid_r_tests,
    	# invalid_r_tests,
    	table_and_figure_checks_list,
    	cit_style_results,
    	citations_in_abstract,
    	citations_referenced,
    	cit_seq_results,
    	reference_style_checks,
    	ref_seq_results,
    	references_cited,
	]

	## make sure the list is flat
	flattened_checks = []
	for i in all_checks:
		if (type(i) != list):
			flattened_checks.append(i)
		else:
			for j in i:
				if (type(j) != list):
					flattened_checks.append(j)
				else:
					for k in j:
						flattened_checks.append(k)

	## Replace this for with the function that tells Penelope
 	if to_penelope:
		for i in flattened_checks:
			tell_penelope(i)

	else:
		for i in flattened_checks:
			print_TestResult_False_is_bad(i, text)
