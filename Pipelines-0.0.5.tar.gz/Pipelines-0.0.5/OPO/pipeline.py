from tests.title_page_checks import *
from tests.heading_test_fns import *
from tests.references_fns import get_references
from tests.data_citation_fns import *
# from tests.p_value_tests import check_for_pval_as_equalities
# from tests.t_test_fns import *
from tests.check_for_badly_reported_stats import *
# from tests.f_test_fns import *
# from tests.r_test_fns import *
from tests.table_and_figure_test_fns import *
from tests.design_specific_checks import *

from helpers.print_fns import *

def check_manuscript(text, to_penelope, design_type = None):

	# Extract title
 	title = check_for_title(text)

 	# Check title length
 	title_length = check_title_length(title, 70)

 	# Extract headings
 	headings = check_headings(text)

 	# Look for things at start of manuscript
 	# look for email
 	emails = check_for_email(text, headings)
 	# look for corresponding author
 	corresponding_author = check_for_corresponding_author(text, headings)

 	# do some checks on references
 	ref_h = headings.get("references_h") or None
 	references = get_references(text, ref_h)
 	#Check for data citation
 	data_citation = check_for_data_citation(references, text)

 # 	# Check statistics
 # 	pvals = check_for_pval_as_equalities(text)
    #
 # 	# Check t tests
 # 	t_tests = check_t_tests_in_text(text)
 # 	badly_reported_t_tests = check_for_badly_reported_t_test(text, t_tests)
    #
	# if not (t_tests or badly_reported_t_tests):
	# 	t_tests = TestResult("correct_t_test_2tail", None, (None, None))
    #
	# # Check f tests
	# f_tests = check_f_tests_match_pvals(text)
 # 	badly_reported_f_tests = check_for_badly_reported_f_test(text, f_tests)
 # 	if not (f_tests or badly_reported_f_tests):
 # 		f_tests = TestResult("correct_f_test", None, (None, None))
    #
	# #Check r tests
	# valid_r_tests, invalid_r_tests = check_r_tests_in_text(text)

	#Check tables and figures
	# I generate this as a dict so that I can use it for easily printing to screen....
	# but I guess it'll be more useful to Penelope as a list
	table_and_figure_checks_dict = perform_table_and_figure_checks(text, ref_h)
	table_and_figure_checks_list = [table_and_figure_checks_dict[k] for k in table_and_figure_checks_dict.keys()]

	# Design specific checks
	study_design_checks = do_study_design_checks(text, references, ref_h, design_type)

	# append everything to one list
	all_checks = [
    	[headings[h] for h in headings.keys()],
    	emails,
    	data_citation,
    	# pvals,
    	# badly_reported_t_tests,
    	# t_tests,
    	# badly_reported_f_tests,
    	# f_tests,
    	# valid_r_tests,
    	# invalid_r_tests,
    	table_and_figure_checks_list,
    	study_design_checks
	]

	## make sure the list is flat
	flattened_checks = []
	for i in all_checks:
		if (type(i) != list):
			flattened_checks.append(i)
		else:
			for j in i:
				if (type(j) != list):
					flattened_checks.append(j)
				else:
					for k in j:
						flattened_checks.append(k)

	## Replace this for with the function that tells Penelope
 	if to_penelope:
		for i in flattened_checks:
			tell_penelope(i)

	else:
		for i in flattened_checks:
			print_TestResult_False_is_bad(i, text)
