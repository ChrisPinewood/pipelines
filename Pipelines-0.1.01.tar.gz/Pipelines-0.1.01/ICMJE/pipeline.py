from tests.title_page_checks import *
from tests.heading_test_fns import *
from tests.references_fns import *
from tests.data_citation_fns import *
from tests.p_value_tests import check_for_pval_as_equalities, check_for_confidence_intervals
from tests.t_test_fns import *
from tests.check_for_badly_reported_stats import *
from tests.f_test_fns import *
from tests.r_test_fns import *
from tests.table_and_figure_test_fns import *
from tests.design_specific_checks import *
from tests.citation_fns import *
from tests.compare_references_and_citations import *
from helpers.print_fns import *

main_body_headings = ["methods_h", "results_h", "discussion_h"]
abstract_subheading_headings = ["purpose_h_ab_sub", "methods_h_ab_sub", "results_h_ab_sub", "conclusions_h_ab_sub"]
start_or_end_headings = ["acknowledgements_h", "data_statement_h", "conflicting_interests_h", "word_count_h", "funding_statement_h"] # OPO doesn't need a funding statement

def check_manuscript(text, to_penelope, design_type = None):

	# Extract title
 	title = check_for_title(text)

 	# Check title length
 	title_length = check_title_length(title, 70)

 	# Extract headings
 	raw_headings = extract_headings(text)
 	
 	# Find references
 	references_h = find_heading_occurance(raw_headings, text, "references_h", -1)
 	
 	# Find abstract
 	abstract_h = find_heading_occurance(raw_headings, text, "abstract_h", 0, None, references_h.position[0])
 	
 	# Find introduction
 	introduction_h = find_heading_occurance(raw_headings, text, "introduction_h", -1)
 	
 	# Find methods
 	methods_h = find_heading_occurance(raw_headings, text, "methods_h", -1, introduction_h.position[0], references_h.position[0])

 	# Find results
 	results_h = find_heading_occurance(raw_headings, text, "results_h", -1, introduction_h.position[0], references_h.position[0])

	# Find discussion
 	discussion_h = find_heading_occurance(raw_headings, text, "discussion_h", -1, introduction_h.position[0], references_h.position[0])

	# Look for structured abstract
	structured_abstract = check_for_structured_abstract(raw_headings, text, abstract_h, introduction_h)
	
	# Find abstract subheadings
	abstract_subheadings = []
# 	if structured_abstract.passed:
# 		earliest = abstract_h.position[0]
# 		latest = introduction_h.position[0] if introduction_h.passed else earliest + 1000
# 		abstract_subheadings = [find_heading_occurance(raw_headings, text, h, 0, earliest, latest) for h in abstract_subheading_headings]	
#  	if abstract_subheadings:
#  		structured_abstract = [] # we don't want to report anything general about structured abstracts if we've looked for specific subheadings
 	
 	# Look for title page sections. These can be in the title page or after the discussion
 	title_page_sections = [find_heading_occurance(raw_headings, text, h, 0, None, introduction_h.position[0]) for h in start_or_end_headings]
	for i in range(len(title_page_sections)):
		if not title_page_sections[i].passed:
			title_page_sections[i] = find_heading_occurance(raw_headings, text, title_page_sections[i].test, 0, discussion_h.position[1], None)
	
 	# look for email
 	email = check_for_title_page_item(email_regex, "email", text, introduction_h.position[0])
 	
 	# look for corresponding author
 	corresponding_author = check_for_title_page_item(corresponding_author_h, "corresponding_author", text, introduction_h.position[0])

 	#do reference checks
 	reference_style_checks, all_refs, num_refs, alpha_refs, ref_style = get_and_check_ref_style(text, references_h, correct_style = "num")
	
	# check citations
	cit_style_results, citations, citations_in_abstract, cit_style = get_citations_and_style(text, all_refs, abstract_h, introduction_h, "num", ref_style)
	
	# set up empty containers 
	cit_seq_results, citations_referenced = [], [] 
	references_cited, ref_seq_results = [], []

	if ref_style == "num":
		# check reference sequences
		ref_nums = get_reference_numbers(num_refs, text)
		ref_seq_results = verify_num_reference_seq(ref_nums, text)
		if cit_style == "num":
			# check citation sequences
			cit_nums = get_citation_numbers(citations, text)
			cit_seq_results = verify_sequence_of_num_citations(cit_nums, text)
			# compare citations with references
			citations_referenced = verify_num_citation_in_references(cit_nums, ref_nums, text)
			# compare references with citations
			references_cited = verify_num_references_in_citations(num_refs, cit_nums, references_h, text)


 	#Check for data citation
 	data_citation = check_for_data_citation(all_refs, text)

	# Check statistics
	pvals = check_for_pval_as_equalities(text, results_h)

	# Check confidence intervals
	confidence_intervals = []
	if pvals:
		confidence_intervals = check_for_confidence_intervals(text)

	# Check t tests
	t_tests = check_t_tests_in_text(text)
	badly_reported_t_tests = check_for_badly_reported_t_test(text, t_tests)

	if not (t_tests or badly_reported_t_tests):
		t_tests = TestResult("correct_t_test_2tail", None, (None, None))

	# Check f tests
	f_tests = check_f_tests_match_pvals(text)
	badly_reported_f_tests = check_for_badly_reported_f_test(text, f_tests)
 	if not (f_tests or badly_reported_f_tests):
 		f_tests = TestResult("correct_f_test", None, (None, None))
	
	# Check r tests
	valid_r_tests, invalid_r_tests = check_r_tests_in_text(text)

	# Check tables and figures
	# I generate this as a dict so that I can use it for easily printing to screen....
	# but I guess it'll be more useful to Penelope as a list
	table_and_figure_checks_dict, tables, extracted_media = perform_table_and_figure_checks(text, references_h)
	table_and_figure_checks_list = [table_and_figure_checks_dict[k] for k in table_and_figure_checks_dict.keys()]

	# Design specific checks
	checklist_citation, study_design_checks = do_study_design_checks(text, all_refs, references_h, introduction_h, abstract_h, design_type)

	# append everything to one list
	all_checks = [
		title_page_sections,
    	email,
    	data_citation,
    	abstract_h,
    	structured_abstract,
    	abstract_subheadings,
    	introduction_h,
    	methods_h,
		checklist_citation, 
    	study_design_checks,
    	results_h,
    	pvals,
    	confidence_intervals,
    	badly_reported_t_tests,
		t_tests,
    	badly_reported_f_tests,
    	f_tests,
    	valid_r_tests,
    	invalid_r_tests,
    	discussion_h,
    	table_and_figure_checks_list,
    	references_h,
    	cit_style_results,
    	citations_in_abstract,
    	citations_referenced,
    	cit_seq_results,
    	reference_style_checks,
    	ref_seq_results,
    	references_cited,
	]

	## make sure the list is flat
	flattened_checks = []
	for i in all_checks:
		if (type(i) != list):
			flattened_checks.append(i)
		else:
			for j in i:
				if (type(j) != list):
					flattened_checks.append(j)
				else:
					for k in j:
						flattened_checks.append(k)

	## Replace this for with the function that tells Penelope
 	if to_penelope:
		for i in flattened_checks:
			tell_penelope(i)

	else:
		for i in flattened_checks:
			print_TestResult_False_is_bad(i, text)

				
				
