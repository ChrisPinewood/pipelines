#!/usr/bin/env python
# -*- coding: utf-8 -*-

from helpers.test_result import *
import re
import os
import json

location = os.path.abspath(os.path.expanduser('resources/re3data.json'))
data_file = open(location, 'rb')
repo_dict = json.load(data_file)
repo_names = repo_dict.keys()
patterns = [r'\b%s\b' % re.escape(key.strip()) for key in repo_names]
urls = [repo_dict[key]["url"] for key in repo_names]
patterns += urls
match_repos = re.compile('|'.join(patterns), flags=re.IGNORECASE)

### MAIN TESTS FOR PENELOPE

def tell_penelope_data_citation(text, references, result = None):
	if not result:
		result = check_for_data_citation(references, text)
	tell_penelope(result)

def check_for_data_citation(references, text):
	#takes references a a list of strings and checks to see if they contain mention of a data repositor
	passed = False
	p1 = None
	p2 = None
	for ref in references:
		r = ref.match_string(text)
		if match_repos.search(r):
			passed = True
			p1 = text.find(r)
			p2 = text.find(r) + len(r)
	result = [TestResult("has_data_citation", passed, (p1, p2))]
	return result

def find_uri(text, report_immediately=True):
    """ find a DOI or URL """
    match_doi = r'\b10\.[0-9]+\S+\b'
    # URL regex from https://gist.github.com/gruber/249502
    match_url = r"(?i)\b((?:[a-z][\w-]+:(?:/{1,3}|[a-z0-9%])|www\d{0,3}[.]|[a-z0-9.\-]+[.][a-z]{2,4}/)(?:[^\s()<>]+|\(([^\s()<>]+|(\([^\s()<>]+\)))*\))+(?:\(([^\s()<>]+|(\([^\s()<>]+\)))*\)|[^\s`!()\[\]{};:'\".,<>?«»“”‘’]))"
    match_uri = re.compile('{0}|{1}'.format(match_doi, match_url))
    return find_in_full_text(match_uri, text, 'find_uri', report_immediately)
