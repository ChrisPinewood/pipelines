from helpers.print_fns import *
from helpers.general_fns import find_in_full_text
from helpers.parker_regexs import *
from helpers.test_result import TestResult
from tests.ethical_fns import *
from title_page_checks import *
from design_specific_auxiliary_checks import *



def do_study_design_checks(text, references, ref_h, introduction_h, abstract_h, type):
	if type == "consort":
		checklist_citation, checks = do_consort_checks(text, references, ref_h, introduction_h, abstract_h)
	elif type == "arrive":
		checklist_citation, checks = do_arrive_checks(text, references, ref_h)
	elif type == "prisma":
		checklist_citation, checks = do_prisma_checks(text, references, ref_h)
	elif type == "moose":
		checklist_citation, checks = do_moose_checks(text, references, ref_h)
	elif type == "entreq":
		checklist_citation, checks = do_entreq_checks(text, references, ref_h)
	elif type == "care":
		checklist_citation, checks = do_care_checks(text, references, ref_h)
	elif type == "srqr":
		checklist_citation, checks = do_srqr_checks(text, references, ref_h)
	elif type == "strobe":
		checklist_citation, checks = do_strobe_checks(text, references, ref_h)
	elif type == "stard":
		checklist_citation, checks = do_stard_checks(text, references, ref_h)
	elif type == "remark":
		checklist_citation, checks = do_remark_checks(text, references, ref_h)
	elif type == "tripod":
		checklist_citation, checks = do_tripod_checks(text, references, ref_h)
	else:
		checklist_citation, checks = [], []

	return checklist_citation, checks

def do_consort_checks(text, references, ref_h, introduction_h, abstract_h):

	#Check registry code
	registration = extract_registration(text, introduction_h, abstract_h)

	#Check for ethical approval
	ethics = extract_ethics(text, humans = True)

	# Check for informed consent
	consent = extract_consent(text)

	#Check for checklist citation
	checklist_citation = check_for_checklist_citation("consort", references, text)

	title = check_for_title(text)
	title_keywords = check_title_for_keywords(title, text, "consort")
	power_calculation = check_for_power_calculation(text)
	randomisation = check_for_randomisation(text)
	blinding = check_for_blinding(text)
	participant_flow_diagram = check_for_flow_diagram(text)

	return checklist_citation, [registration, consent, ethics, title_keywords, power_calculation, randomisation, blinding, participant_flow_diagram]

def do_arrive_checks(text, references, ref_h):

	# check for arvo
	arvo = find_in_full_text(arvo_regex, text, "arvo")
	if not arvo:
		arvo = TestResult("arvo", False, (None, None))

	# check for mention of ethics
	ethics = extract_ethics(text)

	# check for title keywords
	title = check_for_title(text)
	title_keywords = check_title_for_keywords(title, text, "arrive")

	# check for citation
	citation = check_for_checklist_citation("arrive", references, text)
	
	rrid = TestResult("animal_rrid_used", False, (None, None))
	
	return citation, [arvo, ethics, rrid]

def do_prisma_checks(text, references, ref_h):
	citation = check_for_checklist_citation("prisma", references, text)
	return citation, []

def do_moose_checks(text, references, ref_h):
	citation = check_for_checklist_citation("moose", references, text)
	return citation, []

def do_entreq_checks(text, references, ref_h):
	citation = check_for_checklist_citation("entreq", references, text)
	return citation, []

def do_care_checks(text, references, ref_h):
	citation = check_for_checklist_citation("care", references, text)
	return citation, []

def do_srqr_checks(text, references, ref_h):
	citation = check_for_checklist_citation("srqr", references, text)
	return citation, []

def do_strobe_checks(text, references, ref_h):
	citation = check_for_checklist_citation("strobe", references, text)
	return citation, []

def do_stard_checks(text, references, ref_h):
	citation = check_for_checklist_citation("stard", references, text)
	return citation, []

def do_remark_checks(text, references, ref_h):
	citation = check_for_checklist_citation("remark", references, text)
	return citation, []

def do_tripod_checks(text, references, ref_h):
	citation = check_for_checklist_citation("tripod", references, text)
	return citation, []
