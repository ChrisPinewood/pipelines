# -*- coding: utf-8 -*-

import re
from general_fns import *
from file_fns import *
from parker_regexs import p_str, t_str, f_str
from helpers.test_result import *
div_regex = re.compile("\|")

dashes_regex = re.compile(r"(\|(\-+\|)+)")
new_line_regex = re.compile(r"\|\s*\n\s*\|")

# cells_pre_string = "(\|(.*\|){"
# cells_after_string = "^(\n\|([^\|\n]*\|)+)+"#{"
p_str_regex = re.compile(p_str)
t_str_regex = re.compile(t_str)
f_str_regex = re.compile(f_str)

### main functions

def extract_all_tables(text):
	dashed_lines = extract_dash_rows(text)
	tables = [extract_table(d, text) for d in dashed_lines]
	return tables

def extract_table(dashed_line, text):
	try:
		cell_widths = get_cell_widths(dashed_line, text)
		top_row = get_top_row(dashed_line, cell_widths, text)
		rows_below = get_rows_below(dashed_line, cell_widths, text)
		table = get_full_table(top_row, dashed_line, rows_below)
	except:
		table = TestResult("table_extracted", False, dashed_line.position)
	return table

## sub functions

def extract_dash_rows(text):
	dash_rows = find_in_full_text(dashes_regex, text, "dash_rows")
	return list(dash_rows)

def get_cell_widths(row_obj, text):
	row_str = text[row_obj.position[0]:row_obj.position[1]]
	cells = row_str.split("|")[1:-1]
	cell_widths = [len(c) for c in cells]
	return cell_widths

def get_top_row(row_obj, cell_widths, text):
# 	string = r"\|([^\|]{"+str(cell_widths[0])+","+str(cell_widths[0]+2)+"}\|)"
# 	string = r"\n\s*("+string+r"((.|(?<!\|)\n(?!\|))*\|)?\n)+" #here we have (?<!\|)\n(?!\|) which will match new lines within cells
# 	for c in cell_widths[1:]:
# 		string = string + "([^\|]{"+str(c)+","+str(c+2)+"}\|)?"
# 	before_string = string + "$"
# 	before_pattern = re.compile(before_string)
# 	cells_before = before_pattern.search(text[:row_obj.position[0]])
	table_top_pattern = re.compile(r"(\|[^\|]*){"+str(len(cell_widths))+"}\|\s*$")
	cells_before = table_top_pattern.search(text[:row_obj.position[0]])
	return cells_before

def get_rows_below(row_obj, cell_widths, text):
# 	string = r"\|([^\|]{"+str(cell_widths[0])+","+str(cell_widths[0]+2)+"}\|)"
# 	after_string = r"^(\n"+string+")"
# 	after_string = r"^\n("+string+r"((.|(?<!\|)\n(?!\|))*\|)?\n)+" #here we have (?<!\|)\n(?!\|) which will match new lines within cells
# 	after_pattern = re.compile(after_string)
# 	cells_after = after_pattern.search(text[row_obj.position[1]:])
	table_below_pattern = re.compile(r"^(\n\s*(\|[^\|]*){"+str(len(cell_widths))+"}\|)+")
	cells_after = table_below_pattern.search(text[row_obj.position[1]:])
	return cells_after

def get_full_table(top_row, dash_row, rows_below):
	#top_row and rows_below are regular expression matches. dash_row is a test result
	table = []
	title_row_content = get_columns_from_row(top_row.group(), top_row.start())
	table.append(title_row_content)
	below_text = rows_below.group().replace(r"\\", r"\\\\").strip()
	rows = new_line_regex.split(below_text)
	for r in rows:
		start = rows_below.group().find(r)
		r = r.strip()
		r = "|"+r if not r.startswith("|") else r
		r = r+"|" if not r.endswith("|") else r
		row_contents = get_columns_from_row(r, start)
		table.append(row_contents)
	p1 = top_row.start()
	p2 = p1 + rows_below.end()
	table_testresult = TestResult("table_extracted", True, (p1, p2), {"table":table})
	return table_testresult

def get_columns_from_row(row_text, start):
# 	column_headings = top_row_text.strip().split("|")[1:-1]
# 	column_headings = [c.strip() for c in column_headings]	s = top_row.start()
	# we need to know the start position of the row within the whole text
	s = start
	divs = [m.start() for m in div_regex.finditer(row_text)]
	contents = []
	for i in range(len(divs)-1):
		contents.append((row_text[divs[i]:divs[i+1]].strip(), (s+divs[i], s+divs[i+1])))
	return contents
