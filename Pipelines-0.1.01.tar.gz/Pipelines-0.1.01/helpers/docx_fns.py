import os
import time
import datetime
import zipfile
import tempfile
from lxml import etree
import shutil
from shutil import copyfile
import copy
from resources.test_messages import msgs


nps = {'w':"http://schemas.openxmlformats.org/wordprocessingml/2006/main"}
w = "{"+nps['w']+"}"
id_str = "XQZIDXQZ"
blank_comments_filepath = os.path.expanduser('~/Penelope/files/blank_comments.xml')
blank_intro_filepath = os.path.expanduser("~/Penelope/files/blank_intro.docx")


def get_word_xml(docx_filename, target_to_return):
   with open(docx_filename) as f:
      zip = zipfile.ZipFile(f)
      xml_content = zip.read(target_to_return)
   return xml_content


def get_xml_tree(xml_string):
   return etree.fromstring(xml_string)
      
def write_text_and_close_docx (original_docx_filepath, xml_content, component_file_to_write_over, output_docx_filename):
        """ Create a temp directory, expand the original docx zip.
            Write the modified xml to word/document.xml
            Zip it up as the new docx
        """

        tmp_dir = tempfile.mkdtemp() #make a temp directory
        
        with open(original_docx_filepath) as f:
       		zip = zipfile.ZipFile(f) 
       		zip.extractall(tmp_dir) # copy all files from our original docx into the tempdir
       		# Get a list of all the files in the original docx zipfile
	        filenames = zip.namelist()
			
        with open(os.path.join(tmp_dir,component_file_to_write_over), 'w') as f:
            xmlstr = etree.tostring (xml_content, pretty_print=True)
            f.write(xmlstr) ## write over the document.xml in our temp file

        # Get a list of all the files in the our new tempdir
        # Now, create the new zip file and add all the filex into the archive
        zip_copy_filename = output_docx_filename
        with zipfile.ZipFile(zip_copy_filename, "w") as docx:
#             for filename in filenames:
# 				docx.write(filename, filename)
			for (path,dirs,files) in os.walk(tmp_dir):
				for filename in files:
					t = os.path.join(path,filename)
					y = os.path.join(path,filename).replace(tmp_dir+"/", "")
					docx.write(t, y)


        # Clean up the temp dir
        shutil.rmtree(tmp_dir)	

def add_comments_xml_to_docx(filepath):
	blank_comment_xml = etree.parse(blank_comments_filepath)
	write_text_and_close_docx (filepath, blank_comment_xml, 'word/comments.xml', filepath)
	rels_xml_content = get_word_xml(filepath, 'word/_rels/document.xml.rels')
	rels_xml = get_xml_tree(rels_xml_content)
	children = rels_xml.getchildren()
	last_child = children[-1]
	child_copy = copy.deepcopy(last_child)
	child_copy.attrib["Id"] = 'rID'+str(len(children)+1)
	child_copy.attrib["Type"] = "http://schemas.openxmlformats.org/officeDocument/2006/relationships/comments"
	child_copy.attrib["Target"] = "comments.xml"
	last_child.addnext(child_copy)
	write_text_and_close_docx (filepath, rels_xml, 'word/_rels/document.xml.rels', filepath)
	
def make_numbered_word_file(original_filepath, numbered_filepath):
	copyfile(original_filepath, numbered_filepath)
	xml_content = get_word_xml(original_filepath, 'word/document.xml')
	xml_tree = get_xml_tree(xml_content)

	ts = xml_tree.findall('.//w:t', nps) # find all text elements

	id = 0 # add ids to each text element, starting from 0
	for t in ts:
		old_text = t.text
		t.text = old_text+id_str.replace("ID", str(id))
		id+=1	
			
	write_text_and_close_docx(original_filepath, xml_tree, 'word/document.xml', numbered_filepath)


def itertext(my_etree):
     """Iterator to go through xml tree's text nodes"""
     for node in my_etree.iter(tag=etree.Element):
         if check_element_is(node, 't'):
             yield (node, node.text)

def check_element_is(element, type_char):
     word_schema = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'
     return element.tag == '{%s}%s' % (word_schema,type_char)
	
def get_text_from_docx(docx_filepath):
	xml_content = get_word_xml(docx_filepath, 'word/document.xml')
	xml_tree = get_xml_tree(xml_content)
	t = []
	for node, txt in itertext(xml_tree):
		t.append(txt)
	return t

def get_max_comment_id(original_filepath):
	with zipfile.ZipFile(original_filepath, 'a') as z:
		contents = [f.filename for f in z.filelist]
	
	cids = []
	if 'word/comments.xml' in contents:
		comment_content = get_word_xml(original_filepath, 'word/comments.xml')
		c = get_xml_tree(comment_content)
		cid_elems = c.findall(".//w:comment", nps)
		cids = [int(cid.get(w+"id")) for cid in cid_elems]
	
	if cids:
		max_cid = max(cids)
	else:
		max_cid = -1

	return max_cid

def make_commented_docx(docx_filepath, commented_filepath, comment_tuples, intro_reminders, max_comment_id, url):
	# comment tuples are expected in the format:
	# ("Text to put into the comment", ((starting_elem, string_index), (ending_elem, string_index)))	

	copyfile(docx_filepath, commented_filepath)
	
	with zipfile.ZipFile(commented_filepath, 'a') as z:
		contents = [f.filename for f in z.filelist]
	
	if not 'word/comments.xml' in contents:
		add_comments_xml_to_docx(commented_filepath)		
		
	document_xml_content = get_word_xml(commented_filepath, 'word/document.xml')
	document_xml_tree = get_xml_tree(document_xml_content)
	comments_xml_content = get_word_xml(commented_filepath, 'word/comments.xml')
	comments_xml_tree = get_xml_tree(comments_xml_content)
	
	starting_comment_id = max_comment_id + 1
	
	i = starting_comment_id
	for comment_tuple in comment_tuples:
		comments_xml_tree = add_comment_to_comment_xml(comments_xml_tree, i, comment_tuple[0])
		time.sleep(1)
		i += 1
	
	ts = []
	for node, txt in itertext(document_xml_tree):
		ts.append(node)	
	
	final_comment_id = starting_comment_id + (len(comment_tuples) - 1)
	comment_tuples.reverse()
	for comment_tuple in comment_tuples:
		comment_text = comment_tuple[0]

		end_elem = comment_tuple[1][1][0]
		end_location = comment_tuple[1][1][1]
		add_end_of_comment(ts[end_elem], end_location, final_comment_id)
				
		start_elem = comment_tuple[1][0][0]
		start_location = comment_tuple[1][0][1]
		add_start_of_comment(ts[start_elem], start_location, final_comment_id)		

# 		document_xml = add_comment_to_document_xml(document_xml, location, comment_id)	
		
		final_comment_id -= 1
	
# 	print etree.tostring(comments_xml_tree, pretty_print = True)
	
	blank_intro_xml = get_xml_tree(get_word_xml(blank_intro_filepath, 'word/document.xml'))
	blank_intro_body = blank_intro_xml.find('.//w:body', nps)
	ps = blank_intro_body.findall("w:p", nps)
	
	link_elem = ps[6].getchildren()[3]
	hyperlink_elem = link_elem.find("w:instrText", nps)
	hyperlink_elem.text = hyperlink_elem.text.replace("http://www.google.com", url)

	bullet_p = ps[9]
	intro_reminders.reverse()
	print "REMINDERS INSIDE: ", len(intro_reminders)	
	for reminder in intro_reminders:
		bullet_copy = copy.deepcopy(bullet_p)
		copy_text_elem = bullet_copy.findall(".//w:t", nps)[-1]
		copy_text_elem.text = reminder
		bullet_p.addnext(bullet_copy)		

	ps = blank_intro_body.findall("w:p", nps) # we have to find them again after adding new ones
		
	first_child = document_xml_tree.findall('.//w:p', nps)[0]
	for p in ps:
		first_child.addprevious(p)	
	
	write_text_and_close_docx(commented_filepath, document_xml_tree, 'word/document.xml', commented_filepath)
	write_text_and_close_docx(commented_filepath, comments_xml_tree, 'word/comments.xml', commented_filepath)		
		
def add_start_of_comment(elem, start_location, comment_id):
	start_of_comment = etree.Element(w+"commentRangeStart", attrib = {w+"id":str(comment_id)}, nsmap = nps)	
	txt = elem.text
	parent = elem.getparent()
	if start_location == 0:
		parent.addprevious(start_of_comment)
	else:
		first_half = txt[:start_location]
		elem.text = first_half
		
		second_half = txt[start_location:]
		parent_copy = copy.deepcopy(parent)
		next_text_elem = parent_copy.find("w:t", nps)
		next_text_elem.text = second_half
		
		parent.addnext(start_of_comment)
		start_of_comment.addnext(parent_copy)

def add_end_of_comment(elem, end_location, comment_id):
	end_of_comment = etree.Element(w+"commentRangeEnd", attrib = {w+"id":str(comment_id)}, nsmap = nps)
	comment_reference = etree.Element(w+"r")
	comment_reference_sub = etree.SubElement(comment_reference, w+"commentReference", attrib = {w+"id":str(comment_id)})
	txt = elem.text
	parent = elem.getparent()
	if end_location >= len(txt):
		parent.addnext(end_of_comment)
		end_of_comment.addnext(comment_reference)
	else:
		first_half = txt[:end_location]
		elem.text = first_half

		second_half = txt[end_location:]
		parent_copy = copy.deepcopy(parent)
		text_children =	parent_copy.findall(".//w:t", nps)
		first = True
		for child in text_children:
			if first:
				child.text = second_half
				first = False
			else:
				parent_copy.remove(child)
		
		parent.addnext(end_of_comment)
		end_of_comment.addnext(comment_reference)
		comment_reference.addnext(parent_copy)
  
def add_comment_to_document_xml(doc_xml_tree, start, end, comment_id):
	
	ts = []
	for node, txt in itertext(xml_tree):
		ts.append(node)

	t = ts[index]
	parent = t.getparent()
	start_of_comment = etree.Element(w+"commentRangeStart", attrib = {w+"id":str(comment_id)}, nsmap = nps)
	end_of_comment = etree.Element(w+"commentRangeEnd", attrib = {w+"id":str(comment_id)}, nsmap = nps)
	comment_reference = etree.Element(w+"r")
	comment_reference_sub = etree.SubElement(comment_reference, w+"commentReference", attrib = {w+"id":str(comment_id)})
	parent.addprevious(start_of_comment)
	parent.addnext(end_of_comment)
	end_of_comment.addnext(comment_reference)
	return doc_xml

def add_comment_to_comment_xml(comments_xml_tree, comment_id, comment_text):
	root = comments_xml_tree

	now = datetime.datetime.now().isoformat()+"Z"
	new_c_attrib = {w+"id":str(comment_id), w+"author":"Penelope", w+"date":now}
	new_c = etree.Element(w+"comment", attrib = new_c_attrib, nsmap = nps)
	c_sub_firstp = etree.SubElement(new_c, w+"p", nsmap = nps)
	c_sub_firstp_subpPr = etree.SubElement(c_sub_firstp, w+"pPr", nsmap = nps)
	c_sub_firstp_subpPr_substyle = etree.SubElement(c_sub_firstp_subpPr, w+"pStyle", attrib = {w+"val":"Default"}, nsmap = nps)
	c_sub_secondp = etree.SubElement(new_c, w+"p", nsmap = nps)
	c_sub_secondp_subpPr = etree.SubElement(c_sub_secondp, w+"pPr", nsmap = nps)
	c_sub_secondp_subpPr_substyle = etree.SubElement(c_sub_secondp_subpPr, w+"pStyle", attrib = {w+"val":"Default"}, nsmap = nps)
	c_sub_secondp_r = etree.SubElement(c_sub_secondp, w+"r", nsmap = nps)
	c_sub_secondp_r_rPr = etree.SubElement(c_sub_secondp_r, w+"rPr", nsmap = nps)
	fonts_attrib = {w+"cs":"Arial Unicode MS", w+"eastAsia":"Arial Unicode MS"}
	c_sub_secondp_r_rPr_fonts = etree.SubElement(c_sub_secondp_r_rPr, w+"rFonts", attrib = fonts_attrib, nsmap = nps)
	c_sub_secondp_r_rPr_rtl = etree.SubElement(c_sub_secondp_r_rPr, w+"rtl", attrib = {w+"val":str(comment_id)}, nsmap = nps)
	c_sub_secondp_r_t = etree.SubElement(c_sub_secondp_r, w+"t", nsmap = nps)
	c_sub_secondp_r_t.text = comment_text
# 	c_sub_secondp_r_a = etree.SubElement(c_sub_secondp_r, w+"a", nsmap = nps)
	
	root.append(new_c)
	return comments_xml_tree

def turn_check_results_into_comments(all_checks, conv_list, docx_text_map):

	errors = [i for i in all_checks if not i.passed]
	errors = sorted(errors, key=lambda x: x.position[0])

	comments = []
	intro_reminders = []
	for c in errors:
		if c.passed == False:
			if (c.position and (c.position[0] and c.position[1])):
				c_text = msgs[c.test]['fail']
				position_1 = c.position[0] or 0
				position_2 = c.position[1] or 0
				start = docx_text_map[conv_list[position_1]]
				end = docx_text_map[conv_list[position_2]]
				comments.append((c_text, (start, end)))
			else:	
				intro_reminders.append(msgs[c.test]['fail'])
				
	return comments, intro_reminders
	
def get_mapping_for_text_elems(text_list_from_docx):
	mapping = []
	for i in range(len(text_list_from_docx)):
		txt = text_list_from_docx[i]
		for a in range(len(txt)):
			mapping.append((i, a))
	return mapping
	
