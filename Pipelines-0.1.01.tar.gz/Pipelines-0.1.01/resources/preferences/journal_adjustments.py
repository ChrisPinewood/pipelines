import os

journal_adjustment_dict = {
	"opo":
		{"extra":
			[
			'methods_h_ab_sub',
			'results_h_ab_sub',
			'conclusions_h_ab_sub',
			'arvo',
			'purpose_h_ab_sub'
			], 
		"exclude":
			[
			'structured_abstract',
			'title_present'
			],
		"referer":"1234",
		"font":"Times New Roman",
		"banner":os.path.expanduser("~/Penelope/pipelines/email_user/files/image1.png")
		},
	"icmje":
		{"extra":
			[
			], 
		"exclude":
			[
			],
		"referer":"1234",
		"font":"Times New Roman",
		"banner":os.path.expanduser("~/Penelope/pipelines/email_user/files/image1.png"),
		}
	}