animal_specific_texts_dict = {

"arrive_checklist_cited":\
{"pass":"You have cited the ARRIVE guidelines",\
"fail":"Have you cited the ARRIVE guidelines?",\
"explain":"All experiments involving animals in vivo must adhere to the ARRIVE guidelines\
for the reporting of  animal research. You should then cite the ARRIVE statement in your\
reference section",\
"none":"",\
"section":"Reporting Guidelines",\
"important":True,\

},\

"animal_rrid_used":\
{"pass":"You have cited the animals you used using RRIDs",\
"fail":"Have you considered identifying the animals you used using a resource identifier?",\
"explain":"To help other people replicate your experiment, it's good practice to identify the organism you used by citing its unique resource identifier. You can search for identifiers [here](https://scicrunch.org/resources/Organisms/search) and learn more about identifiers for research animals [here](https://scicrunch.org/resources/about/guidelines).",\
"none":"",\
"section":"Reporting Transparency",\
"important":False,\

},\

"antibody_rrids_used":\
{"pass":"You have cited the antibodies you used using RRIDs",\
"fail":"If you used antibodies, have you cited their unique resource identifiers?",\
"explain":"To help other people replicate your experiment, it's good practice to identify the antibodies you used by citing their unique resource identifiers. You can search for identifiers [here](https://scicrunch.org/resources/Antibodies/search) and learn more about identifiers for research animals [here](https://scicrunch.org/resources/about/guidelines).",\
"none":"",\
"section":"Reporting Transparency",\
"important":False,\

},\

"arvo":\
{"pass":"You have mentioned the ARVO statement",\
"fail":"Does your work adhere to the ARVO statement?",\
"explain":"""If you used animals in your research you must state, in the methods section, whether or not your work adheres to the [ARVO statement](http://www.arvo.org/about_arvo/policies/statement_for_the_use_of_animals_in_ophthalmic_and_visual_research/)""",\
# <a href = 'http://www.arvo.org/about_arvo/policies/statement_for_the_use_of_animals_in_ophthalmic_and_visual_research/'>\
# ARVO statement</a> for the use of animals in ophthalmic and visual research
"none":"",\
"section":"Methods",\
"important":False,\

}

}