from email_feedback_texts.risk_of_bias_texts import *
from email_feedback_texts.tables_media_texts import *
from email_feedback_texts.statistics_texts import *
from email_feedback_texts.animal_specifics_texts import *
from email_feedback_texts.ethics_texts import *
from email_feedback_texts.consort_specific_texts import *
from email_feedback_texts.data_citation_texts import *
from email_feedback_texts.main_headings_texts import *
from email_feedback_texts.abstract_subheadings_texts import *
from email_feedback_texts.other_heading_texts import *
from email_feedback_texts.title_page_texts import *
from email_feedback_texts.nih_specific_texts import *
from email_feedback_texts.checklist_citation_texts import *
from email_feedback_texts.references_texts import *
from email_feedback_texts.citations_texts import *


email_msgs = {}

email_msgs.update(risk_of_bias_texts_dict)
email_msgs.update(table_media_texts_dict)
email_msgs.update(statistics_texts_dict)
email_msgs.update(animal_specific_texts_dict)
email_msgs.update(ethics_texts_dict)
email_msgs.update(consort_specific_texts_dict)
email_msgs.update(data_citation_texts_dict)
email_msgs.update(main_headings_texts_dict)
email_msgs.update(abstract_subheading_texts_dict)
email_msgs.update(other_heading_texts_dict)
email_msgs.update(title_page_texts_dict)
email_msgs.update(nih_specific_texts_dict)
email_msgs.update(checklist_citation_texts_dict)
email_msgs.update(references_texts_dict)
email_msgs.update(citations_texts_dict)

# import json
# print json.dumps(email_msgs, sort_keys=True, indent=2, separators=(',', ': '))
