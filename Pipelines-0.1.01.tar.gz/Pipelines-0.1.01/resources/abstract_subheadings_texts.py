abstract_subheading_texts_dict = {

"purpose_h_ab_sub":\
{"pass":"You have a 'Purpose' subsection in your abstract",\
"fail":"Have you included a 'Purpose' subsection in your abstract?",\
"explain":"""Your abstract should be structured with the subsections 'Purpose', 'Methods', 'Results' and 'Conclusions'. The purpose section should set out your primary objectives.""",\
"none":"Your Abstract wasn't checked for subheadings",\
"section":"Abstract",\
"important":False,\
},\

"methods_h_ab_sub":\
{"pass":"You have a 'Methods' subsection in your abstract",\
"fail":"Have you included a 'Methods' subsection in your abstract?",\
"explain":"""Abstracts should be structured with the subsections 'Purpose', 'Methods', 'Results' and 'Conclusions'. The methods section should include the experimental design (if it's not in your title), the sample population, and the main techniques used.""",\
"none":"Your Abstract wasn't checked for subheadings",\
"section":"Abstract",\
"important":False,\
},\

"results_h_ab_sub":\
{"pass":"You have a 'Results' subsection in your abstract",\
"fail":"Have you included a 'Results' subsection in your abstract?",\
"explain":"""Abstracts should be structured with the subsections 'Purpose', 'Methods', 'Results' and 'Conclusions'. Report the main results, whether they were significant or not. Do not selectively mention significant results that weren't central to the objectives of your study.""",\
"none":"Your Abstract wasn't checked for subheadings",\
"section":"Abstract",\
"important":False,\
},\

"conclusions_h_ab_sub":\
{"pass":"You have a 'Conclusions' subsection in your abstract",\
"fail":"Have you included a 'Conclusions' subsection in your abstract?",\
"explain":"""Abstracts should be structured with the subsections 'Purpose', 'Methods', 'Results' and 'Conclusions'. Summarise the main conclusions pertaining to your objectives. Do not overemphasise significant results that weren't central to the objectives of your study.""",\
"none":"Your Abstract wasn't checked for subheadings",\
"section":"Abstract",\
"important":False,\
},\

"structured_abstract":\
{"pass":"Your abstract is structured with subheadings",\
"fail":"Have you structured your abstract?",\
"explain":"""Most medical journals require original research, systematic reviews, and meta- analyses to have structured abstracts. The exact subheadings depend on the journal (and possibly your research paradigm) but in general the sections should provide the background and purpose of the study, the basic procedures you used, your main findings (with effect sizes, statistical and clinical significance, if possible), and principal conclusions. You should emphasize new and important aspects of the study or observations, note important limitations, and avoid overinterpreting findings.""",\
"none":"Your Abstract wasn't checked for subheadings",\
"section":"Abstract",\
"important":True,\
}

}