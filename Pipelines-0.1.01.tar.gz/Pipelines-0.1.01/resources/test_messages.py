from risk_of_bias_texts import *
from tables_media_texts import *
from statistics_texts import *
from animal_specifics_texts import *
from ethics_texts import *
from consort_specific_texts import *
from data_citation_texts import *
from main_headings_texts import *
from abstract_subheadings_texts import *
from other_heading_texts import *
from title_page_texts import *
from nih_specific_texts import *
from checklist_citation_texts import *
from references_texts import *
from citations_texts import *


msgs = {}

msgs.update(risk_of_bias_texts_dict)
msgs.update(table_media_texts_dict)
msgs.update(statistics_texts_dict)
msgs.update(animal_specific_texts_dict)
msgs.update(ethics_texts_dict)
msgs.update(consort_specific_texts_dict)
msgs.update(data_citation_texts_dict)
msgs.update(main_headings_texts_dict)
msgs.update(abstract_subheading_texts_dict)
msgs.update(other_heading_texts_dict)
msgs.update(title_page_texts_dict)
msgs.update(nih_specific_texts_dict)
msgs.update(checklist_citation_texts_dict)
msgs.update(references_texts_dict)
msgs.update(citations_texts_dict)

# from this folder, enter python commands:
# > import json
# > from test_messages import *
# > print json.dumps(msgs, sort_keys=True, indent=2, separators=(',', ': '))
