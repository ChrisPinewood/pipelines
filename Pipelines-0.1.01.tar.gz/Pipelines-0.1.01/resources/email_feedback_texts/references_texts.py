references_texts_dict = {

"correct_ref_style_used_num":\
{"pass":"Your references are numbered",\
"fail":"Should your references be numbered?",\
"explain":"""This journal follows the [Vancouver referencing style](https://en.wikipedia.org/wiki/Vancouver_system), where citations are written as superscript numbers. You should allocate a number to a reference source in the order in which it is cited in the text. If the source is referred to again, the same number is used.""",\
"none":"",\
"section":"Referencing",\
"important":False,\
},\

"correct_ref_style_used_alpha":\
{"pass":"Your references aren't numbered",\
"fail":"Have you used the correct referencing style?",\
"explain":"""Make sure your references follow the [Harvard citation style](https://en.wikipedia.org/wiki/Parenthetical_referencing#How_to_cite). This style uses the names of authors and years of publication, rather than a numerical system.""",\
"none":"",\
"section":"Referencing",\
"important":False,\
},\

"anomaly_ref_style_used":\
{"pass":"All references are in the correct style",\
"fail":"Is this reference in the correct style?",\
"explain":"Make sure all references follow the same style.",\
"none":"",\
"section":"Referencing",\
"important":False,\
"quote_all":True,\
},\

"verify_references_in_citations":\
{"pass":"You've cited all your references",\
"fail":"Have you cited this reference?",\
"explain":"""Make sure you've talked about this reference in your article, and cited it properly. If you don't refer to a source then delete it from your reference list.""",\
"none":"",\
"section":"Referencing",\
"important":False,\
"quote_all":True,\
},\

"alphabetic_refs":\
{"pass":"Your references are in alphabetic order",\
"fail":"Are these references in alphabetic order?",\
"explain":"""When using a Harvard referencing system it is normal for your references to be in alphabetic order, according to the surname of the first author of each entry. Some journals ask for references to be in the order in which they are cited though, so make sure to check the author guidelines for your chosen journal.""",\
"none":"",\
"section":"Referencing",\
"important":False,\
"quote_all":True,\
},\

"verify_num_reference_seq:numerical_order":\
{"pass":"Your references are in numerical order",\
"fail":"Are these references in ascending numerical order?",\
"explain":"""Make sure your references follow a continuous sequential order, increasing in number one by one according to the order they are mentioned in the text.""",\
"none":"",\
"section":"Referencing",\
"important":False,\
"quote_all":True,\
},\

"verify_num_reference_seq:full_sequence":\
{"pass":"You haven't skipped any reference numbers",\
"fail":"Have you skipped a reference number?",\
"explain":"""Make sure that your reference list follows a continuous numbered sequence, and that you haven't missed out any numbers.""",\
"none":"",\
"section":"Referencing",\
"important":False,\
"quote_all":True,\
},\

"verify_num_reference_seq:duplicate_numbers":\
{"pass":"Your references are in numerical order",\
"fail":"Is this reference number unique?",\
"explain":"""Make sure you haven't given two references the same number.""",\
"none":"",\
"section":"Referencing",\
"important":False,\
"quote_all":True,\
},\

"verify_num_reference_seq":\
{"pass":"Your references are in the correct order",\
"fail":"Are these references in ascending numerical order?",\
"explain":"""Make sure your references follow a continuous sequential order, increasing in number one by one according to the order they are mentioned in the text.""",\
"none":"",\
"section":"Referencing",\
"important":False,\
"quote_all":"when wrong",\
},\

"all_alpha_references_cited":\
{"pass":"You have cited all of your references",\
"fail":"Have you cited all of your references?",\
"explain":"Make sure you've talked about this reference in your article, and cited it properly. If you don't refer to a source then delete it from your reference list.",\
"none":"",\
"section":"Referencing",\
"important":False,\
"quote_all":True,\
}	

}