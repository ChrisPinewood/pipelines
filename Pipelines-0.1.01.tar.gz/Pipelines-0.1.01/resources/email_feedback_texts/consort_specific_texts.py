consort_specific_texts_dict = {

"clinical_trial_registration":\
{"pass":"You have included a trial registration ID in your abstract",\
"fail":"Have you included your trial registration ID in your abstract?",\
"explain":"""All clinical trials must be registered with an official registry. The registry will then give you a unique trial ID which you should include in your abstract. 

Acceptable registries include [clinicaltrials.gov](http://www.clinicaltrials.gov/), [ISRCTN.org](www.ISRCTN.org), or any of the [WHO primary registries](http://www.who.int/ictrp/network/primary/en/index.html). 

You should have registered your trial before enrolling participants. But you can (and should) still register retrospectively - just let the editor know you've done this in your cover letter. 

You can learn more about how and why to register your trial [here](http://www.icmje.org/about-icmje/faqs/clinical-trials-registration/).""",\
"none":"",\
"section":"Title Page",\
"important":True
},\

"participant_flow_diagram":\
{"pass":"You have included a participant flow diagram",\
"fail":"Have you included a participant flow diagram?",\
"explain":"""You should describe the the numbers of participants that were assessed for eligibility, randomly assigned to each group, received intended treatment and analysed for the primary outcome. In many cases it's easiest to include this as a flow diagram.

See [example templates of flow diagrams](http://www.consort-statement.org/consort-statement/flow-diagram) or [make your own](https://www.gliffy.com/).""",\
# You can see <a href = 'https://www.google.co.uk/search?q=consort+participant+flow+diagram&safe=off&source=lnms&tbm=isch&sa=X&ved=0ahUKEwjV1ryU8oDKAhUBoRoKHTZQCJsQ_AUIBygB&biw=1278&bih=593'>\
# examples</a>, use these templates \
# (<a href = 'http://www.consort-statement.org/download/Media/Default/Downloads/CONSORT%202010%20Flow%20Diagram.doc'>MS Word<\a>, \
# <a href = 'http://www.consort-statement.org/download/Media/Default/Downloads/CONSORT%202010%20Flow%20Diagram.pdf'>PDF</a>) \
# or <a href = 'https://www.gliffy.com/'>make your own</a>"
"none":"",\
"section":"Methods",\
"important":False
},\

"title_keywords_consort":\
{"pass":"Your title states that this is a randomised trial",\
"fail":"Have you included the term 'Randomised Trial' in your title?",\
"explain":"""Scientists and search engines look for specific words in the titles of manuscripts when searching for literature. Your title should include the term "Randomised Trial" so that other people can find your work easily and include it in reviews or policy recommendations.""",\
"none":"",\
"section":"Title Page",\
"important":False
}

}
