table_media_texts_dict = {

# "tables_present_if_cited":\
# {"pass":"You've included tables in your manuscript",\
# "fail":"Have you included this table that you've cited?",\
# "explain":"It seems like your article cites a table, but we can't find one in \
# your manuscript. You should make them using the table function in Word, not as an \
# embedded excel table",\
# "none":"It looks like your manuscript doesn't mention any tables"},
# 
# "tables_present_if_legends":\
# {"pass":"You've included tables in your manuscript",\
# "fail":"Have you included the table for this legend?",\
# "explain":"It seems like your article includes table legends, but we can't find any tables in \
# your manuscript. You should make them using the table function in Word, not as an \
# embedded excel table",\
# "none":"It looks like your manuscript doesn't have any table legends"},

"tables_present_if_mentioned":\
{"pass":"You have included tables within this file",\
"fail":"Have you included tables in this file?",\
"explain":"""It looks like your article mentions tables, but there don't seem to be any in this file. 
You should put tables near to where they are first mentioned. Make the tables using Microsoft Word's table function. Don't embed them as images or excel spreadsheets as journal software cannot always process these. Avoid using merged cells as these can get distorted.""",\
"none":"It looks like your manuscript doesn't mention, or include tables",\
"section":"Tables",\
"important":True,\
},

"no_surprise_tables":\
{"pass":"You have referred to the tables you've included",\
"fail":"Does each table have a legend and have you referred to each one in your article?",\
"explain":"""Make sure each table has a legends above itself. Table legends should begin with 'Table' followed by a number. Make sure that you refer to each table in the body of your article. 
A good legend will allow readers to quickly understand the data presented in the table without having to read the main article.""",\
"none":"It looks like your manuscript doesn't have any tables",\
"section":"Tables",\
"important":False,\
},

"figures_present_if_mentioned":\
{"pass":"You have inserted figures within this file",\
"fail":"Have you inserted figures within this file?",\
"explain":"""You should embed all figures into this file, near to where they are first discussed. You can use colour and shading, but keep the background white and make sure your figure is legible when printed in black and white. Avoid using 3D graphics.""",\
"none":"It looks like your manuscript doesn't mention, or include figures",\
"section":"Figures",\
"important":True,\
},

"no_surprise_figures":\
{"pass":"You have referred to the figures you've included",\
"fail":"Has each figure got a legend and have you referred to each one in your article?",\
"explain":"""Each figure should have a title below it, starting with 'Figure' and the figure number, followed by a caption. 

Figure legends are one of the more commonly read parts of a manuscript, so it's worth spending time on them. A good legend will provide enough information for the figure to be understood without having to read the article. 

If your figure presents data, make sure the legend includes units, and define any error bars as the standard deviation, 95% confidence intervals or other measure if used.""",\
"none":"It looks like your manuscript doesn't have any figures",\
"section":"Figures",\
"important":False,\
},

"numerically_ordered_table_c":\
{"pass":"You've mentioned tables in numerical order",\
"fail":"Have you numbered your tables in the order you talk about them?",\
"explain":"""Tables must be numbered according to the order they are mentioned in the body of the article.""",\
"none":"It wasn't possible to check that tables are cited in numerical order, because no table citations were found",\
"section":"Tables",\
"important":False,\

},\

"numerically_ordered_figure_c":\
{"pass":"All figures are mentioned in numerical order",\
"fail":"Have you numbered your figures in the order you talk about them?",\
"explain":"""Figures must be numbered according to the sequence they are mentioned in the body of the article.""",\
"none":"It wasn't possible to check that figures are cited in numerical order, because no table citations were found",\
"section":"Figures",\
"important":False,\

},\

"numerically_ordered_table_l":\
{"pass":"Your tables are in the right order",\
"fail":"Are your table legends in the right order?",\
"explain":"""Tables legends must be ordered numerically, according to the order they are mentioned in the body of the article.""",\
"none":"It wasn't possible to check that table legends occur in numerical order, because no table lagends were found",\
"section":"Tables",\
"important":False,\

},\

"numerically_ordered_figure_l":\
{"pass":"Your figures are in the right order",\
"fail":"Are your figure legends in the right order?",\
"explain":"""Figures and their legends must be ordered numerically, according to the order they are mentioned in the body of the article.""",\
"none":"It wasn't possible to check that figure legends occur in numerical order, because no figure lagends were found",\
"section":"Figures",\
"important":False,\

},\

"no_missing_table_c":\
{"pass":"You've mentioned every table in the article body",\
"fail":"Have you discussed all tables in your main text?",\
"explain":"""Make sure you've referred to every table in the body of your article, and that you've specified the table number.""",\
"none":"We couldn't crosscheck your table legends and citations because we couldn't find any",\
"section":"Tables",\
"important":False,\

},\

"no_missing_figure_c":\
{"pass":"You've mentioned every figure in the article body",\
"fail":"Have you mentioned every figure in the main text?",\
"explain":"""Make sure you've referred to every figure in the body of your article, and that you've specified the figure number.""",\
"none":"We couldn't crosscheck your figure legends and citations because we couldn't find any",\
"section":"Figures",\
"important":False,\

},\

"no_missing_table_l":\
{"pass":"Every mentioned table has a table legend",\
"fail":"Have you included a legend for every table?",\
"explain":"""Table legends should begin with 'Table', followed by the table number. 

The table legend should be placed above the embedded table, and both should appear near to where they are mentioned to make life easier for reviewers.""",\
"none":"",\
"section":"Tables",\
"important":False,\

},\

"no_missing_figure_l":\
{"pass":"Every mentioned figure has a figure legend",\
"fail":"Have you included a legend for every figure?",\
"explain":"""Figure legends should begin with 'Figure', followed by the figure number. 

The figure legend should be placed below the embedded figure, and both should appear near to where they are mentioned to make life easier for reviewers.""",\
"none":"",\
"section":"Figures",\
"important":False,\
},\

"no_skipped_figure_l":\
{"pass":"Your figures are numbered sequentially",\
"fail":"Have you skipped a figure number?",\
"explain":"""Figures should be numbered in the order they are discussed in the main article.""",\
"none":"",\
"section":"Figures",\
"important":False,\
},\

"no_skipped_table_l":\
{"pass":"Your tables are numbered sequentially",\
"fail":"Have you skipped a table number?",\
"explain":"""Tables should be numbered in the order they are discussed in the main article.""",\
"none":"",\
"section":"Tables",\
"important":False,\
},\

"table_extracted":\
{"pass":"None of your tables have merged cells or line breaks",\
"fail":"Does this table include merged cells or line breaks?",\
"explain":"""Text boxes, or tables that include complicated formatting like merged cells or line breaks within cells, can get corrupted when your word file is converted into other formats. This can make it impossible for editors or reviewers to read the content properly.""",\
"none":"",\
"section":"Tables",\
"important":False,\
}

}