main_headings_texts_dict = {

"abstract_h":\
{"pass":"You have included an abstract",\
"fail":"Have you included an abstract?",\
"explain":"""Your manuscript should have a section titled 'Abstract', where you summarise your research. If you've already got an abstract make sure the title is spelled correctly and doesn't have any strange formatting. 

Abstracts for research articles should have the subheadings 'Purpose', 'Methods', 'Results' and 'Conclusions'. Review articles should use the subheadings of 'Purpose', 'Recent Findings' and 'Summary'.""",\
# http://onlinelibrary.wiley.com/journal/10.1111/(ISSN)1475-1313/homepage/ForAuthors.html
"none":"There was a problem while checking your manuscript for an Abstract section",\
"section":"Abstract",\
"important":True,\
},\

"introduction_h":\
{"pass":"You have included an introduction",\
"fail":"Have you included an introduction?",\
"explain":"""Your manuscript should have a section titled 'Introduction'. If you already have one, make sure the heading is spelled correctly and doesn't have any strange formatting.

Your introduction should succinctly explain the rationale behind your research. The background needn't be exhaustive, but it should be a balanced representation of the existing field of research. At the end, set out your research question and testable hypotheses.""",\
# http://onlinelibrary.wiley.com/journal/10.1111/(ISSN)1475-1313/homepage/ForAuthors.html
"none":"There was a problem while checking your manuscript for an Introduction section",\
"section":"Introduction",\
"important":True,\
},\

"methods_h":\
{"pass":"You have included a methods section",\
"fail":"Have you included a methods section?",\
"explain":"""Your manuscript should have a section titled 'Methods'. If you already have one, make sure the heading is spelled correctly and doesn't have any strange formatting.

Your methods section should describe the experimental design, subjects used and procedures followed in sufficient detail such that others could duplicate the research. Include details of ethical standards followed, where appropriate.""",\
# http://onlinelibrary.wiley.com/journal/10.1111/(ISSN)1475-1313/homepage/ForAuthors.html
"none":"There was a problem while checking your manuscript for a Methods section",\
"section":"Methods",\
"important":True,\
},\

"results_h":\
{"pass":"You have included a results section",\
"fail":"Have you included a results section?",\
"explain":"""Your manuscript should have a section titled 'Results'. If you already have one, make sure the heading is spelled correctly and doesn't have any strange formatting.

Your results section should describe your data and statistical analyses with minimal discussion.""",\
# http://onlinelibrary.wiley.com/journal/10.1111/(ISSN)1475-1313/homepage/ForAuthors.html
"none":"There was a problem while checking your manuscript for a Results section",\
"section":"Results",\
"important":True,\
},\

"discussion_h":\
{"pass":"You have included a discussion section",\
"fail":"Have you included a discussion section?",\
"explain":"""Your manuscript should have a section titled 'Discussion'. If you already have one, make sure the heading is spelled correctly and doesn't have any strange formatting.

Your discussion section should highlight the key features of the results and their interpretation and do not merely reiterate the results. Include any limitations of the study.""",\
# http://onlinelibrary.wiley.com/journal/10.1111/(ISSN)1475-1313/homepage/ForAuthors.html
"none":"There was a problem while checking your manuscript for a Discussion section",\
"section":"Discussion",\
"important":True,\
},\

"references_h":\
{"pass":"You have a references section",\
"fail":"Have you got a reference section?",\
"explain":"""Your manuscript should have a section titled 'References' where you list your cited sources in numerical order. If you already have one, make sure the heading is spelled correctly and doesn't have any strange formatting.

Try to avoid citing sources that aren't peer reviewed, or haven't been published yet, and avoid excessively citing your own work. 

Most medical journals use the [Vancouver referencing system](https://en.wikipedia.org/wiki/Vancouver_system), where sources are cited with superscript numbers. For examples see section 10 of [OPO's author guideline page](http://onlinelibrary.wiley.com/journal/10.1111/(ISSN)1475-1313/homepage/ForAuthors.html).""",\
# http://onlinelibrary.wiley.com/journal/10.1111/(ISSN)1475-1313/homepage/ForAuthors.html
"none":"There was a problem while checking your manuscript for a References section",\
"section":"Referencing",\
"important":True,\
}

}