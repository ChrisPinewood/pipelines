statistics_texts_dict = {

"correct_f_test":\
{"pass":"These *F*-test statistics are consistent with their *p*-values",\
"fail":"Are these *F* statistics correct?",\
"explain":"""Double check these values as the *p*-value you've provided is not consistent with a 1 tailed test using the *F* statistics and degrees of freedom you've supplied. If you've used special calculations make sure these are clear.""",\
"none":"It looks like you've not reported any f-tests in the main body of text",\
"section":"Results",\
"important":False,\
"quote_all":True,\
},\

"correct_t_test_2tail":\
{"pass":"These *t* statistics are consistent with their *p*-values using a 2 tailed test",\
"fail":"Are these *t* statistics correct?",\
"explain":"""Double check these values as the *p*-values you've provided are not consistent with neither a 2 tailed or 1 tailed test using the *t* statistics and degrees of freedom you've supplied. If you've used special calculations make sure you make these clear.""",\
"none":"It looks like you've not reported t-tests in the main body of text",\
"section":"Results",\
"important":False,\
"quote_all":True,\
},\

"correct_t_test_1tail":\
{"pass":"These *t*-tests are consistent with their *p*-values using a 1 tailed test",\
"fail":"Are these *t* statistics correct?",\
"explain":"""Double check these values as the *p*-values you've provided are not consistent with either a 1 or 2 tailed test using the *t* statistics and degrees of freedom you've supplied. If you've used special calculations make sure you make these clear.""",\
"none":"",\
"section":"Results",\
"important":False,\
"quote_all":True,\
},\

"correct_r_test_2tail":\
{"pass":"These Pearson correlations are consistent with their *p*-values",\
"fail":"Are these Pearson correlations correct?",\
"explain":"Double check these values as the *p*-values and *r* statistics you've supplied aren't consistent for either a 1 or 2 tailed test. If you've used special calculations make sure these are clear.",\
"none":"",\
"section":"Results",\
"important":False,\
"quote_all":True,\
},\

"correct_r_test_1tail":\
{"pass":"These *p*-values are consistent with a 1 tailed Pearson's correlation",\
"fail":"Are these Pearson correlations correct?",\
"explain":"Double check these values as the *p*-value you've provided is not consistent with the *r* statistic and degrees of freedom you've supplied. If you've used special calculations make sure these are clear.",\
"none":"",\
"section":"Results",\
"important":False,\
"quote_all":True,\
},\

"one_tailed_t_test_declared":\
{"pass":"1 tailed *t*-test declared",\
"fail":"Have you justified using a 1 tailed *t*-test?",\
"explain":"""If you perform a 1 tailed *t*-test you should declare it and justify why a 2 tailed test is not necessary.""",\
"none":"",\
"section":"Results",\
"important":False,\
},\

"two_tailed_t_test":\
{"pass":"No 1 tailed t tests found",\
"fail":"",\
"explain":"",\
"none":"",\
"section":"Results",\
"important":False,\
},\

"t_tests_reported_well":\
{"pass":"You've reported all *t*-tests with their degrees of freedom",\
"fail":"Have you reported the degrees of freedom for these *t*-tests?",\
"explain":"""When reporting a *t*-test you should include the degrees of freedom and the *t* statistic. Write this as *t*(df) = *t* statistic.

[Read more about good statistical reporting](http://www.equator-network.org/2013/02/11/sampl-guidelines-for-statistical-reporting/)""",\
"none":"",\
"section":"Results",\
"important":False,\
"quote_all":True,\
},\

"f_tests_reported_well":\
{"pass":"You have reported all *F*-tests with their degrees of freedom",\
"fail":"Have you reported the degrees of freedom for these *F*-tests?",\
"explain":"""When reporting an *F*-test you should include both of the degrees of freedom (df) you used to calculate the *F*-statistic. Write this as *F*(df1, df2) = *F*-statistic. The degrees of freedom are important as they help the reader understand the scale of the study. You can learn more about how to calculate each df value, and what they mean, [here](http://ron.dotsch.org/degrees-of-freedom/). 

[Read more about good statistical reporting](http://www.equator-network.org/2013/02/11/sampl-guidelines-for-statistical-reporting/)""",\
"none":"",\
"section":"Results",\
"important":False,\
"quote_all":True,\
},

"r_tests_reported_well":\
{"pass":"You have reported all Pearson's correlations without their sample size or degrees of freedom",\
"fail":"Have you included the sample size for these Pearson's correlations?",\
"explain":"""When reporting a Pearson's correlation you should include the sample size (n) that was used to calculate the *r* statistic. Write this as *r*(n = ___) = r statistic. 

Alternatively, you can report the degrees of freedom (df) instead of the sample size. You calculate this as n - 2, and write it as *r*(df = ___) = r statistic. 

[Read more about good statistical reporting](http://www.equator-network.org/2013/02/11/sampl-guidelines-for-statistical-reporting/)""",\
"none":"It looks like you've not reported any Pearson correlations in the main body text",\
"section":"Results",\
"important":False,\
"quote_all":True,\
},

"pval_as_equalities":\
{"pass":"These *p*-values are reported well",\
"fail":"Have you given the exact *p*-values here?",\
"explain":"""Most medical journals require that all *p*-values are reported as exact figures, not as inequalities, except for *p*-values smaller than .001. For example: *p* = .074, *p* = .042, *p* < .001. 

[Read more about good statistical reporting](http://www.equator-network.org/2013/02/11/sampl-guidelines-for-statistical-reporting/)""",\
"none":"It looks like you've not reported any *p*-values in the main text",\
"section":"Results",\
"important":False,\
"quote_all":True,\
},

"confidence_intervals":\
{"pass":"You have included confidence intervals",\
"fail":"Have you included confidence intervals for every *p*-value?",\
"explain":"""Medical journals require that all *p*-values are accompanied by an estimate of precision. This is typically a 95% confidence interval.

[Learn more](http://onlinestatbook.com/2/estimation/confidence.html) about confidence intervals, or use [free online calculator](https://www.mccallum-layton.co.uk/tools/statistic-calculators/confidence-interval-for-mean-calculator/)""",\
"none":"",\
"section":"Results",\
"important":False,\
}

}